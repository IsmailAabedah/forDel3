Decompiled factory apps (jadx, Java sources only, no resources) from the head unit.
sources/<package>/sources/...  = decompiled Java.
Not decompiled: com.zhonghong.yzpicture, android.ext.*, third-party apps (ES, X Browser, GPS Test, Target, Neshan).
analysis/ : inv.json + comps.txt (manifest components of every app), aidl.json (all AIDL interfaces with transaction codes),
            canmap.txt (CAN signal map), mcu_api.txt (MCU proxies), logic_const.txt, bt_const.txt.
ZhongHong_HeadUnit_Integration_Handoff_v2.md = the integration document.
Note: manifests are not inside sources/ (jadx ran without resources); see analysis/comps.txt and inv.json.
