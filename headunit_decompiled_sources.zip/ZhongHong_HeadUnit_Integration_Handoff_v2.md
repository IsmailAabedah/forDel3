# ZhongHong Android Head Unit — Integration Handoff (revision 2, includes the 27 Oct 2026 field test)

Purpose: give another AI/developer everything needed to talk to **every unit of this car's head unit** from a normal Android app (a custom launcher / dashboard). It is built from (a) the factory APKs pulled from the unit, decompiled and read, and (b) on-device probe reports produced by a probe app running as a normal app.

## 0. Scope, legend, ground rules

**Confidence tags used everywhere**

| Tag | Meaning |
|---|---|
| `[CODE]` | Read directly in decompiled factory code (descriptors, transaction codes, constants, bit positions). High confidence on *format*. |
| `[DEVICE]` | Observed on the real unit in a probe report. |
| `[VERIFIED]` | Tested on the real unit from a normal app (field test of 27 Oct 2026, section 1b). Authoritative; it overrides anything else in this document. |
| `[UNTESTED]` | Never tried on the device. Treat as "should work, verify first" and use the fallback given in section 1b. |
| `[NOT FOUND]` | Looked for it in the provided APKs and it is not there. |

**Ground rules**
- Target process: a normal app (uid `u0_aXX`, `untrusted_app`), `targetSdkVersion 22` (so all manifest permissions are granted at install; there is no runtime-permission UI to rely on).
- Out of scope: rooting, privilege escalation, modifying the system partition, or anything that needs system UID. Everything below uses interfaces that are exported/world-accessible or readable by any app.
- The third-party launcher `com.wicardtech.wicardcl` (QuickSmartDrive) was **deliberately not analysed or used**. Nothing here comes from it.
- Privacy: device serial number, device ID and GPS coordinates seen in the raw reports were removed.
- Language of the car: system locale `fa-IR`, time zone `Asia/Tehran`. The owner's UI language is Arabic (UI text is the app's own choice, independent of the system locale).

## 1. Device and system facts `[DEVICE]`

| Item | Value |
|---|---|
| Model / board | `AOSP on zh_dragon`, board/hardware `zh_dragon`, manufacturer `NEXELL` (SoC family referenced as `nxp4330` in boot props) |
| Android | 7.1.2 (SDK 25), build `N2G48H`, `userdebug`, `release-keys` |
| Fingerprint | `Android/aosp_zh_dragon/zh_dragon:7.1.2/N2G48H/builde02141541:userdebug/release-keys` |
| ABI | `armeabi-v7a`, `armeabi` only (**32-bit**; no arm64) |
| Screen | 952 x 600 px, density 1.5 (240 dpi bucket), ~634 x 400 dp, landscape, 7 inch |
| SELinux | `ro.boot.selinux = permissive` (so SELinux is not what blocks binder/service lookups) |
| Process context of probe | `uid=10030(u0_a30)`, `untrusted_app`, groups `net_bt_admin(3001)`, `net_bt(3002)`, `inet(3003)`, `everybody(9997)` |
| Default HOME | not set: `ResolverActivity` chooser. HOME candidates: `com.zhonghong.launcher/.activity.LauncherActivity`, the custom app, `com.wicardtech.wicardcl` (QuickSmartDrive), `com.android.settings/.FallbackHome`. `persist.sys.default.launcher` points at the factory launcher |
| Input / UI | `persist.zh.force_no_anim=true`, `persist.zh.forced_no_orient=true`, `ro.zh.inputmethodbottom=30` |
| Audio | `ro.zh.multi.audio_channel=true`; `persist.sys.max_*` (music, navi, tts, voice_call, alarm, ring, system, notification, bluetooth_sco, dtmf) are all **30**; `persist.sys.default_navi=18`, `persist.sys.default_voice_call=20`. A custom navigation audio stream exists: `STREAM_NAVI = 10` `[CODE]` |
| Locale / TZ | `fa-IR`, `Asia/Tehran` |
| Media codecs (boot props) | ext audio `ape,wma,ac3`; ext video `avi,flv,ts,mkv,rm,rmvb,asf,wmv` |
| Storage | internal `/sdcard` (FUSE, `/storage/emulated`); USB sticks appear as `/storage/udisk1`, `/storage/udisk2` (vfat, mounted from `/mnt/media_rw/udiskN`). App-private dirs on USB: `/storage/udiskN/Android/data/<pkg>/files` are writable; the USB root generally is not for a normal app |
| Misc facts | `persist.phone.easyconnect=true` (phone-mirroring app present); `sys.btcall`, `sys.carlifevr`, `zh.navi.pidlist` props exist (see section 8); `persist.sys.usb.config=adb` and a functionfs `adb` mount exist in the property/mount tables (reported as facts only; no developer-options UI is exposed to the user) |

### Hardware ports `[DEVICE]`
Kernel props: `ro.kernel.android.gps=ttyAMA0`, **`ro.kernel.android.mcu=ttyAMA2`**, `ro.kernel.android.bt=goc_serial`, `ro.mcu.baudRate=2`.
`/dev/ttyAMA0..4` are `crw-rw-rw- system system` (world read/write). `ttyAMA0` carries standard NMEA GPS sentences (`$GNGGA…`). `ttyAMA2` is the MCU link (first run sample began `FF AA 50 00 …`, second run was idle). `ttyAMA1` carries C0-delimited binary frames (looks SLIP-like, e.g. `C0 D3 74 00 B8 13 05 01 02 00 01 00 FB 69 C0`), purpose not identified. `ttyAMA3`/`ttyAMA4` idle. `/dev/i2c-*` are root-only. `usb_i2c` is world rw (purpose unknown).
**Do not read or write these ports in production**: the factory MCU service owns them, and reading steals bytes from it. Use the binder interfaces below instead.

### System services registered in ServiceManager (`service list`) `[DEVICE]`
`_logic_service` (`com.logic.common.aidl.ILogicInterface`), `zhonghong.mcu` (`android.zhonghong.IMcuService`), `zhupdate_service` (`com.zhonghong.update.aidl.IUpdateInterface`). `zhbt_service` and `zh_can_service`, which the factory code looks up, were **absent in three `service list` snapshots, including one taken with the car on and a phone connected**. The Bluetooth control service therefore does **not exist on this unit**; see sections 1b and 3.4.

### Installed packages (non-AOSP) `[DEVICE]`
All factory packages are `SYSTEM`; most run as `android.uid.system`. Third party: `com.estrongs.android.pop` (ES File Explorer), `com.xbrowser.play` (X Browser), `com.chartcross.gpstest` (GPS Test), `com.polstar.polnav6` (navigation, "Target"), `org.rajman.neshan.traffic.tehran.navigator` (Neshan), `net.easyconn` (EasyConnected phone mirroring), `com.persian.keyboard…`, plus the user-installed launchers. Full package list with versions is in section 2.

### Things a normal app can / cannot do on this unit `[DEVICE]`
- Can: be a HOME candidate (it appears in the chooser), launch every factory activity and the hidden system apps (ES, X Browser, GPS Test, Android Settings), bind exported factory services, read exported content providers, read `Settings.System`, read system properties.
- Factory apps are not visible in any system app drawer; they only appear through a launcher that lists all `LAUNCHER` activities.
- Installing APKs is only possible through the ES file explorer / package installer launched from a custom launcher (no store, no stock file manager UI).

## 1b. Field test results — 27 Oct 2026 (authoritative)

Source: a diagnostic app (`CarCheck`) run as a normal app on the unit, car on, phone paired, car stationary (never driven). It logged every CAN signal change with timestamps while the owner performed actions and pressed a matching button after each. Where this section disagrees with anything else in the document, **this section wins**. Owner-supplied facts about the car are marked *(owner)*.

### Facts about this car *(owner)*
- Passenger seat belt has **no sensor**. Wipers and windows **have no usable sensors** (confirmed: signals never changed).
- The factory settings app has a passenger-airbag **status** item; in code it is a read-only display (0 = not inhibited, 1 = inhibited). No control path was found.
- Bluetooth and calls work in the factory UI (answer, reject, dial by typing a number). The factory UI shows **no contact names and no call history**, and the providers confirm that data is not available.
- Radio, USB music, video and flash-drive playback all work in the factory apps. Brightness and EQ are set in the factory settings. Volume changes from the factory app, from the head-unit buttons and from the steering-wheel buttons.

### A. CAN signals verified by real actions (CAN service, normal app)
Frame layout seen: each frame is a 14-byte array = `id_hi, id_lo, 0x09`, then 8 data bytes, then 3 trailer bytes (e.g. `02 41 09 | 02 00 00 00 40 06 00 07 | 00 A0 0A` for frame 577 = 0x241). Data bytes start at array index 3, exactly as the bit-access rule in 3.1 assumes; decoded values matched the car in every test.
**Frame 564 (CarStatus switches) was missing from the first fetch and arrived only after the first CAN notification.** Fetch again every time `onCanDataNotify(type)` fires.

| Thing | Signal (frame) | Verified meaning |
|---|---|---|
| Driver door | `Front_LH_Door_Switch_Status` (564 b1 bit0) | **0 = open, 1 = closed** |
| Passenger door | `Front_RH_Door_Switch_Status` (564 b1 bit1) | 0 = open, 1 = closed |
| Rear-left / rear-right door | `Rear_LH_...` bit2, `Rear_RH_...` bit3 (564 b1) | 0 = open, 1 = closed |
| Trunk, bonnet | `Trunk_Lid_Switch_Status` bit4, `Bonnet_Switch_Status` bit5 | not exercised; factory UI treats them like doors (0 = open) |
| Dome light | `Roof_Lamp_Status` (963) | 1 = on (turns on when a door opens) |
| Brake pedal | `Brake_Pedal_Switch_Status` (564), `BrakePedalStatus` (577), `Brake_Lamp_Status` (963) | 1 = pressed / lamp on |
| Hand brake | `Hand_Brake_Switch_Status` (564 b4 bit2) | **1 = engaged, 0 = released** |
| Driver belt | `Driver_Seat_Belt_Switch_Status` (564 b4 bit4) and `Driver_seatbelt_lock_recognition` (722) | **0 = fastened, 1 = NOT fastened** (factory SRS page: 0 locked, 1 unlocked) |
| Passenger belt | `Passanger_Seat_Belt_Switch_Status` (564), `Passenger_seatbelt_lock_recognition` (722 = 3) | no sensor; never changed |
| Parking lamps | `Position_Lamp_Status` (963), `Position_Lamp_Switch_Status` (564) | 1 = on |
| Low beam | `Low_Beam_Status` (963), `Low_Beam_Switch_Status` (564) | 1 = on |
| High beam | `High_Beam_Status` (963), `High_Beam_Lamp_Switch_Status` (564) | 1 = on; low beam signals go to 0 while high beam is on |
| Front / rear fog | `Front_Fog_Lamp_Status`, `Rear_Fog_Lamp_Status` (963) | 1 = on. The `*_Switch_Status` fog signals in 564 are **momentary pulses**: use the 963 lamp status |
| Daylight | `Daylight_Status` (963) | 1 in normal state, goes to 0 while the lights are on (meaning inferred) |
| Turn indicators | `Left_Indicator_Lamp_Status`, `Right_Indicator_Lamp_Status` (963) | **toggle every ~0.35 s while the indicator is active** (blink state, not a steady flag). `Buzzer_Output__Status` (963) ticks with each blink |
| Indicator stalk | `LH_Indicator_Switch_Status`, `RH_Indicator_Switch_Status` (564) | 1 while the stalk is held in that position (short pulses for a flick); `Indicator_Lamps_Command` (564): **1 = right, 2 = left, 0 = none** |
| Hazard | `Hazard_Switch_Status` (564) = momentary pulse; `Hazard_LED_Output_Status` (963) blinks | both indicator lamps blink together. Detect "indicator/hazard active" as "lamp status changed in the last 1 s" or `Indicator_Lamps_Command != 0` |
| Gear lever | `Shifter_Lever_Signals` (1218 b1 bits 2-5) | **9 = P (rest state), 10 = R, 11 = N, 12 = D.** 10 coincided with `back_state=true`; the sequence P-R-N-D was performed in order. `Transmission_EOL_Status` changes with the lever: do not use |
| Reversing lamp | `Reversing_Lamp_Status` (963) | 1 = on (also pulses while the lever passes through R) |
| Central lock | `Door_Lock_Output__Status` (963) | **1 = lock command, 2 = unlock command** (short pulse). `Master_Lock_Switch_Status` (564) pulses when the lock button is pressed. A persistent "locked" flag was not identified |
| Power | `PowerDistributionStatus` (577) = 2; `ACCRelaySt`, `IG1RelaySt`, `IG2RelaySt` = 1; `StartRelaySt` = 0 | state with engine running; `KeyPositionStatus` toggles whenever a door opens: unreliable, ignore |
| Tyres | `*TyrePressureValue` (1042) raw 94 each; `*TyreTemperatureValue` raw 65; status 0; localisation 1; `PEPS_TPMSSystemConfiguration` = 1 | `bar = ceil(raw*1.378+100)/100` -> **2.30 bar**; `°C = raw-40` -> **25 °C**. Plausible, formula confirmed from the factory UI code |
| Outside temp | `AmbientTemp` (695) raw 110 / 112 | `raw*0.5-40` -> 15.0 / 16.0 °C (flips by 1 °C) |
| Odometer | `ODO_calculated_By_BCM` (800) and `ODO_calculated_By_ICM` (1219) | both = 53342, equal. Unit presumably km; **compare with the dashboard** before showing a unit |
| Vehicle speed | `Vehicle_Speed` (1218 b5) | read 0 (car stationary). **Unit not verified** |
| Airbag | `Error_flag_of_the_airbag_ECU` = 0, `Passenger_airbag_cut_off_status` = 0, `The_crash_intensity_describes_whether_there_is_a_crash` = 0 (722) | read-only status (factory code: airbag error 0 ok / 1 error; cut-off 0 not inhibited / 1 inhibited; crash 0 none / 1 crash) |
| Wipers, windows | `Wiper_*`, `*_Window_Switch_Status` (564) | never changed: **no sensors, do not offer these features** |

Noise to filter out when watching for changes: any `Checksum`, `counter`, `Torque`, `Overal_Ratio`, `is413CanValid` signal and the two odometers.

### B. Other services, tested
| Item | Result |
|---|---|
| `_logic_service` | `[VERIFIED]` all `getValue` keys work; events `onIllStateChanged`, `onBackStateChanged` arrive (see 3.2). `getSourceId` = 4099, `getThirdSourceId` = 4096, `getFocusState` = 1 |
| `zhonghong.mcu` | `[VERIFIED]` `getTest() = 100`; `{"all":0}` reads for domains 1, 2, 3; keyed reads; volume follows changes (see 3.3). Writes untested |
| `zhbt_service` | **absent** (3 snapshots, car on, phone connected) |
| System-state broker | `[VERIFIED]` getters, callbacks, events: `back`, `volume` (10..14), `btPhoneState` (0, 2, 3, 7 during a dialled call that was ended) |
| USB music service | `[VERIFIED]` bind and reads; commands not exercised |
| USB video service | **does not connect** (bind true, no connection in 5 s) |
| BT provider | tables empty; contacts/call-log providers unusable |
| Media provider | `[VERIFIED]` audio 10 rows, `scan_state` = 2 |
| Overlay window (type 2002) | `[VERIFIED]` works |
| `sys.btcall` | `[VERIFIED]` unset -> `true` during a call -> `false` afterwards |
| `Settings.System` BT keys | `[VERIFIED]` `bt_connected=true`, `key_bluetooth_state=2`, `key_signal_state=5`, `key_battery_state` 2 then 3 |
| Audio streams | streams 0..10 valid (11 invalid), max 30 each; STREAM_MUSIC (3) = 9 while MCU `SYS_VOL` = 14: **the MCU volume is not the Android stream volume**; stream 10 (navigation) exists |
| Installed | AVM, CarLife, phonelink, power, zuiserver, radio packages **not installed**; EasyConnected, ES, X Browser, GPS Test, Target, Neshan, Google Maps installed; all 17 factory intents/components resolve |
| Firmware | `ro.build.zhonghongpackage = YIZHAN 2024-01-17 21:16:49`; `zh.navi.pidlist = 1244,1602` while navigation apps ran |
| Settings.System | `screen_brightness = 230`; `radio_rds_enbale=false`; `system_state_aux=0`; maintenance keys hold text like `<number>_<number>` with Persian digits (e.g. remaining km `۴۰۰۰_33926`): parse with Unicode digit support |

### C. Fallback rules for the implementer (use these when a feature cannot be verified or is unavailable)

| Feature | Primary method | Fallback if it fails | Last resort |
|---|---|---|---|
| Doors, lamps, brake, hand brake, driver belt, gear, TPMS, outside temp, power | CAN service (table A), re-fetch on every notification | none needed (verified) | hide the item while its frame is missing |
| Reverse state | any of: `Settings.System back_state`, Logic `onBackStateChanged`, broker `notifyBackState`, MCU `BACK_SIGNAL` | use a second source; all four were verified | CAN `Shifter_Lever_Signals == 10` |
| ACC, power, lights-switch state | Logic events / MCU domain 3 / broker | CAN relays and lamp status | - |
| Vehicle speed | GPS speed (Location, provider verified enabled) | CAN `Vehicle_Speed` | **Auto-calibrate on the first drive**: while GPS speed > 20 km/h compare the two; if CAN/GPS stays within about 5 % use CAN, if the ratio is a stable constant (e.g. 1.6 or 0.62) apply it, otherwise stay on GPS. Never show CAN speed before it has been validated |
| Volume (read) | MCU `SYS_VOL` + broker `notifyVOL` events | factory settings screen | - |
| Volume (write) | **not verified**; do not rely on it. Hardware keys / steering-wheel / factory app already do it | after a harmless same-value write test succeeds, `sendInfo(2,1,{"SYS_VOL":n})` | open `com.zhonghong.action.set` |
| Brightness, EQ | open the factory screens (`com.zhonghong.action.set`, `com.zhonghong.action.eq`) | read-only display from MCU (`backlight`, `bass`, `SYS_USER_MID`, `treb`) | - |
| Radio | open the factory radio screen | read MCU domain 1 when `status` is not `off` (frequency keys were not captured; verify before using) | show only the active source id (Logic `getSourceId`, MCU `MCU_SOURCE`) |
| USB music | `UsbMusicService` for now-playing and controls (bind verified) | open `com.zhonghong.intent.action.music` / `usb_music_list` | - |
| USB video | open `com.zhonghong.video_activity` | - | - |
| Phone / calls | factory screens (`android.bluetooth_btdial`, `btmusic`, `btsettings`); factory call screen handles incoming calls | status from `Settings.System` keys, `sys.btcall`, broker `btPhoneState` | no custom answer/reject/dial, no contacts, no call log |
| Custom popups / alerts | overlay window type 2002 (verified) | in-app banner | - |
| Voice alerts | no TTS engine on the unit: bundled audio clips | tones | visual banner |
| Passenger airbag | show the CAN status (read only) | - | - |
| Wipers, windows, passenger belt | **do not implement** (no sensors) | - | - |
| Beep / screen-off broadcasts | not verified (beep sent, result unreported; screen-off not sent) | skip | - |
| Trunk / bonnet | CAN bits 4 and 5, assumed like doors (0 = open); verify when first used | hide | - |
| Odometer | show raw value, unit checked against the dashboard | hide | - |
## 2. Package inventory (factory + system)

| Package | Version | Shared UID | Role | Exported components (services / providers / receivers / activities with custom action) |
|---|---|---|---|---|
| `android.ext.services` | 1 | - | AOSP ext services | svc `Ranker` [android.service.notification.NotificationRankerService] |
| `android.ext.shared` | 1 | - | AOSP ext shared | - |
| `com.car.phoneprovider` | 20180720 | - | Phone-book / call-log content provider `com.car.phone_data` | provider `com.car.phone_data` |
| `com.chartcross.gpstest` | 1.5.4 | - | GPS Test (3rd party) | rcv `ImIdShareBroadCastReceiver` [com.inmobi.share.id]; rcv `ReferrerReceiver` [com.android.vending.INSTALL_REFERRER] |
| `com.estrongs.android.pop` | 3.1.0.3 | - | ES File Explorer (3rd party) | svc `OBEXFtpServerService` [android.intent.action.START_OBEX_FTP_SERVER]; provider `com.estrongs.files`; act `FileExplorerActivity` [org.openintents.action.VIEW_DIRECTORY,com.estrongs.android.SHOW_DISK_USAGE]; act `ESFileSharingActivity` [android.intent.action.SEND,android.intent.action.SEND_MULTIPLE]; act `PopNoteEditor` [android.intent.action.EDIT]; act `FileChooserActivity` [com.estrongs.action.PICK_FILE,com.estrongs.action.PICK_FILE,com.estrongs.action.PICK_DIRECTORY,com.estrongs.action.PICK_DIRECTORY,android.intent.action.CREATE_SHORTCUT]; act `ESContentChooserActivity` [android.intent.ac |
| `com.polstar.polnav6` | @0x7f040002 | - | Navigation (3rd party) | svc `PolnavELService` [com.polstar.polnav6.IPolnavELService] |
| `com.xbrowser.play` | 3.4.5 | - | X Browser (3rd party) | act `BrowserActivity` [android.intent.action.WEB_SEARCH,android.intent.action.WEB_SEARCH,android.intent.action.MEDIA_SEARCH,android.intent.action.SEARCH,android.intent.action.SEND] |
| `com.zh.auxin` | 202110211840 | android.uid.system | AUX-in screen | - |
| `com.zh.settings` | 202401051446 | android.uid.system | System settings UI (sound/EQ, display, wifi, system, language) | svc `SetService` [com.zhonghong.action.set]; act `MainActivity` [com.zhonghong.action.set]; act `EqActivity` [com.zhonghong.action.eq] |
| `com.zh.test` | 202301041609 | android.uid.system | Factory test tool (CmdService, boot receiver). Not exported | - |
| `com.zh.yzradio` | 202211090303 | android.uid.system | Radio UI (FM/AM, RDS). Talks to the radio through the MCU service | - |
| `com.zhonghong.aidlserver` | 1.0 | - | System state broker (ACC, volume, BT state, back state, headlamp, network, TUID) with callbacks + generic get/set provider registry | svc `SystemStateService` [com.zhonghong.aidlserver.service.SystemStateService]; svc `SystemStateService2` [com.zhonghong.aidlserver.service.SystemStateService2] |
| `com.zhonghong.bluetooth` | 202401051453 | android.uid.system | Bluetooth/phone stack manager (Nforetek stack). Exported content provider `btinfo`. Control service registers itself as system service `zhbt_service` | svc `BtCtrlManagerService` [com.zhonghong.bluetooth.START_BtCtrlService]; provider `com.zhonghong.bluetooth.provider.btinfo`; rcv `UpdateSystemReceiver` [zhonghong.intent.action.START_UPDATE,zhonghong.intent.action.END_UPDATE,com.zhonghong.bluetooth.call_last_number]; rcv `EasyConnectedReceiver` [net.easyconn.bt.checkstatus,net.easyconn.bt.connected,net.easyconn.app.quit,net.easyconn.a2dp.release,net.easyconn.a2dp.acquire,net.easyconn.bt.connect,net.easyconn.connection.break]; act `MainActivity` [android.bluetooth_btsettings,android.bluetooth_btdial]; act `MusicActivity` [android.bluetooth_btm |
| `com.zhonghong.can` | 2024.01.05 | android.uid.system | CAN decoder service: raw CAN frames -> decoded vehicle state (doors, lights, TPMS, ...). Exposed as bound service | svc `CanService` [com.zhonghong.intent.action.can] |
| `com.zhonghong.carsetting` | 202401171303 | android.uid.system | Car settings UI (TPMS page, car status, ambient temp...). Shows how raw CAN values are converted to display values | - |
| `com.zhonghong.launcher` | 202401051430 | android.uid.system | Factory launcher (home screen, app slots, status widgets) | act `MediaActivity` [com.zhonghong.launcher.MEDIA_ACTION]; act `NaviActivity` [com.zhonghong.launcher.NAVI_ACTION] |
| `com.zhonghong.logic` | 202401051107 | android.uid.system | System logic: ACC/power/reverse(parking)/AVM/illumination states, audio source & focus arbitration, TFT/backlight, reverse transparent layer, key events. Registers system service `_logic_service` | svc `LogicService` [com.zhonghong.logic.service.LogicService] |
| `com.zhonghong.mcu` | 20170117 | android.uid.system | MCU firmware update service only (not the MCU data path) | svc `McuUpdateService` [com.zhonghong.mcu.START_MCUUPDATE]; svc `McuCtrlServer` [com.zhonghong.action.mcuupdate] |
| `com.zhonghong.mediaconfigtool` | 202009281030 | android.uid.system | Media config tool (USB receiver) | - |
| `com.zhonghong.mediascan2` | 20230321.1.0 | - | Media scanner + exported content provider `com.zhonghong.media` (library of audio/video/image/txt) | provider `com.zhonghong.media` |
| `com.zhonghong.screensaver` | 202209191426 | android.uid.system | Screensaver service (exported action) + USB receiver | svc `ScreenService` [com.zhonghong.screensaver.ScreenService] |
| `com.zhonghong.update` | 202302071016 | android.uid.system | System update UI + exported `UpdateService` (also registered as `zhupdate_service`) | svc `UpdateService` [com.zhonghong.ctrl_update] |
| `com.zhonghong.uuidtool` | 202011241500 | android.uid.system | UUID/device identity tool | - |
| `com.zhonghong.yzmusic` | 202303211539 | android.uid.system | USB music player + exported `UsbMusicService` (control & metadata) | svc `UsbMusicService` [com.zhonghong.usb_music_action]; act `MainActivity` [com.zhonghong.usb_music_activity,com.zhonghong.usb_music_list,com.zhonghong.intent.action.music] |
| `com.zhonghong.yzpicture` | 202206021631 | android.uid.system | USB picture viewer | act `MainActivity` [com.zhonghong.usb_music_activity] |
| `com.zhonghong.yzvideo` | 20240105.01 | android.uid.system | USB video player + exported `VideoService` | svc `VideoService` [com.zhonghong.usb_video_action]; act `MainActivity` [com.zhonghong.video_activity] |

Note: in manifests, a service/receiver with an `<intent-filter>` and no explicit `exported` attribute is exported by default on this SDK level. The table lists those as exported.

## 3. How to connect to everything (the connection map)

### 3.0 Reachability matrix

| # | Unit / data | How to reach it | Status |
|---|---|---|---|
| 1 | Vehicle state from CAN (doors, lights, brake, belts, gear lever, TPMS, ambient temp, ODO, power/relays, locks) | `bindService` to `com.zhonghong.can` / `com.zhonghong.can.CanService`, AIDL `ICanInterface` (3.1) | `[VERIFIED]` works from a normal app; decoded values confirmed against real actions |
| 2 | System state: ACC, power, reverse, illumination, running, audio source/focus | System service `_logic_service` (3.2) | `[VERIFIED]` reads and events work |
| 3 | MCU: volume, mute, bass/mid/treble, balance/fade, backlight, MCU clock, system flags, radio state | System service `zhonghong.mcu` (3.3), read side | `[VERIFIED]` read-all and keyed reads work. Writes `[UNTESTED]` |
| 4 | Bluetooth control (answer, hang up, dial, BT music keys) | `zhbt_service` | `[VERIFIED] NOT AVAILABLE`: the service is not registered (phone connected, car on). Use the factory screens and the read-only signals in 3.4 |
| 5 | BT status / metadata | ContentProvider `btinfo` | `[VERIFIED]` provider exists but tables are **empty** (not populated). Use the signals in 3.4-D |
| 6 | Phone book + call log | ContentProvider `com.car.phone_data` | `[VERIFIED] NOT USABLE`: `contacts` and `call_log` return a null cursor, `contacts_favorite` is empty (matches the factory UI, which shows no names or history either) |
| 7 | USB music (metadata + play/pause/next/prev) | bind `UsbMusicService` (3.5) | `[VERIFIED]` bind + reads work. Commands `[UNTESTED]` (nothing was playing) |
| 8 | USB video control | bind `VideoService` (3.5) | `[VERIFIED] NOT RESPONDING`: `bindService` returns true but never connects (5 s). Use the factory video screen |
| 9 | Media library | ContentProvider `com.zhonghong.media` (3.5) | `[VERIFIED]` works (audio table returned rows; `scan_state` readable) |
| 10 | System state broker | bind `SystemStateService` (3.6) | `[VERIFIED]` getters + callbacks work (volume, back, BT phone state events seen) |
| 11 | Radio high-level AIDL / BT-music AIDL | AIDL in the music app | `[NOT FOUND]` no server; radio state is readable from MCU domain 1 (radio was off during the test, so the "radio on" JSON is `[UNTESTED]`) |
| 12 | Key / MultiScreen / Navi / ExtraAudioDevice AIDL | SDK interfaces | `[NOT FOUND]` no server |
| 13 | Screen off / beep broadcasts | Broadcasts received by Logic (3.8) | beep: sent, result not reported (`[UNTESTED]`); screen-off: deliberately not tested |
| 14 | Factory screens (radio, USB music/video/pictures, BT dial/music/settings, system settings, EQ, car settings, AUX, update) | `startActivity` with the actions in 3.8 | `[VERIFIED]` all 17 listed intents/components resolve |
| 15 | Phone call quick check | system property `sys.btcall` | `[VERIFIED]` unset until the first call, then `"true"` during a call and `"false"` after |
| 16 | BT connection / signal / battery | `Settings.System` `bt_connected`, `key_bluetooth_state`, `key_signal_state`, `key_battery_state` | `[VERIFIED]` readable (values seen: `true`, 2, 5, battery 2 then 3) |
| 17 | Draw over other apps (call/alert popups) | `WindowManager` type 2002 (`TYPE_PHONE`) with `SYSTEM_ALERT_WINDOW` | `[VERIFIED]` an overlay window was added successfully |
| 18 | Raw serial ports | `/dev/ttyAMA0..4` | `[DEVICE]` world rw, **do not use** |

**Standard AIDL call recipe (everything marked "standard AIDL" below).**
```
Parcel d = Parcel.obtain(), r = Parcel.obtain();
d.writeInterfaceToken(DESCRIPTOR);
d.writeInt(...)/writeString(...)/writeStrongBinder(cb);       // arguments in declared order
binder.transact(TRANSACTION_CODE, d, r, 0);
r.readException();                                             // then read the return value from r
```
A callback is a `Binder` subclass with `attachInterface(null, CALLBACK_DESCRIPTOR)`; in `onTransact(code,data,reply,flags)` call `data.enforceInterface(CALLBACK_DESCRIPTOR)`, read the arguments, then `reply.writeNoException()`.
Hidden service lookup: `Class.forName("android.os.ServiceManager").getMethod("getService", String.class).invoke(null, name)` (reflection is allowed on SDK 25).
Always run binder calls off the main thread.

---

### 3.1 CAN service (`com.zhonghong.can`)  [CODE]

- Bind: `new Intent().setClassName("com.zhonghong.can","com.zhonghong.can.CanService")` (intent action `com.zhonghong.intent.action.can`). Factory clients first try system service name `zh_can_service`, which is not registered on this unit `[DEVICE]`, then fall back to this bind.
- Descriptor `com.zhonghong.cancommon.ICanInterface` (standard AIDL):

| Code | Method |
|---|---|
| 1 | `registerCallback(ICanDataCallback)` |
| 2 | `unregisterCallback(ICanDataCallback)` |
| 3 | `execCmd(int cmd, String value)` |
| 4 | `execExtraCmd(int cmd, String value, String extra)` |
| 5 | `ElementData getElementDataInfo(int moduleType)` |

- Callback descriptor `com.zhonghong.cancommon.ICanDataCallback`: code 1 `onCanDataNotify(int moduleType)` (call `getElementDataInfo(moduleType)` again when it fires).
- `getElementDataInfo` reply (after `readException()`): `int hasValue`; if non-zero an `ElementData` follows: `int size`, then `size` times { `int frameId`; `int len` (written as a Parcel byte); if `len>0` a Parcel byte-array (`int length` + bytes) }.
- Module types: **1** CarSet (frames 963, 800, 722, 1219, 1218), **2** TPMS (1042, 1043), **3** CarStatus (564, 577), **4** AmbientTemp (695).
- Frame layout: `byte[]` of a frame = 3 header bytes (frame id low/high + 1 byte) then 8 data bytes. Data bit access is Intel/little-endian over the data bytes:
  `value = sum( bit(i) << i )` where bit `i` is at absolute bit position `(3 + byteIdx) * 8 + startBit + i` of the array (bit 0 = LSB of each byte). Verified identical to the factory routine on 22,000 random inputs.
- The full field table (every named signal with byte/bit/length) is in **Appendix A**.
- **Decoded semantics confirmed from the factory car-settings UI code (`com.zhonghong.carsetting`)** `[CODE]`:
  - Doors (frame 564, byte 1, bits 0..5 = front-left/driver, front-right, rear-left, rear-right, trunk, bonnet): **value 0 = OPEN, 1 = closed**.
  - Hand brake (564, byte 4 bit 2) `==1` = engaged. Reverse gear (564, byte 4 bit 3) `==1`.
  - Tyre pressure bar = `ceil(raw * 1.378 + 100) / 100` (one decimal). Tyre temperature °C = `raw - 40`.
  - Tyre pressure status: 0 normal, 1 very low, 2 slightly low, 3 slightly high, 4 very high. Tyre temperature status: 0 normal, 3 slightly high, 4 very high. `TPMSError==1` sensor error; `AirLeakError==1` leak; `SensorLowBattery==1`.
  - A wheel is shown only when `PEPS_TPMSSystemConfiguration == 1` (frame 1043 byte 5 bits 0-1) **and** that wheel's `SelfLocalizationStatus == 1` (frame 1043 byte 4, 2 bits per wheel) **and** no `TPMSError`.
  - Ambient temperature °C = `raw * 0.5 - 40`; raw `>= 254` means not available.
  - `Start_Switch_Status` and `PowerDistributionStatus`: values 2 or 3 mean "on".
- **Confirmed by the 27 Oct 2026 field test**: see section 1b for the full verified signal table (doors, lamps, indicators, hazard, brake pedal, hand brake, driver belt, gear lever P/R/N/D, central lock command, reversing lamp, TPMS, ambient temperature, ODO, power relays). **Frame 564 is not in the first `getElementDataInfo` reply**; it appears only after the service raises `onCanDataNotify` (the first notification in the test came with the first state change). Treat 564 signals as "unknown" until it arrives, and always re-fetch the module that was notified.
- **Still unconfirmed**: `Vehicle_Speed` unit (car was never driven; it read 0), odometer unit (both read 53342), trunk and bonnet switch (not exercised; same polarity as doors in the factory UI code), `KeyPositionStatus` (it toggles whenever a door opens, so do not use it), wipers/windows/passenger belt (the car has no such sensors: the signals never changed).
- `execCmd` / `execExtraCmd`: the code routes commands (range 100–199, "CarSet", CAN module id 1333, 7 data bytes) to a sender registry, but **no concrete sender class is shipped** in this APK `[NOT FOUND]`. Assume it does nothing. This unit's CAN integration is effectively **read-only** `[VERIFIED by absence]`. The factory SRS page also shows the passenger airbag cut-off (`0` = not inhibited, `1` = inhibited) as a **status only**; no control path was found for it.

---

### 3.2 Logic service (`_logic_service`)  [CODE] + [VERIFIED]

**Field test:** `getValue` works for every key listed below (`isAccOn=true`, `isPowerOn=true`, `isInBackState=false`, `isIllon=false`, `isRunning=true`, `getAvmState=0`, `isAuxState=false`, `getSourceId=4099`, `getThirdSourceId=4096`, `getFocusState=1`). `registerLogicCallback` succeeded and events arrived: `onIllStateChanged true/false` when the lights were switched on/off, and `onBackStateChanged true/false` while the gear lever passed through R (including a brief true for ~0.2 s when passing R) and during a real reverse. `Settings.System back_state` and `Shifter_Lever_Signals = 10` were true at the same time.

- Obtain: `ServiceManager.getService("_logic_service")` (listed in `service list`).
- Descriptor `com.logic.common.aidl.ILogicInterface` (standard AIDL):

| Code | Method |
|---|---|
| 1 | `registerLogicCallback(int domain, ILogicCallback cb)` |
| 2 | `unregisterLogicCallback(int domain, ILogicCallback cb)` |
| 3 | `setCmd(String cmd, String value, String extra)` |
| 4 | `String getValue(String key, String extra)` |

- Callback descriptor `com.logic.common.aidl.ILogicCallback`: code 1 `onEventChanged(String event, String value, String extra)`. In this build `registerLogicCallback` registers the callback for **all** events whatever the `domain` argument (declared domains: 1 logic state, 2 source, 3 key, 4 setting).
- `setCmd` implemented: `setSourceId` (value = source id as decimal string), `releaseSourceId`, `closeSourceId`. The constants `setBright`, `setVolume`, `setAutoBright`, `setVolumeChange` exist but are **not handled** by this binder; use the MCU service or `Settings.System` for brightness/volume.
- `getValue` implemented (returns the decimal/boolean text): `getSourceId`, `getThirdSourceId`, `hasFocusById` (extra = id), `getFocusStateById` (extra = id), `getFocusState`, `getAvmState`, `isAccOn`, `isAuxState`, `isIllon`, `isInBackState`, `isPowerOn`, `isRunning`.
- Events (values are strings such as `"true"/"false"` or ints): `onAccStateChanged`, `onPowerStateChanged`, `onBackStateChanged` (reverse gear/parking), `onAvmStateChanged`, `onRunningStateChanged`, `onIllStateChanged` (illumination/lights switch), `onAuxStateChanged`, `onSourceChanged`, `onThirdSourceChanged`, `onFoucsStateChanged`, `receiverFoucsStateChanged`, `onTftStateChanged`, `onBrightChanged`, `onBrightModeChanged`, `onKeyEvent`, `onMediaButtonPressed`.
- Audio source ids: radio 0, music 1, video 2, BT music 3, online music 4, online radio 5, news 6, online program 7, online video 8, SD music 9, SD video 10, AUX 11, CarLife 12, BT phone 13, voice 14, third-party audio app 15, null 4096, off(ARM) 4097, off(MCU) 4098, other app 4099.
- Reverse camera behaviour `[CODE]`: the video switch is done by the hardware/factory logic. While reversing the Logic app writes `Settings.System "back_state" = "true"/"false"` and shows a transparent touch-blocking layer (`BackcarTransParentLayer`). A third-party launcher must not cover the camera view; it can only observe `back_state` / `onBackStateChanged`. The factory logic does not obviously duck other apps' audio in the code read (not verified).

---

### 3.3 MCU service (`zhonghong.mcu`)  [CODE] + [DEVICE]

- Obtain: `ServiceManager.getService("zhonghong.mcu")` (listed in `service list`). Descriptor `android.zhonghong.IMcuService`.
- **Non-standard wire format (no exception header in replies).**

| Code | Call | Request parcel | Reply |
|---|---|---|---|
| 2 | `getTest()` | token | int |
| 3 | `obtainInfo(domain, cmd, in, out)` | token, `writeInt(domain)`, `writeInt(cmd)`, then the raw data of the `in` parcel appended | the `out` parcel data followed by a final `int` result (1 = ok). Read `out` as the first `dataSize-4` bytes; read the result at `dataSize-4` |
| 4 | `sendInfo(domain, cmd, p)` | token, `writeInt(domain)`, `writeInt(cmd)`, raw data of `p` appended | one `int` (1 = ok) |
| 5 | `registDataChangedListener(domain, IDataChangedListener)` | token, `writeInt(domain)`, `writeStrongBinder(listener)` | int |
| 6 | `unregistDataChangedListener(domain, listener)` | same | int |

  Listener descriptor `android.zhonghong.IDataChangedListener`: code 2 `notify(int domain, int cmd, int arg, Parcel data)`.
- **JSON conventions (all current settings/state live behind these):**
  - *Write*: `sendInfo(domain, 1, p)` where `p` contains `writeByteArray(jsonBytes)` and the json is `{"KEY": value}` (one or more keys).
  - *Read all keys of a domain*: `obtainInfo(domain, 1, in, out)` with `in = writeByteArray("{\"all\":0}")`. The `out` data is: `int len`, `int type`, then `len` bytes; the text is the first `len-1` bytes (trailing NUL), and it is a JSON object.
  - *Read one key*: same but `in` = `{"KEY":0}`; the text returned is the value of that key.
  - Domain ids: **1** radio, **2** settings (audio/display), **3** system state, **4** MCU hard-key info (radio seek-left/right commands are also sent here), **5** CAN info (MCU level), **6** customer info, **7** ATest, **8** offline config (`obtainInfo(8,0)` with `{"all":0}`), **4608** system key (cmd 4352 register key, 4353 clean key), **4864** touch.
- **Domain 2 (settings) keys `[CODE]`** (read and write by the same key): `SYS_VOL`, `SYS_MUTE`, `SYS_BEEP`, `SYS_BEEPVOL`, `SYS_BTVOL`, `SYS_TTSVOL`, `SYS_GPSVOL`, `SYS_TBOXVOL`, `defvol`, `carspeed_volume` (speed-dependent volume), `EQ40`, `EQ80`, `EQ500`, `EQ1k`, `EQ5k`, `EQ16k`, `bass`, `SYS_MID`, `treb`, `SYS_LOUD`, `audiofade`, `audiobal`, `3D_AUDIO_SW`, `SYS_AUDIOMODE`, `FM_LIMITER`, `AM_LIMITER`, `brightness`, `backlight`, `vicebacklight`, `setautobrighton`, `TFT1`, `TFT2`, `SYS_TIME12H`, `LANG_SEL`, `UNLOCK_STATE` (read-only door unlock state), `WELCOME_REQ`, `PRODUCT_INFO`, `CAN_COMPANY`, `SYS_FLAG`, `SYS_SYSFLAG2`, `SYS_ARMSAVE1..3`, `RRS_AUTO_LEVEL`, `RRS_RTURN_EN`, `RRS_AUTO_REQ`. The full list of proxy methods and domain/command numbers is in Appendix B.
- **Domain 3 (system) keys** `[CODE]`: `ACC_STATE`, `POWER_STATE`, `BACK_SIGNAL` (reverse), `ILL_STATE`, `SYSREADY`, `MCU_SOURCE` (read; write via `setMcuSource`), `MCU_STATE`, `BPOWER_ON`, `BRIGHT_TURNER`, `VICEDIRVER_HEADPHONE`, `NEED_SHOWDIALOG`, `MCU_TIME`, `SYS_TIME`. Several action methods exist (power key, reset key, beep, update state, mute 1 s, navi-voice notification, animation notification) sent as JSON to domain 3; see Appendix B.
- **Domain 1 (radio) `[CODE]`:**
  - Read all: `{"all":0}` -> JSON with `getfreq` (current frequency), `freq`, `scan`, `loc`, `st` (stereo), `stind`, `aps` (auto-preset search), `RADIO_AREA`, `RADIO_SREACH_STATE`, `RADIO_PLAYSTATE`, `AUX_PLAYSTATE`, signal level `signlevel`, `HAVESIG`, RDS keys `RADIO_NAME` (station name/PS), `RADIO_TEXT`, `PTY`, `TP`, `TP_INFO`, `TA_MODE`, `RDS_ON_OFF`, `RDS_TA_MODE`, `AF`, `EON`, `INTRO`, `LAGEL_FREG`.
  - Set frequency: `{"freq": (band << 14) | (freq & 16383)}`, band `3` = FM, `0` = AM (the factory rejects other values). FM values are in 10 kHz units (e.g. 9500 = 95.0 MHz), AM in kHz.
  - Seek next/previous station: domain **4**, `{"RADIO_SREACH_R":0}` / `{"RADIO_SREACH_L":0}`. Stop scan: domain 1, `{"stop_scan":0}`. Scan: `{"scan":0}`. Play state: `{"RADIO_PLAYSTATE": n}`. AUX play state: `{"AUX_PLAYSTATE": n}`. Plus loc/stereo/APS toggles, RDS on/off, PTY, TA/AF clicks, factory radio area (Appendix B).
- Hard keys (domain 4) and system keys (domain 4608): the factory UI registers listeners to receive steering-wheel / panel key events (`McuHardKeyInfo`, `SystemKeyInfo` parcels). Exact parcel layouts: see decompiled `McuHardKeyInfo`/`SystemKeyInfo` (not needed unless implementing steering-wheel buttons).
- **Field test `[VERIFIED]`:** `getTest() = 100`. `{"all":0}` works for domains 1, 2, 3 (reply layout: `ok`, `len`, `type=1`, JSON text). Keyed reads work for keys that exist (`SYS_VOL`, `SYS_MUTE`, `ACC_STATE`, `BACK_SIGNAL`, `ILL_STATE`, `MCU_SOURCE`); a key that is not in the JSON returns `ok=0`. The read **without** an input parcel returns `ok=0`: always send the JSON request. Observed `SYS_VOL` followed the volume change (9 then 14) and matched the `notifyVOL` events 10..14.
- **Domain 2 keys actually present on this unit:** `AM_LIMITER`, `FM_LIMITER`, `SYS_ARMSAVE1..3`, `SYS_AUDIOMODE`, `SYS_BEEP`, `SYS_BEEPVOL`, `SYS_BTVOL`, `SYS_GPSVOL`, `SYS_TTSVOL`, `SYS_LOUD`, `SYS_MID`, `SYS_MUTE`, `SYS_VOL`, `SYS_USER_BASS`, `SYS_USER_MID`, `SYS_USER_TREB`, `bass`, `treb`, `audiobal`, `audiofade`, `defvol`, `carspeed_volume`, `backlight` (= 80, screen backlight), `setautobrighton` (true), `TFT1`, MCU clock `SYS_YEAR/MONTH/DAY/HOUR/MINUTE/SECOND`, `SYS_TIME12H`, `SYS_FLAG`, `SYS_SYSFLAG2`, `mcuver`, `canver`, `VIN_DATA`, `TUID_DATA` (identifier arrays: do not store or log). **Not present:** the six-band `EQ40..EQ16k` keys, `brightness`, `SYS_TBOXVOL`. The EQ on this unit is three-band (`bass`/`mid`/`treble`, 0..14, centre 7).
- **Domain 3 keys present:** `ACC_STATE`, `BACK_SIGNAL`, `BPOWER_ON`, `CAR_RUN`, `ILL_STATE`, `MCU_SOURCE` (15 observed), `MCU_STATE`, `NEED_SHOWDIALOG`, `POWER_STATE`, `RADAR_BEEP`, `RESERVED_BLOCK`, `SOURCE_VAILFLAG`.
- **Domain 1 (radio) with the radio off:** `{"class":"radio","result":{"HAVESIG":false,"RADIO_AREA":0},"status":"off"}`. The JSON with the radio playing (frequency etc.) was not captured `[UNTESTED]`.
- **Writes (`sendInfo`) were never tried** `[UNTESTED]`. The factory UI, the head-unit buttons and the steering-wheel keys already control volume, brightness and EQ, so a launcher does not need writes. If writes are wanted, test first by writing a key to its **current** value.

---

### 3.4 Bluetooth, phone book, call state  [CODE]

**A. Control service `zhbt_service` - `[VERIFIED] NOT AVAILABLE` on this unit.**
`ServiceManager.getService("zhbt_service")` returned null in all three snapshots, including with the car on and a phone connected (`bt_connected=true`). The factory code that would register it is in the BT app, but it is not running as a registrable service here. The command and key tables below describe the protocol only for reference (Appendix C); **do not plan on answer / reject / dial / BT-music-key control from a custom UI.** Use the fallbacks:
- Answer / reject / hang up: the factory call screen appears by itself on an incoming call. Do not build a duplicate. (The user confirms answering and rejecting work on the factory UI.)
- Dial: open the factory dialer with `android.bluetooth_btdial`. That activity only reads the action (dial vs settings); it takes **no number extra**, so numbers are typed in the factory screen.
- BT music: open `android.bluetooth_btmusic`.
- Call state in a custom UI: `sys.btcall` (`true` during a call), the system-state broker callback `notifyBTPhoneState(int)` (values seen during an outgoing call that was ended: 0, 2, 0, 2, 7, 3) and `getBluetoothInCallState()`.

For reference, the unreachable interface was: descriptor `com.zhonghong.bluetooth.aidl.IBtCtrlInterface` (1 `setCmd(int,String,String)`, 2 `getValue(String,String)`, 3 `registerCallback(int,IBtDataCallback)`, 4 `unregisterCallback`), callback `IBtDataCallback.onDataChanged(int domain, String json)`, commands answer 29, hang up 30, dial 34, etc., call states 0 talking, 1 hold, 2 outgoing, 3 alerting, 4 incoming, 5 waiting, 7 terminated.

**B. Content provider `content://com.zhonghong.bluetooth.provider.btinfo`** (authority `com.zhonghong.bluetooth.provider.btinfo`, exported, no permissions):
- `/btbase` -> columns `id, state, devname, power, signal, battery, talkname, talknum, micincar, micmute`
- `/btmusic` -> `id, title, artist, album, duration, btmusicstate`
- `/btcontacts` -> `id, name, num`
- `/ctrlbt` update channel (`enable_bt`).
  **`[VERIFIED]` empty:** `btbase` has one row where only `id` and a 4-character `power` value are set (every other column is null, even while a phone is connected); `btmusic` has one all-null row; `btcontacts` has 0 rows. Do not use these tables.

**C. Content provider `content://com.car.phone_data`** (app `com.car.phoneprovider`, exported, no permissions):
- `/contacts` and `/contacts_favorite` -> `_id, address, name, number, pinyin, storage, type`
- `/call_log` -> `_id, active_start_time, address, end_time, name, number, start_time, timestamp, type` (type codes: 5 missed, 6 received, 7 dialed)
- `/force_contactes` and `/force_calllog` trigger a refresh.
- **`[VERIFIED]`:** `contacts` and `call_log` return a **null cursor** from a normal app, and `contacts_favorite` is empty. The factory UI on this car shows no contact names or call history either, so **contacts and call history are not available**; do not build features on them.

**D. Cheap signals that need no binder `[VERIFIED]`:**
- System property `sys.btcall` = `"true"` while a BT call is active, `"false"` otherwise (set by the BT app).
- `Settings.System`: `bt_connected`, `key_bluetooth_state`, `key_signal_state`, `key_battery_state` (written by the factory status-bar SDK).
- `SystemStateInterface` (3.6): `getBluetoothConnectState()`, `getBluetoothInCallState()` and callbacks `notifyBTState`, `notifyBTPhoneState(int)`.
- Broadcast `com.zhonghong.bluetooth.call_last_number` is handled by an exported receiver in the BT app (`UpdateSystemReceiver`; the name suggests "call last number", behaviour not read in detail).

**E. Factory screens:** actions `android.bluetooth_btdial` (dialer), `android.bluetooth_btsettings` (BT settings), `android.bluetooth_btmusic` (BT music) on `com.zhonghong.bluetooth`.

**F. Underlying stack:** the BT app embeds the Nforetek stack (`com.nforetek.bt.aidl.*`, `UiCommand` and callbacks). It is an internal detail of the BT app, bound only by it.

---

### 3.5 Media: USB music, USB video, library, radio, AUX  [CODE]

**USB music service** `[VERIFIED]` bind, descriptor, `isPlaying`, `getTitle`, `getArtist`, `getAlbum` and `registerDataChange` all worked (commands were not exercised because nothing was playing) — bind `com.zhonghong.yzmusic` / `com.zhonghong.music.model.service.UsbMusicService` (action `com.zhonghong.usb_music_action`, exported). Descriptor `com.zhonghong.mediaaidl.usbmusic.IUsbMusicAidlInterface` (standard AIDL):
1 `registerDataChange(IUsbMusicAidlListener)`, 2 `unregisterDataChange`, 3 `boolean isPlaying()`, 4 `String getTitle()`, 5 `String getAlbum()`, 6 `String getArtist()`, 7 `setMusicSource()` (switch the audio source to USB music), 8 `next()`, 9 `prev()`, 10 `playPause()`, 11 `play()`, 12 `pause()`.
Listener `com.zhonghong.mediaaidl.usbmusic.IUsbMusicAidlListener`: 1 `onId3(String title, String artist, String album)`, 2 `onPlayState(boolean playing)`.
There is no "play this track" call; choosing a specific file is done in the factory screen (`com.zhonghong.usb_music_list`).

**USB video service** — `com.zhonghong.yzvideo.service.VideoService` (action `com.zhonghong.usb_video_action`, exported). Interface `com.zhonghong.mediaaidl.video.IVideoAidlInterface`: 1 `registerDataChange(IVideoAidlListener)`, 2 `unregisterDataChange`, 3 `isPlaying`, 4 `getTitle`, 5 `setVideoSource`, 6 `next`, 7 `prev`, 8 `playPause`, 9 `play`, 10 `pause`. **`[VERIFIED] NOT RESPONDING`:** `bindService` returned true but `onServiceConnected` never fired within 5 s. Treat the video service as unavailable; launch the factory video screen (`com.zhonghong.video_activity`) and read the library from the media provider.

**Radio AIDL / BT-music AIDL** `[NOT FOUND]`: `IRadioAidlInterface` (`getFreq`, `isAMBand`, `isPlaying`, `setRadioSource`, `playPause`, `nextStation`, `prevStation`, `nextStep`, `prevStep`, `nextSearch`, `prevSearch`, `fMAMSwitch`) and `IBtMusicAidlInterface` (title/artist/album/play/pause/next/prev/`setBtMusicSource`) are defined in the music app, but the packages that would serve them (a radio service, `com.zhonghong.bluetooth.BtMusicService`) are not in the provided APKs. The launcher/logic code starts a service with action `com.zhonghong.radio.radioservice.action` (extra `command`), which does not exist in the provided APKs either. **Control the radio through MCU domain 1 (section 3.3).**

**Media library provider** `[VERIFIED]` (audio returned 10 rows, `id3` 10 rows, `video`/`image`/`txt` 0 rows, `scan_state` state = 2) `content://com.zhonghong.media` (exported, no permissions), tables:
`audio(_id, path, name, parent_path, title, album, artist)`, `id3(path, title, album, artist, name, parent_path, uuid, file_size)`, `video(_id, path, name, parent_path)`, `image(_id, path, name, parent_path)`, `txt(_id, path, name, parent_path)`, `status(path, state)`; URI patterns `audio`, `audio/*`, `video`, `video/*`, `image`, `image/*`, `txt`, `txt/*`, `id3`, `scan_state`, `scan_state/*`.

**AUX** — activity `com.zh.auxin` (VIEW). Source id 11 in Logic; MCU key `AUX_PLAYSTATE` (domain 1). `Settings.System system_state_aux`.

**Picture viewer** — `com.zhonghong.yzpicture` (also answers `com.zhonghong.usb_music_activity`).

---

### 3.6 System-state broker (`com.zhonghong.aidlserver`)  [CODE]

- Bind `com.zhonghong.aidlserver` / `com.zhonghong.aidlserver.service.SystemStateService` (action `com.zhonghong.aidlserver.service.SystemStateService`, exported, process `:systemstate`). A second service `SystemStateService2` serves the generic interface.
- `com.zhonghong.aidlib.state.SystemStateInterface`: 1 `registerCallBack(SystemStateCallBack)`, 2 `unregisterCallBack`, 3 `int getTuidNumber()`, 4 `boolean getNetworkState()`, 5 `boolean getBluetoothConnectState()`, 6 `boolean getBluetoothInCallState()`.
- `com.zhonghong.aidlib.state.SystemStateCallBack` (callback): 1 `notifyHeadlampState(boolean)`, 2 `notifyVOL(int)`, 3 `notifyBTPhoneState(int)`, 4 `notifyACC(boolean)`, 5 `notifyBTState(boolean)`, 6 `notifyNetworkState(boolean)`, 7 `notifyBackState(boolean)`, 8 `notifyPowerState(boolean)`.
- `SystemStateInterface2` (generic category/type store): `registerCallback(int, StateCallback)`, `registerServiceProvider(int, ServiceProvider)`, `getBooleanInfo/getIntInfo/getStringInfo(int,int)`, `setBooleanInfo/setIntInfo/setStringInfo(int,int,value)`, `notify*Info`. It forwards to whichever app registered as provider for the category, so it only returns data if a provider registered `[UNTESTED]`. Known type ids (`ZServiceProviderTypes`): ACC 1001, back-car 1002, power 1003, volume 1004, mute 1005, headlamp 1006, main TFT backlight 1007 (second TFT 1008), illumination-on 1009, main TFT brightness 1010 (second 1011), brake warning 1012; Bluetooth: connect state 2001, phone state 2002, music state 2003, HFP 2004, A2DP 2005; network connect state 3001, TBOX UUID 3002; multiscreen 4001-4005 (vice screen state, screen lock, main/vice app name, headphone state). Categories: system 1000, Bluetooth 2000, network 3000, multiscreen 4000.
- **`[VERIFIED]`:** bind works; `getNetworkState=false`, `getBluetoothConnectState=true`, `getBluetoothInCallState=false`, `getTuidNumber` call works (value is an identifier: never store or log it), `registerCallBack` works. Events seen: `notifyBackState` 1/0 (reverse), `notifyVOL` 10..14 (volume changes), `notifyBTPhoneState` 0/2/3/7 (call). `SystemStateService2` binds and reports descriptor `...SystemStateInterface2`.
- Value for a quick implementation: use this broker's callbacks for back/volume/phone state instead of polling.

---

### 3.7 Other services / apps

| App | Component | What it offers |
|---|---|---|
| `com.zhonghong.update` | `UpdateService` (action `com.zhonghong.ctrl_update`, exported); also system service `zhupdate_service` (`com.zhonghong.update.aidl.IUpdateInterface`) | system update control. **Do not use** from a launcher |
| `com.zhonghong.screensaver` | `ScreenService` (action `com.zhonghong.screensaver.ScreenService`, exported) | start/stop the screensaver (started as a service; extras not analysed) |
| `com.zh.settings` | `SetService` (action `com.zhonghong.action.set`) + activities Sound/System/Wifi/Display/Field/EQ | system settings screens |
| `com.zhonghong.mcu` | `McuUpdateService`, `McuCtrlServer` | MCU firmware update only. **Do not use** |
| `com.zh.test` | `CmdService`, boot receiver | factory test tool, not exported |
| `com.zhonghong.mediaconfigtool`, `com.zhonghong.uuidtool` | USB receivers | factory tools |

---

### 3.8 Intents and broadcasts

**Activities (use `startActivity(new Intent(action))` or explicit component):**

| Action / component | Opens |
|---|---|
| `com.zhonghong.intent.action.music`, `com.zhonghong.usb_music_activity` | USB music player |
| `com.zhonghong.usb_music_list` | USB music track list |
| `com.zhonghong.video_activity` | USB video |
| `com.zh.yzradio/.MainActivity` (VIEW) | Radio |
| `android.bluetooth_btdial` / `android.bluetooth_btsettings` / `android.bluetooth_btmusic` | BT dialer / BT settings / BT music |
| `com.zhonghong.action.set` | system settings; `com.zhonghong.action.eq` = equalizer |
| `com.zhonghong.carsetting/.MainActivity` | car settings (TPMS etc.) |
| `com.zh.auxin/.MainActivity` | AUX-in |
| `com.zhonghong.launcher.MEDIA_ACTION`, `com.zhonghong.launcher.NAVI_ACTION` | factory launcher media / navigation pages |
| `com.zhonghong.update/.MainActivity`, `com.zh.test/.MainActivity`, `com.zhonghong.logic/.MainActivity` | update / factory test / logic status |
| `com.estrongs.android.pop`, `com.xbrowser.play`, `com.chartcross.gpstest`, `com.android.settings` | file manager (also the way to install APKs), browser, GPS test, Android settings |

**Broadcasts the Logic app listens for (any app can send them)** `[CODE]`:
- `com.zhonghong.logic.close_screen` -> turns the display (TFT) off.
- `com.zhonghong.android.key` with int extra `data = 4608` -> system beep.
- `action.radio.RDS_TRAFFIC` -> wakes/opens the screen for RDS traffic announcements.
- It also reacts to `android.media.VOLUME_CHANGED_ACTION` and master-mute changes.
Other broadcast/action names seen in the code (for completeness): `com.zhonghong.zuiserver.BROADCAST`, `com.zhonghong.LaunchAction`, `zhonghong.intent.action.START_UPDATE` / `END_UPDATE`, `com.polstar.navi.COORDINATE`, and the BT app's `com.zhonghong.bluetooth.call_last_number`. Packages referenced by the factory launcher but not installed on this unit: `com.zhonghong.avm` (surround camera), `com.zhonghong.carlife`, `com.zhonghong.power`, `com.zhonghong.phonelink`, `com.zhonghong.ledscreen`, `com.zhonghong.expandapps`.

---

### 3.9 Settings.System keys and system properties (readable by any app)

`Settings.System` (read; written by factory apps): `back_state` (`"true"` while reversing), `screen_brightness`, `screen_brightness_mode`, `navi_mix_value` (navigation-mix ducking value, default 10), `radio_rds_enbale`, `system_state_aux`, `bt_connected`, `key_bluetooth_state`, `key_signal_state`, `key_battery_state`, `key_type_car_level`, `time_12_24`, and the maintenance-reminder keys `CAR_ENGINE_OIL_CHANGE_TYPE`/`_REMAIN_TYPE`, `CAR_ENGINE_OIR_FILTER_CHANGE_TYPE`/`_REMAIN_TYPE`, `CAR_ENGINE_AIR_FILTER_CHANGE_TYPE`/`_REMAIN_TYPE`, `CAR_FUEL_FILTER_CHANGE_TYPE`/`_REMAIN_TYPE`. `Global`: `auto_time`, `auto_time_zone`, `auto_time_gps`.

System properties of interest: `sys.btcall` (BT call active), `sys.carlifevr`, `sys.stream.duckvalue` (duck level for streams), `zh.navi.pidlist`, `persist.sys.default.launcher`, `persist.sys.default_navi`, `persist.sys.default_voice_call`, `persist.sys.max_*`, `persist.phone.easyconnect`, `CarSettingKey` (= `0` on this unit), `ro.mcu.baudRate`, `ro.kernel.android.{gps,mcu,bt}`.
Read a property with `Class.forName("android.os.SystemProperties").getMethod("get", String.class, String.class)`.

## 4. Other usable features found in the apps (beyond the obvious)

Each line: feature — where it comes from — how to use it.

**Vehicle data (read-only, via CAN service, section 3.1)**
- Vehicle speed from CAN (frame 1218): potentially better than GPS (works in tunnels), but its unit is unverified. Validate it against GPS on the first drive before using it (rule in section 1b-C).
- Gear / shifter lever signals and transmission warnings (frame 1218): transmission warning lamp, OBD warning flag, clutch/transmission temperature warnings, winter mode, overall ratio.
- Two odometers (BCM 800 and ICM 1219).
- Full lamp/indicator state (frame 963 has per-lamp status incl. daylight, roof lamp, brake lamp, reversing lamp, corner lamps; frame 564 has the switch states, hazard).
- Central lock command, remote lock/unlock signals, anti-theft state, key battery, PEPS/keyless status, steering lock status. (Wipers and windows exist as signals but **this car has no such sensors**: they never changed in the test. `KeyPositionStatus` toggles with door events: do not use.)
- Airbag ECU fault flag, passenger airbag cut-off **status** (0 = not inhibited, 1 = inhibited; status only, no control), crash flag, driver belt lock recognition (frame 722). Passenger belt: no sensor on this car.
- TPMS per wheel: pressure, temperature, status, leak, sensor error, sensor battery.
- Ambient temperature.
- Service-reminder values written to `Settings.System` (oil, oil filter, air filter, fuel filter): readable without binder.

**System / power / screen**
- ACC, power, illumination (headlight switch), reverse, AVM, "running" states with callbacks (Logic or SystemState broker) — use for automatic day/night, auto-wake and parking behaviour.
- Screen off on demand: broadcast `com.zhonghong.logic.close_screen`.
- System beep: broadcast `com.zhonghong.android.key` with `data=4608`.
- Brightness / backlight / TFT on-off / auto-brightness via MCU domain 2 (`brightness`, `backlight`, `TFT1`, `setautobrighton`) or `Settings.System screen_brightness`.
- Volume, mute, EQ (6-band), bass/mid/treble, loudness, balance/fade, 3D audio, beep volume, navigation/TTS/GPS/BT/TBOX volumes, speed-dependent volume (`carspeed_volume`) via MCU domain 2. Reading `SYS_VOL` and `SYS_MUTE` also tells the current level.
- Custom audio streams: `STREAM_NAVI = 10`, per-stream maximum 30 (`persist.sys.max_*`).
- Audio source arbitration (Logic): query who has focus, request/release a source id.

**Media / radio / phone**
- Radio: tune, seek, scan, stop, area, RDS (station name, radio text, PTY, TP/TA/AF/EON), stereo/loc/APS flags, signal level (MCU domain 1/4).
- USB music: now playing + controls (service), full library (provider), launch the factory list.
- USB video control (service).
- Pictures viewer, AUX-in.
- Bluetooth (what is really reachable): connected flag, phone signal and battery level (`Settings.System`), call-active flag (`sys.btcall`), call-state events (system-state broker), plus the factory dialer / BT music / BT settings screens. Not reachable on this unit: answer/hang up/dial from a custom UI, BT music keys, contacts, call log.
- Phone mirroring (`net.easyconn`, `persist.phone.easyconnect=true`) and CarLife (`ID_CARLIFE=12` source id; the CarLife app itself is not installed).

**Utilities already installed on the unit**
- ES File Explorer, X Browser, GPS Test, Android Settings, package installer — launchable only from a custom launcher; they are the unit's route to files, web and APK installation.
- Navigation apps: Target (`polnav6`), Neshan, Google Maps; `Settings.System navi_mix_value` = how loud music stays under navigation voice; `zh.navi.pidlist` = pids of navigation processes.
- Factory screens for car settings, EQ, system settings, update, factory test (`com.zh.test`, `com.zhonghong.uuidtool`).

**Hard keys / steering wheel**
- MCU domain 4 (hard keys) and 4608 (system keys) deliver panel and steering-wheel key events to registered listeners; Logic emits `onKeyEvent` / `onMediaButtonPressed` (also consumed by the factory UI). Steering-wheel learning exists (`setWheelKeyStudy`, MCU domain 2) `[UNTESTED]`.
- Standard Android media key events (`KEYCODE_MEDIA_*`) are presumably also generated for some buttons `[UNTESTED]`.


## 5. Verification status and open gaps

**Verified on the real unit (section 1b):** CAN service access and all signals in 1b-A; Logic service reads and events; MCU read-all and keyed reads; system-state broker getters, callbacks and events; USB-music bind and reads; media provider; overlay window; `sys.btcall`; Bluetooth/`Settings.System` status keys; all factory intents resolve; absence of `zhbt_service`; unusable BT/contacts/call-log providers; unresponsive video service.

**Verified by reading factory code (`[CODE]`), formats reliable:** every AIDL descriptor and transaction code listed; CAN field map (Appendix A); MCU domains, JSON keys and wire format; provider schemas; system properties and `Settings.System` keys.

**Still unverified (use the fallbacks in 1b-C):**
1. Writing to the MCU (`sendInfo`): volume, brightness, EQ.
2. USB-music control commands (play/pause/next/prev) and its events while playing.
3. Radio JSON while the radio is playing (frequency, station name, signal keys).
4. `Vehicle_Speed` unit and the odometer unit (car was stationary; both odometers equal 53342).
5. Trunk and bonnet switch values.
6. The beep broadcast `com.zhonghong.android.key` (sent; the owner did not report whether a beep was heard) and the screen-off broadcast (not sent).
7. The radio-on and incoming-call (as opposed to dialled-call) event sequences; `btPhoneState` values were seen only for an outgoing call that was ended (0, 2, 3, 7) and are not mapped to named states.
8. Steering-wheel and hard-key event delivery to a third-party app.

**Not found / not available:** `zhbt_service`; a working video service; BT provider data; contacts and call log; servers for `IRadioAidlInterface`, `IBtMusicAidlInterface`, `KeyInterface`, `ScreenInterface`, `NaviInterface`, `ExtraDeviceInterface`; CAN control commands (no sender shipped); six-band EQ keys; `brightness` key; the AVM / CarLife / power / phonelink apps; wiper, window and passenger-belt sensors.

**Pitfalls**
- Re-fetch the CAN module on every `onCanDataNotify`, and treat frame 564 as unknown until it arrives.
- Indicator lamp signals blink; do not read them once and assume steady state.
- Fog switch signals are momentary pulses; use the lamp status signals.
- `targetSdkVersion 22` is deliberate so location, storage, overlay and boot permissions are granted at install on a unit with no permission UI.
- 32-bit ABIs only. Do not read raw serial ports; do not call the update or MCU-update services.
- Do not log or store `TUID_DATA`, `VIN_DATA`, the TUID number or any device identifier.
- The factory UI already provides the call screen and the reverse overlay; do not duplicate them.
- Writing to USB root is not allowed for a normal app; use `/storage/udiskN/Android/data/<pkg>/files`.

---

## Appendix A — Complete CAN signal map (auto-extracted from the factory decoder)

Format: `Signal  byte N  bit B  len L` — `N` is the data-byte index (add 3 for the array index), `B` the start bit inside the byte, `L` the bit length, little-endian across bytes. Frames: CarStatus = 564 and 577, CarSet = 963, 800, 722, 1219, 1218, TPMS = 1042 and 1043, AmbientTemp = 695. Semantics that are confirmed are listed in section 3.1; everything else is the raw signal name from the factory decoder.

```
## CarStatusInfo
  -- frame 564
   LH_Indicator_Switch_Status                   byte0  bit0  len1
   RH_Indicator_Switch_Status                   byte0  bit1  len1
   Position_Lamp_Switch_Status                  byte0  bit2  len1
   Low_Beam_Switch_Status                       byte0  bit3  len1
   High_Beam_Lamp_Switch_Status                 byte0  bit4  len1
   Front_Fog_Lamp_Switch_Status                 byte0  bit5  len1
   Rear_Fog_Lamp_Switch_Status                  byte0  bit6  len1
   Horn_Switch_Status                           byte0  bit7  len1
   Front_LH_Door_Switch_Status                  byte1  bit0  len1
   Front_RH_Door_Switch_Status                  byte1  bit1  len1
   Rear_LH_Door_Switch_Status                   byte1  bit2  len1
   Rear_RH_Door_Switch_Status                   byte1  bit3  len1
   Trunk_Lid_Switch_Status                      byte1  bit4  len1
   Bonnet_Switch_Status                         byte1  bit5  len1
   Wash_Pump_Switch_Status                      byte2  bit0  len1
   Wiper_INT_Switch_Status                      byte2  bit1  len1
   Wiper_Low_Speed_Switch_Status                byte2  bit2  len1
   Wiper_High_Speed_Switch_Status               byte2  bit3  len1
   Wiper_Auto_Switch_Status                     byte2  bit4  len1
   Rear_Wiper_Switch_Status                     byte2  bit5  len1
   Rear_Wash_Pump_Switch_Status                 byte2  bit6  len1
   Front_Wiper_Return_Switch_Status             byte2  bit7  len1
   Start_Switch_Status                          byte3  bit0  len2
   AC_Switch_Status                             byte3  bit2  len1
   Screen_Heater_Switch_Status                  byte4  bit0  len1
   Brake_Pedal_Switch_Status                    byte4  bit1  len1
   Hand_Brake_Switch_Status                     byte4  bit2  len1
   Reverse_Gear_Switch_Status                   byte4  bit3  len1
   Driver_Seat_Belt_Switch_Status               byte4  bit4  len1
   Passanger_Seat_Belt_Switch_Status            byte4  bit5  len1
   Passanger_Load_Cell_Switch_Status            byte4  bit6  len1
   Remote_Status                                byte5  bit0  len2
   Global_Lock_Unlock_Status                    byte5  bit2  len2
   FLH_Actuator_Switch_Status                   byte5  bit4  len1
   FRH_Actuator_Switch_Status                   byte5  bit5  len1
   Master_Lock_Switch_Status                    byte5  bit6  len1
   Anti_theft_Status                            byte5  bit7  len1
   LH_Window_Switch_Status                      byte6  bit0  len2
   RH_Window_Switch_Status                      byte6  bit2  len2
   Hazard_Switch_Status                         byte7  bit0  len1
   Trunk_Lid_Command_Switch_Status              byte7  bit1  len1
   Indicator_Lamps_Command                      byte7  bit2  len2
   Shock_Sensor_Command                         byte7  bit4  len1
   Resons_For_Lock_change_status                byte7  bit5  len2
  -- frame 577
   PowerDistributionStatus                      byte0  bit0  len2
   PKE_RKE_UnlockSignal                         byte0  bit2  len2
   PKE_RKE_LockSignal                           byte0  bit4  len2
   PKE_RKE_LuggageUnlockSignal                  byte0  bit6  len2
   BrakePedalStatus                             byte1  bit0  len2
   RemoteWindowUpSignal                         byte1  bit2  len1
   RemoteWindowDownSignal                       byte1  bit3  len1
   SearchCarSignal                              byte1  bit4  len1
   KeyInCarAlarmSignal                          byte1  bit5  len1
   KeyBatteryStatus                             byte1  bit6  len1
   RemoteAlarmCommand                           byte2  bit0  len4
   KeyPositionStatus                            byte2  bit4  len3
   Key_Position_Light_Command                   byte3  bit0  len3
   UnlockModeTransitionSignal                   byte3  bit3  len1
   UnallowStartupSignal                         byte3  bit4  len4
   PERequestButtonSignal                        byte4  bit0  len2
   Anti_theft_status_indication                 byte4  bit2  len2
   PEPS_Fail_Status                             byte4  bit4  len1
   PEPS_Anti_theft_Command                      byte4  bit5  len1
   IGSwitchSteerlockStatus                      byte4  bit6  len2
   IGSwitchSteerlockFaultBit                    byte5  bit0  len1
   ESCLLock_UnlockFailIndication                byte5  bit1  len2
   PEPS_AlarmStatus                             byte5  bit3  len2
   PEPS_ICMAlarm                                byte6  bit0  len4
   PEPS_ICMInd                                  byte6  bit4  len4
   ACCRelaySt                                   byte7  bit0  len1
   IG1RelaySt                                   byte7  bit1  len1
   IG2RelaySt                                   byte7  bit2  len1
   StartRelaySt                                 byte7  bit3  len1
## CarSetInfo
  -- frame 963
   Left_Indicator_Lamp_Status                   byte0  bit0  len2
   Right_Indicator_Lamp_Status                  byte0  bit2  len2
   Position_Lamp_Status                         byte0  bit4  len2
   Low_Beam_Status                              byte0  bit6  len2
   High_Beam_Status                             byte1  bit0  len2
   Front_Fog_Lamp_Status                        byte1  bit2  len2
   Rear_Fog_Lamp_Status                         byte1  bit4  len2
   Daylight_Status                              byte1  bit6  len2
   Roof_Lamp_Status                             byte2  bit0  len2
   Brake_Lamp_Status                            byte2  bit2  len2
   Reversing_Lamp_Status                        byte2  bit4  len2
   Left_Corner_Lamp_Status                      byte2  bit6  len2
   Right_Corner_Lamp_Status                     byte3  bit0  len2
   Vehicle_Type                                 byte3  bit2  len4
   Front_Wiper_Output_Status                    byte4  bit0  len3
   Rear_Wiper_Output_Status                     byte4  bit3  len2
   Wash_Output_Status                           byte4  bit5  len2
   Horn_Relay__Status                           byte5  bit0  len2
   Screen_Heater_Relay__Status                  byte5  bit2  len2
   Isolator_Relay__Status                       byte5  bit4  len2
   Veco_Relay__Status                           byte5  bit6  len2
   Door_Lock_Output__Status                     byte6  bit0  len2
   Trunk_Output__Status                         byte6  bit2  len2
   Buzzer_Output__Status                        byte6  bit4  len2
   Reaview_Mirror_Output__Status                byte6  bit6  len2
   Hazard_LED_Output_Status                     byte7  bit1  len1
   Master_Lock_LED_Output_Status                byte7  bit2  len1
   Child_Lock_LED_Indicator_Output_Status       byte7  bit3  len1
   Anti_theft_Indicator_Output_Status           byte1  bit4  len1
   Start_Stop_Amber_LED_Output_Status           byte1  bit5  len1
   Start_Stop_Green_LED_Output_Status           byte1  bit6  len1
  -- frame 800
   ODO_calculated_By_BCM                        byte0  bit0  len16
  -- frame 722
   Checksum_of_message_Airbag_1                 byte0  bit0  len8
   The_crash_intensity_describes_whether_there_is_a_crash byte1  bit0  len3
   Driver_seatbelt_lock_recognition             byte2  bit0  len2
   Passenger_seatbelt_lock_recognition          byte2  bit2  len2
   Airbag_counter_for_live_check                byte4  bit4  len4
   Error_flag_of_the_airbag_ECU                 byte5  bit1  len1
   Passenger_airbag_cut_off_status              byte5  bit2  len1
  -- frame 1219
   ODO_calculated_By_ICM                        byte0  bit0  len16
  -- frame 1218
   Torque_Reserve_Request                       byte0  bit0  len8
   Transmission_EOL_Status                      byte1  bit0  len8
   Fuel_Cut_Off_Assist_Flag                     byte1  bit1  len1
   Shifter_Lever_Signals                        byte1  bit2  len4
   Winter_Mode_Status                           byte1  bit6  len1
   Transmission_Warning_Lamp                    byte2  bit0  len1
   OBD_Warning_Flag_Request                     byte2  bit1  len1
   Clutch_Temperature_Warning                   byte2  bit2  len1
   Transmision_Temperature_Warning              byte2  bit3  len1
   Overal_Ratio                                 byte3  bit0  len16
   Vehicle_Speed                                byte5  bit0  len8
## TpmsInfo
  -- frame 1042
   FLTyrePressureValue                          byte0  bit0  len8
   FRTyrePressureValue                          byte1  bit0  len8
   RLTyrePressureValue                          byte2  bit0  len8
   RRTyrePressureValue                          byte3  bit0  len8
   FLTyreTemperatureValue                       byte4  bit0  len8
   FRTyreTemperatureValue                       byte5  bit0  len8
   RLtyreTemperatureValue                       byte6  bit0  len8
   RRTyreTemperatureValue                       byte7  bit0  len8
  -- frame 1043
   FLtyrePressureStatus                         byte0  bit0  len3
   FLtyreTemperatureStauts                      byte0  bit3  len3
   FLTPMSError                                  byte0  bit6  len1
   FLAirLeakError                               byte0  bit7  len1
   FRTyrePressureStatus                         byte1  bit0  len3
   FRTyreTemperatureStauts                      byte1  bit3  len3
   FRTPMSError                                  byte1  bit6  len1
   FRAirLeakError                               byte1  bit7  len1
   RLTyrePressureStatus                         byte2  bit0  len3
   RLtyreTemperatureStauts                      byte2  bit3  len3
   RLTPMSError                                  byte2  bit6  len1
   RLAirLeakError                               byte2  bit7  len1
   RRtyrePressureStatus                         byte3  bit0  len3
   RRTyreTemperatureStauts                      byte3  bit3  len3
   RRTPMSError                                  byte3  bit6  len1
   RRAirLeakError                               byte3  bit7  len1
   FLTyreSelfLocalizationStatus                 byte4  bit0  len2
   FRTyreSelfLocalizationStatus                 byte4  bit2  len2
   RLTyreSelfLocalizationStatus                 byte4  bit4  len2
   RRTyreSelfLocalizationStatus                 byte4  bit6  len2
   PEPS_TPMSSystemConfiguration                 byte5  bit0  len2
   FLSensorLowBattery                           byte5  bit2  len1
   FRSensorLowBattery                           byte5  bit3  len1
   RLSensorLowBattery                           byte5  bit4  len1
   RRSensorLowBattery                           byte5  bit5  len1
   is413CanValid                                byte8  bit0  len8
## AmbientTempInfo
  -- frame 695
   AmbientTemp                                  byte0  bit0  len8
```
## Appendix B — MCU proxy API (domain / command per factory method)

Each line: `method(args) -> manager call(domain, cmd, key…)`. `sendJson(d, ...)` = `sendInfo(d, 1, {json})`; `getJson*(d, 1, "KEY", default)` = keyed read; `obtainAllJsonMsg(d,1)` = read-all with `{"all":0}`; `sendData(d, bytes)` = raw binary payload to domain `d`.

```
## SystemProxy
  getSystemInfoJson() -> obtainAllJsonMsg(3, 1)
  getSystemInfo() -> obtainAllParcel(3, 1, out)
  sendCmd(byte[] data) -> sendData(3, data)
  setMcuSource(int source) -> sendJson(3, data)
  getMcuSource() -> getJsonInt(3, 1, "MCU_SOURCE", 0)
  sendPowerKeyToMcu() -> sendJson(3, data)
  sendResetKeyToMcu() -> sendJson(3, data)
  sendUpdateStateToMcu(int state) -> sendJson(3, data)
  reqMcuPoweron() -> sendJson(3, data)
  sendResetCmdToMcu(int cmd) -> sendJson(3, data)
  notifyUnrealPoweroffToMcu(int cmd) -> sendJson(3, data)
  notifyAnimationToMcu(int cmd) -> sendJson(3, data)
  notifyNaviVoiceToMcu(int cmd) -> sendJson(3, data)
  notifyMcuMute1S() -> sendJson(3, data)
  sendBeepToMcu() -> sendJson(3, data)
  setMcuStateByBit(int state) -> sendJson(3, data)
  setMcuState(int state) -> sendJson(3, data)
  clearMcuStateByBit(int state) -> sendJson(3, data)
  getMcuState() -> getJsonInt(3, 1, "MCU_STATE", 0)
  getBPowerOn() -> getJsonBoolean(3, 1, "BPOWER_ON", false)
  setBPowerOnFalse() -> sendJson(3, data)
  getViceDriverHeadPhone() -> getJsonBoolean(3, 1, "VICEDIRVER_HEADPHONE", false)
  getBrightTurner() -> getJsonInt(3, 1, "BRIGHT_TURNER", 100)
  getReservedData() -> getPracel(3, 3, source)
  isParking() -> getJsonBoolean(3, 1, "BACK_SIGNAL", false)
  isSysReady() -> getJsonBoolean(3, 1, "SYSREADY", true)
  isAccOn() -> getJsonBoolean(3, 1, "ACC_STATE", true)
  getShowTouchDialogState() -> getJsonInt(3, 1, "NEED_SHOWDIALOG", 0)
  isPowerOnState() -> getJsonBoolean(3, 1, "POWER_STATE", false)
  getMcuTime() -> getJsonLong(3, 1, "MCU_TIME", 0L)
  getSysTime() -> getJsonLong(3, 1, "SYS_TIME", 0L)
  isIllState() -> getJsonBoolean(3, 1, "ILL_STATE", false)
## SettingsProxy
  sendCmd(byte[] data) -> sendData(2, data)
  getOfflineConfigInfo() -> obtainConfigInfo(8, 0)
  getSetupInfo() -> obtainAllJsonMsg(2, 1)
  getSettingsInfo() -> obtainAllParcel(2, 1, out)
  setBrightness(int brightness) -> sendJson(2, jsondata)
  getBrightness() -> getJsonInt(2, 1, "brightness", 0)
  setRrsAutoLevel(int data) -> sendJson(2, jsondata)
  getRrsAutoLevel() -> getJsonInt(2, 1, "RRS_AUTO_LEVEL", 0)
  getRrsRturnEn() -> getJsonInt(2, 1, "RRS_RTURN_EN", 0)
  setRrsRturnEn(int data) -> sendJson(2, jsondata)
  getAutoRrsTouchReq() -> getJsonInt(2, 1, "RRS_AUTO_REQ", 0)
  is3DAudioEnabled() -> getJsonBoolean(2, 1, "3D_AUDIO_SW", false)
  enable3DAudio(boolean z) -> sendJson(2, jSONObject.toString().getBytes())
  isBeepEnabled() -> getJsonBoolean(2, 1, "SYS_BEEP", false)
  enableBeep(boolean z) -> sendJson(2, jSONObject.toString().getBytes())
  getBeepVol() -> getJsonInt(2, 1, "SYS_BEEPVOL", -1)
  setBeepVol(byte vol) -> sendJson(2, jsondata)
  setVol(byte vol) -> sendJson(2, jsondata)
  getVol() -> getJsonInt(2, 1, "SYS_VOL", -1)
  setAudio40(byte data) -> sendJson(2, jsondata)
  getAudio40() -> getJsonInt(2, 1, "EQ40", 0)
  setAudio80(byte data) -> sendJson(2, jsondata)
  getAudio80() -> getJsonInt(2, 1, "EQ80", 0)
  setAudio500(byte data) -> sendJson(2, jsondata)
  getAudio500() -> getJsonInt(2, 1, "EQ500", 0)
  setAudio1k(byte data) -> sendJson(2, jsondata)
  getAudio1k() -> getJsonInt(2, 1, "EQ1k", 0)
  setAudio5k(byte data) -> sendJson(2, jsondata)
  getAudio5k() -> getJsonInt(2, 1, "EQ5k", 0)
  setAudio16k(byte data) -> sendJson(2, jsondata)
  getAudio16k() -> getJsonInt(2, 1, "EQ16k", 0)
  setTreb(byte data) -> sendJson(2, jsondata)
  getTreb() -> getJsonInt(2, 1, "treb", 0)
  setMid(byte data) -> sendJson(2, jsondata)
  getMid() -> getJsonInt(2, 1, "SYS_MID", 0)
  setBass(byte data) -> sendJson(2, jsondata)
  getBass() -> getJsonInt(2, 1, "bass", 0)
  enableLoud(boolean z) -> sendJson(2, jSONObject.toString().getBytes())
  isLoudEnabled() -> getJsonBoolean(2, 1, "SYS_LOUD", false)
  setFade(byte data) -> sendJson(2, jsondata)
  getFade() -> getJsonInt(2, 1, "audiofade", 0)
  setBal(byte data) -> sendJson(2, jsondata)
  getBal() -> getJsonInt(2, 1, "audiobal", 0)
  reqMcuVerInside() -> sendJson(2, jsondata)
  reqCanVer() -> sendJson(2, jsondata)
  setMute(boolean z) -> sendJson(2, jSONObject.toString().getBytes())
  isMute() -> getJsonBoolean(2, 1, "SYS_MUTE", false)
  setBtVol(byte data) -> sendJson(2, jsondata)
  getBtVol() -> getJsonInt(2, 1, "SYS_BTVOL", 0)
  setFmLimiter(byte data) -> sendJson(2, jsondata)
  getFmLimiter() -> getJsonInt(2, 1, "FM_LIMITER", 0)
  setAmLimiter(byte data) -> sendJson(2, jsondata)
  getAmLimiter() -> getJsonInt(2, 1, "AM_LIMITER", 0)
  setSpeedAdjustVolume(byte data) -> sendJson(2, jsondata)
  getSpeedAdjustVolume() -> getJsonInt(2, 1, "carspeed_volume", 0)
  setTboxVol(byte data) -> sendJson(2, jsondata)
  getTboxVol() -> getJsonInt(2, 1, "SYS_TBOXVOL", -1)
  getWelcomeState() -> getJsonInt(2, 1, "WELCOME_REQ", -1)
  forceMcuMute(byte data) -> sendJson(2, jsondata)
  setTTSVol(byte data) -> sendJson(2, jsondata)
  getTTSVol() -> getJsonInt(2, 1, "SYS_TTSVOL", -1)
  setGPSVol(byte data) -> sendJson(2, jsondata)
  getGpsVol() -> getJsonInt(2, 1, "SYS_GPSVOL", -1)
  setDefVol(byte data) -> sendJson(2, jsondata)
  getDefVol() -> getJsonInt(2, 1, "defvol", -1)
  setSysFlag(byte data) -> sendJson(2, jsondata)
  getSysFlag() -> getJsonInt(2, 1, "SYS_FLAG", -1)
  setSysFlag2(byte data) -> sendJson(2, jsondata)
  getSysFlag2() -> getJsonInt(2, 1, "SYS_SYSFLAG2", -1)
  setAudioMode(byte data) -> sendJson(2, jsondata)
  getAudioMode() -> getJsonInt(2, 1, "SYS_AUDIOMODE", 0)
  setTimeFormat24(boolean is24hFormat) -> sendJson(2, jsondata)
  isTimeFormat24() -> getJsonBoolean(2, 1, "SYS_TIME12H", false)
  getCarDoorUnlockState() -> getJsonInt(2, 1, "UNLOCK_STATE", -1)
  setTftOn(boolean val) -> sendJson(2, jsondata)
  isTftOn() -> getJsonBoolean(2, 1, "TFT1", true)
  setTftOn2(boolean val) -> sendJson(2, jsondata)
  isTftOn2() -> getJsonBoolean(2, 1, "TFT2", false)
  setSave1(byte data) -> sendJson(2, jsondata)
  getSave1() -> getJsonInt(2, 1, "SYS_ARMSAVE1", 0)
  setSave2(byte data) -> sendJson(2, jsondata)
  getSave2() -> getJsonInt(2, 1, "SYS_ARMSAVE2", 0)
  setSave3(byte data) -> sendJson(2, jsondata)
  getSave3() -> getJsonInt(2, 1, "SYS_ARMSAVE3", 0)
  setAutoBrightOn(boolean open) -> sendJson(2, jsondata)
  getAutoBrightOn() -> getJsonBoolean(2, 1, "setautobrighton", true)
  setBacklight(byte data) -> sendJson(2, jsondata)
  getBacklight() -> getJsonInt(2, 1, "backlight", 5)
  setViceBacklight(byte data) -> sendJson(2, jsondata)
  getViceBacklight() -> getJsonInt(2, 1, "vicebacklight", 5)
  setLanguageToMcu(byte data) -> sendJson(2, jsondata)
  getSysLanguage() -> getJsonInt(2, 1, "LANG_SEL", 1)
  setProductInfoToMcu(byte data) -> sendJson(2, jsondata)
  getProductInfo() -> getJsonInt(2, 1, "PRODUCT_INFO", 0)
  setFactoryVerCtrl(byte data) -> sendJson(2, jsondata)
  getFactoryVerCtrl() -> getJsonInt(2, 1, "CAN_COMPANY", 0)
  setWheelKeyStudy(int keyVal) -> sendJson(2, jsondata)
## McuHardKeyProxy
## SystemKeyProxy
## TouchProxy
## CustomerProxy
## ATestProxy
## CanProxy
## RadioProxy
  getRadioJson() -> obtainAllJsonMsg(1, 1)
  getRadioInfo() -> obtainAllParcel(1, 1, out)
  sendCmd(byte[] data) -> sendData(1, data)
  setFreq(int band, int freq) -> sendJson(1, data)
  getFreq() -> getJsonInt(1, 1, "getfreq", 0)
  setScan() -> sendJson(1, data)
  getScan() -> getJsonInt(1, 1, "scan", 0)
  setLoc() -> sendJson(1, data)
  getLoc() -> getJsonBoolean(1, 1, "loc", false)
  setSt() -> sendJson(1, data)
  getSt() -> getJsonBoolean(1, 1, "st", false)
  getStInd() -> getJsonBoolean(1, 1, "stind", false)
  setSearch() -> sendJson(1, data)
  getSearch() -> getJsonBoolean(1, 1, "aps", false)
  getArea() -> getJsonInt(1, 1, "RADIO_AREA", 0)
  setSearchRight() -> sendJson(4, data)
  setSearchLeft() -> sendJson(4, data)
  isLRSearch() -> getJsonBoolean(1, 1, "RADIO_SREACH_STATE", false)
  stopAllSearchMode() -> sendJson(1, data)
  setPlayState(int state) -> sendJson(1, data)
  getPlayState() -> getJsonInt(1, 1, "RADIO_PLAYSTATE", 0)
  setAuxPlayState(int state) -> sendJson(1, data)
  getAuxPlayState() -> getJsonInt(1, 1, "AUX_PLAYSTATE", 0)
  setClickTA() -> sendJson(1, data)
  setClickAF() -> sendJson(1, data)
  setRdsOnOff(boolean isOn) -> sendJson(1, data)
  setRdsPty(int type) -> sendJson(1, data)
  setFactoryRadioArea(int area) -> sendJson(1, jsondata)

```
## Appendix C — Constants

### C.1 Bluetooth (`ZHConstant`)

```
int ANSWER_MODE_INCOMING = 0;
int ANSWER_MODE_KEEPCALL = 1;
int ANSWER_MODE_TERMINATECALL = 2;
int BOND_STATE_BONDED = 2;
int BOND_STATE_BONDING = 1;
int BOND_STATE_NONE = 0;
int BT_UPDATE_FAIL = 4;
int BT_UPDATE_RUN = 2;
int BT_UPDATE_START = 1;
int BT_UPDATE_SUCCESS = 3;
int CALLLOG_TYPE_DIALED = 7;
int CALLLOG_TYPE_MISSED = 5;
int CALLLOG_TYPE_RECEIVED = 6;
int CALL_STATE_ALERTING = 3;
int CALL_STATE_HELD_BY_RESPONSE_AND_HOLD = 6;
int CALL_STATE_HOLD = 1;
int CALL_STATE_INCOMING = 4;
int CALL_STATE_OUTGOING = 2;
int CALL_STATE_TALKING = 0;
int CALL_STATE_TERMINATED = 7;
int CALL_STATE_WAITING = 5;
int CMD_ANSWER = 29;
int CMD_CONNECT = 7;
int CMD_CONNECT_A2DP = 13;
int CMD_CONNECT_HFP = 14;
int CMD_DIAL = 34;
int CMD_DIAL_KEY_NUM = 35;
int CMD_DISCONNECT = 8;
int CMD_DISCONNECT_A2DP = 16;
int CMD_DISCONNECT_HFP = 15;
int CMD_ENABLE = 1;
int CMD_ENABLE_AUTO_CONNECT = 27;
int CMD_FAST_BACKWARD = 40;
int CMD_FAST_FORWARD = 39;
int CMD_HANGUP = 30;
int CMD_NEXT = 17;
int CMD_PAIR = 9;
int CMD_PAUSE = 20;
int CMD_PLAY = 19;
int CMD_PREV = 18;
int CMD_REGISTER_PLAY_CALLBACK = 32;
int CMD_REQUEST_ID3INFO = 24;
int CMD_REQUEST_PAIRED_DEVICE = 6;
int CMD_REQUEST_PLAY_STATE = 25;
int CMD_SET_AUTO_ANSWER = 41;
int CMD_SET_AUTO_CONNECT = 28;
int CMD_SET_DISCOVERY = 5;
int CMD_SET_MIC_MUTE = 37;
int CMD_SET_MIC_TO_CAR = 36;
int CMD_SET_MUSIC_MUTE = 21;
int CMD_SET_NAME = 2;
int CMD_SET_PASSWORD = 42;
int CMD_SET_PHONE_MUTE = 38;
int CMD_SET_SOUND = 23;
int CMD_START_BT_UPDATE = 12;
int CMD_START_SCAN = 3;
int CMD_STOP = 26;
int CMD_STOP_SCAN = 4;
int CMD_UNPAIR = 10;
int CMD_UNPAIR_ALL = 11;
int CMD_UNREGISTER_PLAY_CALLBACK = 33;
int CMD_UPDOWN_SOUND = 22;
int CONTACT_STORAGE_CALLLOG = 2;
int CONTACT_STORAGE_PHONE = 1;
int CONTACT_STORAGE_SIM = 0;
int CONTACT_TYPE_FAX = 1;
int CONTACT_TYPE_HOME = 2;
int CONTACT_TYPE_MSG = 3;
int CONTACT_TYPE_NULL = 4;
int CONTACT_TYPE_PAGER = 5;
int CONTACT_TYPE_PHONE = 0;
int CONTACT_TYPE_PREF = 6;
int CONTACT_TYPE_VOICE = 7;
int CONTACT_TYPE_WORK = 8;
int DISCOVER_STATE_CONNECTABLE = 1;
int DISCOVER_STATE_CONNECTABLE_DISCOVERABLE = 2;
int DISCOVER_STATE_NONE = 0;
int DOMAIN_ID_CALLLOG = 5;
int DOMAIN_ID_CONTACT = 4;
int DOMAIN_ID_MUSIC = 2;
int DOMAIN_ID_PHONE = 3;
int DOMAIN_ID_SETTINGS = 1;
int DOWNLOAD_FAILED_STATE = 2;
int DOWNLOAD_OTHER_FINISH_STATE = 4;
int DOWNLOAD_START_STATE = 0;
int DOWNLOAD_SUCCESS_STATE = 1;
int DOWNLOAD_USER_REJECT_STATE = 3;
String EVENT_ON_A2DP_CONNECT_STATE_CHANGED = "onA2dpConnectStateChanged";
String EVENT_ON_A2DP_STREAM_CHANGED = "onA2dpStreamChanged";
String EVENT_ON_ADDRESS_CHANGED = "onAddressChanged";
String EVENT_ON_AUDIO_SESSIONID_CHANGED = "onAudioSessionIDChanged";
String EVENT_ON_BATTERY_CHANGED = "onBatteryChanged";
String EVENT_ON_BTUPDATE_STATE = "onBtUpdateState";
String EVENT_ON_CALLLOG_DATA_CHANGED = "onCallLogDataChanged";
String EVENT_ON_CALL_STATE_CHANGED = "onCallStateChanged";
String EVENT_ON_CONNECT_STATE_CHANGED = "onConnectStateChanged";
String EVENT_ON_DEVICE_BOND_STATE_CHANGED = "onDeviceBondStateChanged";
String EVENT_ON_DEVICE_CHANGED = "onDeviceChanged";
String EVENT_ON_DEVICE_OUTOF_RANGE = "onDeviceOutOfRange";
String EVENT_ON_DISCOVERABLE_STATE_CHANGED = "onDiscoverableStateChanged";
String EVENT_ON_DONWLOAD_STATE_CHANGED = "onDonwloadStateChanged";
String EVENT_ON_DOWNLOAD_FINISH = "onDownloadFinish";
String EVENT_ON_ENABLE_STATE_CHANGED = "onEnableStateChanged";
String EVENT_ON_FOUND_REMOTE_PHONE_INFO = "onFoundRemotePhoneInfo";
String EVENT_ON_ID3_INFO_CHANGED = "onId3InfoChanged";
String EVENT_ON_MIC_MUTE_STATE_CHANGED = "onMicMuteStateChanged";
String EVENT_ON_NAME_CHANGED = "onNameChanged";
String EVENT_ON_PASSWORD_CHANGED = "onPasswordChanged";
String EVENT_ON_PLAY_DURATION_CHANGED = "onPlayDurationChanged";
String EVENT_ON_PLAY_POSITION_CHANGED = "onPlayPositionChanged";
String EVENT_ON_PLAY_STATE_CHANGED = "onPlayStateChanged";
String EVENT_ON_READYOK = "onReadyOk";
String EVENT_ON_SCAN_STATE_CHANGED = "onScanStateChanged";
String EVENT_ON_SIGNAL_STRENGTH_CHANGED = "onSignalStrengthChanged";
String EVENT_ON_VERSION_CHANGED = "onVersionChanged";
String EVENT_ON_VOICE_STATE_CHANGED = "onVoiceStateChanged";
String GET_A2DP_STATE = "getA2dpState";
String GET_ADDRESS = "getAddress";
String GET_ALL_CALLLOGS = "getALLCalllogs";
String GET_AUDIO_SESSION_ID = "getAudioSessionId";
String GET_CALLS = "getCalls";
String GET_CALL_STATE = "getCallState";
String GET_CONNECTD_EVICE = "getConnectDevice";
String GET_CONNECT_STATE = "getConnectState";
String GET_CUR_BATTERY_VALE = "getCurBatteryVale";
String GET_CUR_POSITION = "getCurPosition";
String GET_CUR_SIGNAL_STRENGTH = "getCurSignalStrength";
String GET_DEVICES = "getDevices";
String GET_DURATION = "getDuration";
String GET_ENABLE_STATE = "getEnableState";
String GET_ID3_INFO = "getId3Info";
String GET_MAX_BATTERY_VALE = "getMaxBatteryVale";
String GET_MAX_SIGNAL_STRENGTH = "getMaxSignalStrength";
String GET_MIN_BATTERY_VALE = "getMinBatteryVale";
String GET_MIN_SIGNAL_STRENGTH = "getMinSignalStrength";
String GET_NAME = "getName";
String GET_PASSWORD = "getPassword";
String GET_PLAY_STATE = "getPlayState";
String GET_REMOTE_A2DP_ADDESS = "getRemoteA2dpAddess";
String GET_REMOTE_ADDRESS = "getRemoteAddress";
String GET_REMOTE_PHONE_NUMBER = "getRemotePhoneNumber";
String GET_REMOTE_PHONE_PERATOR = "getRemotePhonOperator";
String GET_VERSION = "getVersion";
int HANGUP_MODE_CURCALL = 1;
int HANGUP_MODE_INCOMING = 0;
int HANGUP_MODE_MULTIPLE = 2;
String IS_3CALLING = "is3Calling";
String IS_A2DP_CONNECTED = "isA2dpConnected";
String IS_A2DP_STREAM = "isA2dpStream";
String IS_AUTO_ANSWER = "isAutoAnswer";
String IS_CALLLOG_DOWNLOAD = "isCalllogDownloading";
String IS_CONNECTED = "isConnected";
String IS_COVERABLE = "isCoverable";
String IS_ENABLED = "isEnabled";
String IS_ENABLE_AUTO_CONNECT = "isEnableAutoConnect";
String IS_MIC_MUTE = "isMicMute";
String IS_OPEN_AUTO_CONNECT = "isOpenAutoConnect";
String IS_PLAYING = "isPlaying";
String IS_SCANNING = "isScanning";
String IS_TAKING = "isTaking";
String IS_VOICE_IN_CAR = "isVoiceInCar";
String KEY_EVENT = "event";
String KEY_VALUE0 = "value0";
String KEY_VALUE1 = "value1";
String KEY_VALUE2 = "value2";
String KEY_VALUE3 = "value3";
int PLAY_STATE_ERROR = 5;
int PLAY_STATE_FWD_SEEK = 3;
int PLAY_STATE_PAUSED = 1;
int PLAY_STATE_PLAYING = 0;
int PLAY_STATE_REW_SEEK = 4;
int PLAY_STATE_STOPPED = 2;
int PROFILE_A2DP = 2;
int PROFILE_AVRCP = 4;
int PROFILE_AVRCP_13 = 8;
int PROFILE_AVRCP_14 = 16;
int PROFILE_BLUETOOTH = 0;
int PROFILE_DUN = 2048;
int PROFILE_FTP = 4096;
int PROFILE_HFP = 1;
int PROFILE_HID = 256;
int PROFILE_IAP = 8192;
int PROFILE_MAP = 64;
int PROFILE_NAP = 1024;
int PROFILE_PANU = 512;
int PROFILE_PBAP = 32;
int PROFILE_SPP = 128;
String QUERY_NAME_BY_NUMBER = "queryNameByNumber";
int STATE_A2DP_CONNECTED = 2;
int STATE_A2DP_CONNECTING = 1;
int STATE_A2DP_DISCONNECTTING = 3;
int STATE_A2DP_NOT_INIT = 5;
int STATE_A2DP_READY = 0;
int STATE_A2DP_STREAM = 4;
int STATE_CONNECTED = 2;
int STATE_CONNECTING = 1;
int STATE_DIS_CONNECTING = 3;
int STATE_DOWNLOAD_DOWNLOADING = 2;
int STATE_DOWNLOAD_NOT_INIT = 0;
int STATE_DOWNLOAD_READY = 1;
int STATE_OFF = 10;
int STATE_ON = 12;
int STATE_READY = 0;
int STATE_TURNING_OFF = 13;
int STATE_TURNING_ON = 11;
int TYPE_GOC_JAVA = 1;
int TYPE_IVT_JAVA = 2;
int TYPE_NFORE_AIDL = 0;
```
### C.2 Logic (`LogicConstant`)
```
String CMD_CLOSE_SOURCE_ID = "closeSourceId";
String CMD_RELEASE_SOURCE_ID = "releaseSourceId";
String CMD_SET_AUTO_BRIGHT = "setAutoBright";
String CMD_SET_BRIGHT = "setBright";
String CMD_SET_SOURCE_ID = "setSourceId";
String CMD_SET_VOLUME = "setVolume";
String CMD_SET_VOLUME_CHANGE = "setVolumeChange";
int DOMAIN_KEY = 3;
int DOMAIN_LOGIC_STATE = 1;
int DOMAIN_SETTING = 4;
int DOMAIN_SOURCE = 2;
String EVENT_ON_ACC_STATE_CHANGED = "onAccStateChanged";
String EVENT_ON_AUX_STATE_CHANGED = "onAuxStateChanged";
String EVENT_ON_AVM_STATE_CHANGED = "onAvmStateChanged";
String EVENT_ON_BACK_STATE_CHANGED = "onBackStateChanged";
String EVENT_ON_BRIGHT_MODE_CHANGED = "onBrightModeChanged";
String EVENT_ON_BRIGH_CHANGED = "onBrightChanged";
String EVENT_ON_FOUCS_STATE_CHANGED = "onFoucsStateChanged";
String EVENT_ON_ILL_STATE_CHANGED = "onIllStateChanged";
String EVENT_ON_KEY_EVENT = "onKeyEvent";
String EVENT_ON_MEDIA_BUTTON_PRESSED = "onMediaButtonPressed";
String EVENT_ON_POWER_STATE_CHANGED = "onPowerStateChanged";
String EVENT_ON_RUNNING_STATE_CHANGED = "onRunningStateChanged";
String EVENT_ON_SOURCE_CHANGED = "onSourceChanged";
String EVENT_ON_TFT_STATE_CHANGED = "onTftStateChanged";
String EVENT_ON_THIRD_SOURCE_CHANDED = "onThirdSourceChanged";
String EVENT_RECEIVER_FOUCS_STATE_CHANGED = "receiverFoucsStateChanged";
String GET_AVM_STATE = "getAvmState";
String GET_BRIGHT = "getBright";
String GET_FOCUS_STATE = "getFocusState";
String GET_FOCUS_STATE_BY_ID = "getFocusStateById";
String GET_MAX_BRIGHT = "getMaxBright";
String GET_MIN_BRIGHT = "getMinBright";
String GET_SOURCE_ID = "getSourceId";
String GET_STREAM_TYPE = "getStreamType";
String GET_THIRD_SOURCE_ID = "getThirdSourceId";
String GET_VOLUME = "getVolume";
String HAS_FOCUS_BY_ID = "hasFocusById";
int ID_AUX = 11;
int ID_BT_MUSIC = 3;
int ID_BT_PHONE = 13;
int ID_CARLIFE = 12;
int ID_MUSIC = 1;
int ID_NEWS = 6;
int ID_NULL = 4096;
int ID_OFF_ARM = 4097;
int ID_OFF_MCU = 4098;
int ID_ONLINE_MUSIC = 4;
int ID_ONLINE_PROGRAM = 7;
int ID_ONLINE_RADIO = 5;
int ID_ONLINE_VIDEO = 8;
int ID_OTHER_APP = 4099;
int ID_RADIO = 0;
int ID_SD_MUSIC = 9;
int ID_SD_VIDEO = 10;
int ID_THIRD_AUDIO_APP = 15;
int ID_VIDEO = 2;
int ID_VOICE = 14;
String IS_ACC_ON = "isAccOn";
String IS_AUTO_BRIGHT = "isAutoBright";
String IS_AUX_STATE = "isAuxState";
String IS_ILL_ON = "isIllon";
String IS_IN_BACK_STATE = "isInBackState";
String IS_POWER_ON = "isPowerOn";
String IS_RUNNING = "isRunning";
String IS_TFT_ON = "isTftOn";
String LOGIC_SERVICE_NAME = "_logic_service";
```
## Appendix D — Every AIDL interface found (descriptor, transaction code, method)

Codes are the generated `TRANSACTION_*` numbers (first-declared = 1). `?` = code not parsed (see the descriptor section above for IMcuService).

Nforetek Bluetooth stack: 31 internal interfaces (`com.nforetek.bt.aidl.*`, e.g. UiCommand, callbacks) used only inside the BT app; not listed.

```
## android.zhonghong.IDataChangedListener   (found in: zhset)
  2   void notify(int i, int i2, int i3, Parcel parcel)
## android.zhonghong.IMcuService   (found in: zhset)
  ?   int getTest()
  ?   boolean obtainInfo(int i, int i2, Parcel parcel, Parcel parcel2)
  ?   int registDataChangedListener(int i, IDataChangedListener iDataChangedListener)
  ?   boolean sendInfo(int i, int i2, Parcel parcel)
  ?   int unregistDataChangedListener(int i, IDataChangedListener iDataChangedListener)
## com.logic.common.aidl.ILogicCallback   (found in: zhset)
  1   void onEventChanged(String str, String str2, String str3)
## com.logic.common.aidl.ILogicInterface   (found in: zhset)
  4   String getValue(String str, String str2)
  1   void registerLogicCallback(int i, ILogicCallback iLogicCallback)
  3   void setCmd(String str, String str2, String str3)
  2   void unregisterLogicCallback(int i, ILogicCallback iLogicCallback)
## com.zhonghong.aidlib.extraaudiodevice.ExtraDeviceFocusListener   (found in: zhset)
  1   void onAudioFocusChange(int i)
## com.zhonghong.aidlib.extraaudiodevice.ExtraDeviceInterface   (found in: zhset)
  2   int abandonSecondaryAudioFocus(ExtraDeviceFocusListener extraDeviceFocusListener)
  1   int requestSecondaryAudioFocus(ExtraDeviceFocusListener extraDeviceFocusListener, int i, int i2)
## com.zhonghong.aidlib.key.KeyCallBack   (found in: zhset)
  1   void notifyTouchKey(String str, int i)
## com.zhonghong.aidlib.key.KeyInterface   (found in: zhset)
  1   void registerCallBack(KeyCallBack keyCallBack)
  3   void sendKey(String str, int i)
  2   void unregisterCallBack(KeyCallBack keyCallBack)
## com.zhonghong.aidlib.multiscreen.ScreenCallBack   (found in: zhset)
  2   void notifyLockScreenState(boolean z)
  3   void notifyScreenPosChange(String str, String str2)
  1   void notifyViceScreenState(boolean z)
## com.zhonghong.aidlib.multiscreen.ScreenInterface   (found in: zhset)
  10  void broadcastScreenPosChange(String str, String str2)
  2   int getCurrentScreenPosition(String str)
  11  String getScreenApplication(int i)
  3   boolean isLockScreen()
  1   boolean isViceScreenOn()
  6   void registerCallBack(ScreenCallBack screenCallBack)
  8   void registerProvider(ScreenProvider screenProvider)
  12  void setSystemUiDisplay(boolean z, boolean z2)
  4   void startApp(String str, String str2, int i)
  5   void startApp2(String str, String str2, int i, Bundle bundle)
  7   void unregisterCallBack(ScreenCallBack screenCallBack)
  9   void unregisterProvider(ScreenProvider screenProvider)
## com.zhonghong.aidlib.multiscreen.ScreenProvider   (found in: zhset)
  2   int getCurrentScreenPosition(String str)
  3   String getScreenApplication(int i)
  6   boolean isLockScreen()
  5   boolean isViceScreenOn()
  4   void setSystemUiDisplay(boolean z, boolean z2)
  1   void startApp(String str, String str2, int i, Bundle bundle)
## com.zhonghong.aidlib.navi.NaviInterface   (found in: zhset)
  1   void setTurnedTo(int i)
  2   void startNavigation(String str)
## com.zhonghong.aidlib.state.ServiceProvider   (found in: aidlserver)
  1   boolean getBoolean(int i)
  2   int getInt(int i)
  3   String getString(int i)
  4   void setBoolean(int i, boolean z)
  5   void setInt(int i, int i2)
  6   void setString(int i, String str)
## com.zhonghong.aidlib.state.StateCallback   (found in: aidlserver)
  1   void notifyBoolean(int i, boolean z)
  2   void notifyInt(int i, int i2)
  3   void notifyString(int i, String str)
## com.zhonghong.aidlib.state.SystemStateCallBack   (found in: aidlserver)
  4   void notifyACC(boolean z)
  3   void notifyBTPhoneState(int i)
  5   void notifyBTState(boolean z)
  7   void notifyBackState(boolean z)
  1   void notifyHeadlampState(boolean z)
  6   void notifyNetworkState(boolean z)
  8   void notifyPowerState(boolean z)
  2   void notifyVOL(int i)
## com.zhonghong.aidlib.state.SystemStateInterface   (found in: aidlserver)
  5   boolean getBluetoothConnectState()
  6   boolean getBluetoothInCallState()
  4   boolean getNetworkState()
  3   int getTuidNumber()
  1   void registerCallBack(SystemStateCallBack systemStateCallBack)
  2   void unregisterCallBack(SystemStateCallBack systemStateCallBack)
## com.zhonghong.aidlib.state.SystemStateInterface2   (found in: aidlserver)
  8   boolean getBooleanInfo(int i, int i2)
  9   int getIntInfo(int i, int i2)
  11  ServiceProvider getServiceProvider(int i)
  10  String getStringInfo(int i, int i2)
  5   void notifyBooleanInfo(int i, int i2, boolean z)
  6   void notifyIntInfo(int i, int i2, int i3)
  7   void notifyStringInfo(int i, int i2, String str)
  1   void registerCallback(int i, StateCallback stateCallback)
  3   void registerServiceProvider(int i, ServiceProvider serviceProvider)
  12  void setBooleanInfo(int i, int i2, boolean z)
  13  void setIntInfo(int i, int i2, int i3)
  14  void setStringInfo(int i, int i2, String str)
  2   void unregisterCallback(int i, StateCallback stateCallback)
  4   void unregisterServiceProvider(int i, ServiceProvider serviceProvider)
## com.zhonghong.bluetooth.aidl.IBtCtrlInterface   (found in: bt)
  2   String getValue(String str, String str2)
  3   void registerCallback(int i, IBtDataCallback iBtDataCallback)
  1   void setCmd(int i, String str, String str2)
  4   void unregisterCallback(int i, IBtDataCallback iBtDataCallback)
## com.zhonghong.bluetooth.aidl.IBtDataCallback   (found in: bt)
  1   void onDataChanged(int i, String str)
## com.zhonghong.cancommon.ICanDataCallback   (found in: zhset)
  1   void onCanDataNotify(int i)
## com.zhonghong.cancommon.ICanInterface   (found in: zhset)
  3   void execCmd(int i, String str)
  4   void execExtraCmd(int i, String str, String str2)
  5   ElementData getElementDataInfo(int i)
  1   void registerCallback(ICanDataCallback iCanDataCallback)
  2   void unregisterCallback(ICanDataCallback iCanDataCallback)
## com.zhonghong.mcu.IMcuUpdateService   (found in: mcu)
  1   void showMcuUpdateDialog()
## com.zhonghong.mcuupdate.aidlserver.McuUpdateCallback   (found in: mcu)
  2   void onMcuUpdateProgressChanged(int i)
  1   void onMcuUpdateStateChanged(int i)
## com.zhonghong.mcuupdate.aidlserver.McuUpdateCtrlService   (found in: mcu)
  2   void registerCallBack(McuUpdateCallback mcuUpdateCallback)
  1   void update(String str)
## com.zhonghong.mediaaidl.btmusic.IBtMusicAidlInterface   (found in: music)
  5   String getAlbum()
  6   String getArtist()
  4   String getTitle()
  3   boolean isPlaying()
  8   void next()
  12  void pause()
  11  void play()
  10  void playPause()
  9   void prev()
  1   void registerDataChange(IBtMusicAidlListener iBtMusicAidlListener)
  7   void setBtMusicSource()
  2   void unregisterDataChange(IBtMusicAidlListener iBtMusicAidlListener)
## com.zhonghong.mediaaidl.btmusic.IBtMusicAidlListener   (found in: music)
  1   void onId3(String str, String str2, String str3)
  2   void onPlayState(boolean z)
## com.zhonghong.mediaaidl.radio.IRadioAidlInterface   (found in: music)
  14  void fMAMSwitch()
  5   int getFreq()
  4   boolean isAMBand()
  3   boolean isPlaying()
  12  void nextSearch()
  8   void nextStation()
  10  void nextStep()
  7   void playPause()
  13  void prevSearch()
  9   void prevStation()
  11  void prevStep()
  1   void registerDataChange(IRadioAidlListener iRadioAidlListener)
  6   void setRadioSource()
  2   void unregisterDataChange(IRadioAidlListener iRadioAidlListener)
## com.zhonghong.mediaaidl.radio.IRadioAidlListener   (found in: music)
  1   void onBandState(boolean z)
  3   void onFreq(int i, boolean z)
  2   void onPlayState(boolean z)
## com.zhonghong.mediaaidl.usbmusic.IUsbMusicAidlInterface   (found in: music)
  5   String getAlbum()
  6   String getArtist()
  4   String getTitle()
  3   boolean isPlaying()
  8   void next()
  12  void pause()
  11  void play()
  10  void playPause()
  9   void prev()
  1   void registerDataChange(IUsbMusicAidlListener iUsbMusicAidlListener)
  7   void setMusicSource()
  2   void unregisterDataChange(IUsbMusicAidlListener iUsbMusicAidlListener)
## com.zhonghong.mediaaidl.usbmusic.IUsbMusicAidlListener   (found in: music)
  1   void onId3(String str, String str2, String str3)
  2   void onPlayState(boolean z)
## com.zhonghong.mediaaidl.video.IVideoAidlInterface   (found in: music)
  4   String getTitle()
  3   boolean isPlaying()
  6   void next()
  10  void pause()
  9   void play()
  8   void playPause()
  7   void prev()
  1   void registerDataChange(IVideoAidlListener iVideoAidlListener)
  5   void setVideoSource()
  2   void unregisterDataChange(IVideoAidlListener iVideoAidlListener)
## com.zhonghong.mediaaidl.video.IVideoAidlListener   (found in: music)
  2   void onPlayState(boolean z)
  1   void onTitle(String str)
```
## Appendix E — Manifest components of every factory app (auto-generated)

`exp=0xffffffff` means exported=true; `None` means the attribute is absent (default rules apply).

```
##### android.ext.services 1 uid= None | android.ext.services.apk
  SVC .notification.Ranker exp= 0xffffffff perm= android.permission.BIND_NOTIFICATION_RANKER_SERVICE proc= None actions= ['android.service.notification.NotificationRankerService']
##### com.car.phoneprovider 20180720 uid= None | com.car.phoneprovider.apk
  PRV com.car.phone_data exp= 0xffffffff r= None w= None perm= None
  ACT com.car.phoneprovider.ui.MainActivity exp= None actions= [] cats= []
##### com.polstar.polnav6 @0x7f040002 uid= None | com.polstar.polnav6.apk
  SVC .PolnavELService exp= None perm= None proc= None actions= ['com.polstar.polnav6.IPolnavELService']
  SVC .BGService exp= None perm= None proc= None actions= []
  RCV .ShutdownReceiver exp= None perm= None actions= ['android.intent.action.ACTION_SHUTDOWN', 'android.intent.action.QUICKBOOT_POWEROFF']
  RCV .CoordinateReceiver exp= None perm= None actions= ['com.polstar.navi.COORDINATE']
  ACT .MainActivity exp= None actions= [] cats= ['LAUNCHER']
##### com.zh.auxin 202110211840 uid= android.uid.system | com.zh.auxin.apk
  ACT com.zh.auxin.MainActivity exp= None actions= ['android.intent.action.VIEW'] cats= ['LAUNCHER']
##### com.zh.test 202301041609 uid= android.uid.system | com.zh.test.apk
  SVC com.zh.test.fragment.service.CmdService exp= None perm= None proc= None actions= []
  RCV com.zh.test.fragment.broadcast.BootReceiver exp= None perm= None actions= ['android.intent.action.BOOT_COMPLETED']
  ACT .MainActivity exp= None actions= [] cats= ['LAUNCHER']
##### com.zhonghong.mediaconfigtool 202009281030 uid= android.uid.system | com.zhonghong.mediaconfigtool.apk
  RCV com.zhonghong.mediaconfigtool.receiver.USBReceiver exp= 0x0 perm= None actions= ['android.intent.action.MEDIA_MOUNTED', 'android.intent.action.MEDIA_UNMOUNTED', 'android.intent.action.MEDIA_EJECT']
  ACT com.zhonghong.mediaconfigtool.MainActivity exp= None actions= [] cats= ['LAUNCHER']
##### com.zhonghong.screensaver 202209191426 uid= android.uid.system | com.zhonghong.screensaver.apk
  SVC com.zhonghong.screensaver.service.ScreenService exp= 0xffffffff perm= None proc= None actions= ['com.zhonghong.screensaver.ScreenService']
  RCV com.zhonghong.screensaver.receiver.MountBroadcastReceiver exp= 0x0 perm= None actions= ['android.intent.action.MEDIA_MOUNTED', 'android.intent.action.MEDIA_EJECT', 'android.intent.action.MEDIA_UNMOUNTED', 'android.intent.action.BOOT_COMPLETED']
##### com.zhonghong.update 202302071016 uid= android.uid.system | com.zhonghong.update.apk
  SVC com.zhonghong.update.service.UpdateService exp= 0xffffffff perm= None proc= None actions= ['com.zhonghong.ctrl_update']
  ACT .MainActivity exp= None actions= [] cats= ['LAUNCHER']
##### com.zhonghong.uuidtool 202011241500 uid= android.uid.system | com.zhonghong.uuidtool.apk
  RCV com.zhonghong.receiver.USBBroadcastReceiver exp= 0x0 perm= None actions= ['android.intent.action.MEDIA_MOUNTED', 'android.intent.action.MEDIA_EJECT']
  ACT com.zhonghong.uuidtool.MainActivity exp= None actions= [] cats= ['LAUNCHER']
##### com.zhonghong.yzpicture 202206021631 uid= android.uid.system | com.zhonghong.yzpicture.apk
  ACT com.zhonghong.yzpicture.view.MainActivity exp= 0xffffffff actions= ['android.intent.action.VIEW', 'com.zhonghong.usb_music_activity'] cats= ['LAUNCHER', 'DEFAULT']
##### com.zhonghong.yzvideo 20240105.01 uid= android.uid.system | com.zhonghong.yzvideo.apk
  SVC com.zhonghong.yzvideo.service.VideoService exp= 0xffffffff perm= None proc= None actions= ['com.zhonghong.usb_video_action']
  ACT com.zhonghong.yzvideo.view.MainActivity exp= None actions= ['android.intent.action.VIEW', 'com.zhonghong.video_activity'] cats= ['LAUNCHER']
##### com.zh.settings 202401051446 uid= android.uid.system | com_zh_settings.apk
  SVC com.zh.settings.service.SetService exp= None perm= None proc= None actions= ['com.zhonghong.action.set']
  ACT com.zh.settings.MainActivity exp= None actions= ['com.zhonghong.action.set'] cats= ['LAUNCHER', 'DEFAULT']
  ACT com.zh.settings.SoundActivity exp= None actions= [] cats= []
  ACT com.zh.settings.SystemActivity exp= None actions= [] cats= []
  ACT com.zh.settings.WifiActivity exp= None actions= [] cats= []
  ACT com.zh.settings.DisplayActivity exp= None actions= [] cats= []
  ACT com.zh.settings.FieldActivity exp= None actions= [] cats= []
  ACT com.zh.settings.EqActivity exp= None actions= ['com.zhonghong.action.eq'] cats= ['DEFAULT']
  ACT com.zh.settings.ZXingActivity exp= None actions= [] cats= []
##### com.zh.yzradio 202211090303 uid= android.uid.system | com_zh_yzradio.apk
  ACT com.zh.yzradio.MainActivity exp= None actions= ['android.intent.action.VIEW'] cats= ['LAUNCHER']
  ACT com.zh.yzradio.rds.RdsViewActivity exp= None actions= [] cats= []
##### com.zhonghong.aidlserver 1.0 uid= None | com_zhonghong_aidlserver.apk
  SVC com.zhonghong.aidlserver.service.SystemStateService exp= 0xffffffff perm= None proc= :systemstate actions= ['com.zhonghong.aidlserver.service.SystemStateService']
  SVC com.zhonghong.aidlserver.service.SystemStateService2 exp= 0xffffffff perm= None proc= :systemstate2 actions= ['com.zhonghong.aidlserver.service.SystemStateService2']
  ACT com.zhonghong.aidlserver.MainActivity exp= None actions= [] cats= []
##### com.zhonghong.bluetooth 202401051453 uid= android.uid.system | com_zhonghong_bluetooth.apk
  SVC com.zhonghong.bluetooth.service.BtCtrlManagerService exp= None perm= None proc= None actions= ['com.zhonghong.bluetooth.START_BtCtrlService']
  RCV com.zhonghong.bluetooth.receiver.BootReceiver exp= 0x0 perm= None actions= ['com.zhonghong.zuiserver.BROADCAST']
  RCV com.zhonghong.bluetooth.receiver.UpdateSystemReceiver exp= 0xffffffff perm= None actions= ['zhonghong.intent.action.START_UPDATE', 'zhonghong.intent.action.END_UPDATE', 'com.zhonghong.bluetooth.call_last_number']
  RCV com.zhonghong.bluetooth.receiver.EasyConnectedReceiver exp= 0xffffffff perm= None actions= ['net.easyconn.bt.checkstatus', 'net.easyconn.bt.connected', 'net.easyconn.app.quit', 'net.easyconn.a2dp.release', 'net.easyconn.a2dp.acquire', 'net.easyconn.bt.connect', 'net.easyconn.connection.break']
  PRV com.zhonghong.bluetooth.provider.btinfo exp= 0xffffffff r= None w= None perm= None
  ACT com.zhonghong.bluetooth.MainActivity exp= None actions= ['android.bluetooth_btsettings', 'android.bluetooth_btdial'] cats= ['LAUNCHER', 'DEFAULT']
  ACT com.zhonghong.bluetooth.MusicActivity exp= None actions= ['android.bluetooth_btmusic'] cats= ['DEFAULT']
  ACT com.zhonghong.bluetooth.ContactActivity exp= None actions= [] cats= []
  ACT com.zhonghong.bluetooth.SetActivity exp= None actions= [] cats= []
##### com.zhonghong.can 2024.01.05 uid= android.uid.system | com_zhonghong_can.apk
  SVC com.zhonghong.can.CanService exp= 0xffffffff perm= None proc= None actions= ['com.zhonghong.intent.action.can']
##### com.zhonghong.carsetting 202401171303 uid= android.uid.system | com_zhonghong_carsetting.apk
  ACT com.zhonghong.carsetting.MainActivity exp= None actions= [] cats= ['LAUNCHER']
##### com.zhonghong.launcher 202401051430 uid= android.uid.system | com_zhonghong_launcher.apk
  RCV com.zhonghong.launcher.receiver.BootReceiver exp= 0x0 perm= None actions= ['com.zhonghong.zuiserver.BROADCAST']
  ACT com.zhonghong.launcher.activity.LauncherActivity exp= None actions= [] cats= ['HOME', 'LAUNCHER', 'DEFAULT']
  ACT com.zhonghong.launcher.activity.MediaActivity exp= None actions= ['com.zhonghong.launcher.MEDIA_ACTION'] cats= ['DEFAULT']
  ACT com.zhonghong.launcher.activity.NaviActivity exp= None actions= ['com.zhonghong.launcher.NAVI_ACTION'] cats= ['DEFAULT']
##### com.zhonghong.logic 202401051107 uid= android.uid.system | com_zhonghong_logic.apk
  SVC com.zhonghong.logic.service.LogicService exp= None perm= None proc= None actions= ['com.zhonghong.logic.service.LogicService']
  SVC com.zhonghong.logic.multouth.MultiTouchService exp= None perm= None proc= None actions= []
  RCV com.zhonghong.logic.receiver.BootReceiver exp= None perm= None actions= ['android.intent.action.BOOT_COMPLETED']
  ACT com.zhonghong.logic.MainActivity exp= None actions= [] cats= ['LAUNCHER']
##### com.zhonghong.mcu 20170117 uid= android.uid.system | com_zhonghong_mcu.apk
  SVC com.zhonghong.mcu.McuUpdateService exp= None perm= None proc= None actions= ['com.zhonghong.mcu.START_MCUUPDATE']
  SVC com.zhonghong.mcuupdate.aidlserver.McuCtrlServer exp= None perm= None proc= None actions= ['com.zhonghong.action.mcuupdate']
##### com.zhonghong.mediascan2 20230321.1.0 uid= None | com_zhonghong_mediascan2.apk
  PRV com.zhonghong.media exp= 0xffffffff r= None w= None perm= None
  ACT com.zhonghong.mediascan.MainActivity exp= None actions= [] cats= ['LAUNCHER']
##### com.zhonghong.yzmusic 202303211539 uid= android.uid.system | com_zhonghong_yzmusic.apk
  SVC com.zhonghong.music.model.service.UsbMusicService exp= 0xffffffff perm= None proc= None actions= ['com.zhonghong.usb_music_action']
  ACT com.zhonghong.yzmusic.view.MainActivity exp= 0xffffffff actions= ['android.intent.action.VIEW', 'com.zhonghong.usb_music_activity', 'com.zhonghong.usb_music_list', 'com.zhonghong.intent.action.music'] cats= ['LAUNCHER', 'DEFAULT', 'DEFAULT']

```
## Appendix F — Essentials from the on-device probe reports (identifiers removed)

Two probe runs were taken with an ordinary app (`uid u0_aXX`). Serial numbers, host/network identifiers and GPS coordinates were removed.

### F.1 Registered system services (`service list`, full)
```
0	zhupdate_service: [com.zhonghong.update.aidl.IUpdateInterface]
1	_logic_service: [com.logic.common.aidl.ILogicInterface]
2	drm.drmManager: [drm.IDrmManagerService]
3	media.camera: [android.hardware.ICameraService]
4	android.service.gatekeeper.IGateKeeperService: [android.service.gatekeeper.IGateKeeperService]
5	contexthub_service: [android.hardware.location.IContextHubService]
6	launcherapps: [android.content.pm.ILauncherApps]
7	shortcut: [android.content.pm.IShortcutService]
8	media_router: [android.media.IMediaRouterService]
9	media_session: [android.media.session.ISessionManager]
10	graphicsstats: [android.view.IGraphicsStats]
11	dreams: [android.service.dreams.IDreamManager]
12	network_time_update_service: []
13	appwidget: [com.android.internal.appwidget.IAppWidgetService]
14	soundtrigger: [com.android.internal.app.ISoundTriggerService]
15	jobscheduler: [android.app.job.IJobScheduler]
16	hardware_properties: [android.os.IHardwarePropertiesManager]
17	usb: [android.hardware.usb.IUsbManager]
18	DockObserver: []
19	audio: [android.media.IAudioService]
20	wallpaper: [android.app.IWallpaperManager]
21	country_detector: [android.location.ICountryDetector]
22	location: [android.location.ILocationManager]
23	devicestoragemonitor: []
24	notification: [android.app.INotificationManager]
25	recovery: [android.os.IRecoverySystem]
26	updatelock: [android.os.IUpdateLock]
27	connectivity: [android.net.IConnectivityManager]
28	ethernet: [android.net.IEthernetManager]
29	wifiscanner: [android.net.wifi.IWifiScanner]
30	wifi: [android.net.wifi.IWifiManager]
31	wifip2p: [android.net.wifi.p2p.IWifiP2pManager]
32	netpolicy: [android.net.INetworkPolicyManager]
33	netstats: [android.net.INetworkStatsService]
34	network_score: [android.net.INetworkScoreService]
35	textservices: [com.android.internal.textservice.ITextServicesManager]
36	network_management: [android.os.INetworkManagementService]
37	clipboard: [android.content.IClipboard]
38	statusbar: [com.android.internal.statusbar.IStatusBarService]
39	device_policy: [android.app.admin.IDevicePolicyManager]
40	deviceidle: [android.os.IDeviceIdleController]
41	lock_settings: [com.android.internal.widget.ILockSettings]
42	uimode: [android.app.IUiModeManager]
43	accessibility: [android.view.accessibility.IAccessibilityManager]
44	input_method: [com.android.internal.view.IInputMethodManager]
45	pinner: []
46	input: [android.hardware.input.IInputManager]
47	window: [android.view.IWindowManager]
48	alarm: [android.app.IAlarmManager]
49	content: [android.content.IContentService]
50	account: [android.accounts.IAccountManager]
51	telephony.registry: [com.android.internal.telephony.ITelephonyRegistry]
52	mount: [IMountService]
53	scheduling_policy: [android.os.ISchedulingPolicyService]
54	webviewupdate: [android.webkit.IWebViewUpdateService]
55	usagestats: [android.app.usage.IUsageStatsManager]
56	battery: []
57	sensorservice: [android.gui.SensorServer]
58	processinfo: [android.os.IProcessInfoService]
59	permission: [android.os.IPermissionController]
60	dbinfo: []
61	gfxinfo: []
62	meminfo: []
63	procstats: [com.android.internal.app.procstats.IProcessStats]
64	activity: [android.app.IActivityManager]
65	user: [android.os.IUserManager]
66	package: [android.content.pm.IPackageManager]
67	display: [android.hardware.display.IDisplayManager]
68	power: [android.os.IPowerManager]
69	appops: [com.android.internal.app.IAppOpsService]
70	batterystats: [com.android.internal.app.IBatteryStats]
71	netd: [android.net.INetd]
72	media.resource_manager: [android.media.IResourceManagerService]
73	media.player: [android.media.IMediaPlayerService]
74	media.drm: [android.media.IMediaDrmService]
75	media.extractor: [android.media.IMediaExtractorService]
76	media.sound_trigger_hw: [android.hardware.ISoundTriggerHwService]
77	media.radio: [android.hardware.IRadioService]
78	media.audio_policy: [android.media.IAudioPolicyService]
79	media.audio_flinger: [android.media.IAudioFlinger]
80	media.codec: [android.media.IMediaCodecService]
81	android.security.keystore: [android.security.IKeystoreService]
82	zhonghong.mcu: [android.zhonghong.IMcuService]
83	batteryproperties: [android.os.IBatteryPropertiesRegistrar]
84	gpu: [android.ui.IGpuService]
85	SurfaceFlinger: [android.ui.ISurfaceComposer]
```

### F.2 Selected system properties
```
[CarSettingKey]: [0]
[dev.bootcomplete]: [1]
[persist.phone.easyconnect]: [true]
[persist.sys.country]: []
[persist.sys.dalvik.vm.lib.2]: [libart.so]
[persist.sys.default.launcher]: [com.zhonghong.launcher/com.zhonghong.launcher.activity.LauncherActivity]
[persist.sys.default_navi]: [18]
[persist.sys.default_voice_call]: [20]
[persist.sys.language]: [fa]
[persist.sys.locale]: [fa-IR]
[persist.sys.localevar]: []
[persist.sys.logger.config]: [kmsg,logcat]
[persist.sys.max_alarm]: [30]
[persist.sys.max_bluetooth_sco]: [30]
[persist.sys.max_dtmf]: [30]
[persist.sys.max_enforced]: [30]
[persist.sys.max_music]: [30]
[persist.sys.max_navi]: [30]
[persist.sys.max_notification]: [30]
[persist.sys.max_ring]: [30]
[persist.sys.max_system]: [30]
[persist.sys.max_tts]: [30]
[persist.sys.max_voice_call]: [30]
[persist.sys.start.logic.first]: [1]
[persist.sys.timezone]: [Asia/Tehran]
[persist.sys.usb.config]: [adb]
[persist.sys.webview.vmsize]: [104857600]
[persist.zh.force_no_anim]: [true]
[persist.zh.forced_no_orient]: [true]
[persist.zh.google.py]: [1]
[persist.zh.login]: [true]
[ro.board.platform]: [s5p4418]
[ro.boot.hardware]: [zh_dragon]
[ro.boot.nxp4330.ext_audio]: [,ape,wma,ac3]
[ro.boot.nxp4330.ext_media]: [true]
[ro.boot.nxp4330.ext_video]: [,avi,flv,ts,mkv,rm,rmvb,asf,wmv]
[ro.boot.selinux]: [permissive]
[ro.build.fingerprint]: [Android/aosp_zh_dragon/zh_dragon:7.1.2/N2G48H/builde02141541:userdebug/release-keys]
[ro.build.tags]: [release-keys]
[ro.build.type]: [userdebug]
[ro.build.version.release]: [7.1.2]
[ro.hardware]: [zh_dragon]
[ro.kernel.android.bt]: [goc_serial]
[ro.kernel.android.gps]: [ttyAMA0]
[ro.kernel.android.mcu]: [ttyAMA2]
[ro.mcu.baudRate]: [2]
[ro.product.board]: [zh_dragon]
[ro.product.brand]: [Android]
[ro.product.cpu.abi2]: [armeabi]
[ro.product.cpu.abi]: [armeabi-v7a]
[ro.product.cpu.abilist32]: [armeabi-v7a,armeabi]
[ro.product.cpu.abilist64]: []
[ro.product.cpu.abilist]: [armeabi-v7a,armeabi]
[ro.product.device]: [zh_dragon]
[ro.product.first_api_level]: [25]
[ro.product.locale]: [en-US]
[ro.product.manufacturer]: [NEXELL]
[ro.product.model]: [AOSP on zh_dragon]
[ro.product.name]: [aosp_zh_dragon]
[ro.zh.inputmethodbottom]: [30]
[ro.zh.multi.audio_channel]: [true]
[ro.zh.onlysetscan]: [true]
[ro.zh.regudevice]: [2]
[sys.boot_completed]: [1]
[sys.carlifevr]: [false]
[sys.stream.duckvol]: [33]
[sys.usb.config]: [adb]
[sys.usb.configfs]: [1]
[sys.usb.controller]: [c0040000.dwc2otg]
[sys.usb.ffs.ready]: [1]
[sys.usb.state]: [adb]
[sys.zh.recoveryrun]: [true]
[sys.zh.regularvol]: [-10]
[zh.navi.pidlist]: [7767,1673]
```

### F.3 TTY drivers and device nodes
```
/dev/tty             /dev/tty        5       0 system:/dev/tty
/dev/console         /dev/console    5       1 system:console
/dev/ptmx            /dev/ptmx       5       2 system
g_serial             /dev/ttyGS    250 0-3 serial
pty_slave            /dev/pts      136 0-1048575 pty:slave
pty_master           /dev/ptm      128 0-1048575 pty:master
ttyAMA               /dev/ttyAMA   204 64-77 serial

crw------- 1 root   root          89,  10 1970-01-01 03:30 i2c-10
crw------- 1 root   root          89,   2 1970-01-01 03:30 i2c-2
crw------- 1 root   root          89,   3 1970-01-01 03:30 i2c-3
crw------- 1 root   root          89,   4 1970-01-01 03:30 i2c-4
crw-rw-rw- 1 root   root           5,   0 1970-01-01 03:30 tty
crw-rw-rw- 1 system system       204,  64 1970-01-01 03:30 ttyAMA0
crw-rw-rw- 1 system system       204,  65 2026-10-26 13:38 ttyAMA1
crw-rw-rw- 1 system system       204,  66 2026-10-26 13:38 ttyAMA2
crw-rw-rw- 1 system system       204,  67 2009-09-01 04:30 ttyAMA3
crw-rw-rw- 1 system system       204,  68 1970-01-01 03:30 ttyAMA4
crw-rw-rw- 1 system system        10,  56 1970-01-01 03:30 usb_i2c
```

### F.4 Serial port samples (hex, first bytes read in 1.5 s)
```
ttyAMA0  GPS: NMEA text sentences ($GNGGA ...)  [content not reproduced: it contains the car position]
ttyAMA1  run 1: C0 CB C4 00 70 0E 0A 02 09 10 00 B8 67 AF 77 1F 26 46 FC C0
ttyAMA1  run 2: C0 D3 74 00 B8 13 05 01 02 00 01 00 FB 69 C0
ttyAMA2  run 1 (MCU link per ro.kernel.android.mcu): FF AA 50 00 00 A0 15 02 D2 09 FD 00 0D 00 F0 00 00 00 00 DC 0A
ttyAMA2  run 2: (no data)
ttyAMA3 / ttyAMA4: (no data)
```

### F.5 Storage layout
```
/mnt:
appfuse
asec
expand
media_rw
obb
runtime
sdcard
secure
user

/sdcard:
Android
AudioRecorder
CarProbe
Download
backup
backups
easyconn
qsdlogs.qsd
qsdvideo
show_test.png
xbrowser
zhmedia

/storage:
emulated
self
udisk1
udisk2

adb /dev/usb-ffs/adb functionfs rw,relatime 0 0
/dev/block/vold/public:8_1 /mnt/media_rw/udisk2 vfat rw,dirsync,nosuid,nodev,noexec,relatime,uid=1023,gid=1023,fmask=0007,dmask=0007,allow_utime=0020,codepage=437,iocharset=iso8859-1,shortname=mixed,utf8,errors=remount-ro 0 0
/dev/block/mmcblk0p2 /system ext4 ro,seclabel,relatime,data=ordered 0 0
/dev/block/mmcblk0p9 /data ext4 rw,seclabel,nosuid,nodev,noatime,data=ordered 0 0
tmpfs /storage tmpfs rw,seclabel,relatime,mode=755,gid=1000 0 0
/dev/fuse /storage/emulated fuse rw,nosuid,nodev,noexec,noatime,user_id=1023,group_id=1023,default_permissions,allow_other 0 0
/dev/fuse /storage/udisk2 fuse rw,nosuid,nodev,noexec,noatime,user_id=1023,group_id=1023,default_permissions,allow_other 0 0
tmpfs /storage/self tmpfs rw,seclabel,relatime,mode=755,gid=1000 0 0
```
