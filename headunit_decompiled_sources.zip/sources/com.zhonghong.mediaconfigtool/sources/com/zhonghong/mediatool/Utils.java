package com.zhonghong.mediatool;

/* loaded from: classes.dex */
public final class Utils {
    public static Utils instance;

    private native String getConfigLocked();

    private native boolean saveConfigLocked(String str);

    static {
        System.loadLibrary("mediatool");
    }

    private Utils() {
    }

    public static synchronized Utils getInstance() {
        Utils utils;
        synchronized (Utils.class) {
            if (instance == null) {
                synchronized (Utils.class) {
                    instance = new Utils();
                }
            }
            utils = instance;
        }
        return utils;
    }

    public String getConfig() {
        return getConfigLocked();
    }

    public boolean saveConfig(String config) {
        if (config == null || "".equals(config)) {
            return false;
        }
        return saveConfigLocked(config);
    }
}
