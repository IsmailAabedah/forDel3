package com.zhonghong.mediaconfigtool;

/* loaded from: classes.dex */
public final class BuildConfig {
    public static final boolean DEBUG = true;
}
