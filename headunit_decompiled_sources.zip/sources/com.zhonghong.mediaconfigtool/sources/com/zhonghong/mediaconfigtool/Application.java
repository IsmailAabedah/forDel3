package com.zhonghong.mediaconfigtool;

import android.app.Activity;
import android.util.Log;

/* loaded from: classes.dex */
public class Application extends android.app.Application {
    private static Activity mMainActivity;
    private static final Application mInstance = new Application();
    private static final String TAG = Application.class.getSimpleName();

    public static synchronized Application getInstance() {
        Application application;
        synchronized (Application.class) {
            application = mInstance;
        }
        return application;
    }

    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        Log.i(TAG, "onCreate");
    }

    public Activity getMainActivity() {
        return mMainActivity;
    }

    public void setMainActivity(Activity activity) {
        mMainActivity = activity;
    }
}
