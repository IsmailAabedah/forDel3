package com.zhonghong.mediaconfigtool;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.SystemProperties;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.zhonghong.mediaconfigtool.utils.FileUtils;
import com.zhonghong.mediaconfigtool.utils.MediaConfigUtils;
import java.io.File;

/* loaded from: classes.dex */
public class MainActivity extends Activity implements View.OnClickListener {
    private static final String MEDIA_PATH = "/mnt/sdcard/zhmedia";
    private static final int MSG_ADD_LOG = 4;
    private static final int MSG_AUTO_WRITE = 3;
    private static final int MSG_REBOOT = 6;
    private static final int MSG_UPDATE_BUTTONS = 2;
    private static final int MSG_UPDATE_PROGRESS = 5;
    private static final String TAG = "MainActivity";
    private Button btExit;
    private Button btGetCfg;
    private Button btGetFileCfg;
    private Button btSetCfg;
    private String currentCfgtring;
    private String failedString;
    private String fileNotExistString;
    private String invalidateCfgString;

    @SuppressLint({"HandlerLeak"})
    private Handler mHandler = new Handler() { // from class: com.zhonghong.mediaconfigtool.MainActivity.1
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 2:
                    MainActivity.this.enableButtons(((Boolean) msg.obj).booleanValue());
                    break;
                case 3:
                    MainActivity.this.autoWrite();
                    break;
                case 4:
                    MainActivity.this.tvLog.append(msg.obj + "\n");
                    MainActivity.this.tvLog.setMovementMethod(ScrollingMovementMethod.getInstance());
                    break;
                case 5:
                    MainActivity.this.tvLog.append(".");
                    MainActivity.this.tvLog.setMovementMethod(ScrollingMovementMethod.getInstance());
                    MainActivity.this.updateProgress();
                    break;
                case 6:
                    Log.i(MainActivity.TAG, "reboot");
                    PowerManager powerManager = (PowerManager) MainActivity.this.getSystemService("power");
                    powerManager.reboot("mediaConfig reboot");
                    break;
            }
        }
    };
    private String rebootInfo;
    private String successString;
    private String syncDoneString;
    private TextView tvLog;
    private String warningString;
    private String writingString;

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(TAG, "onCreate");
        setContentView(R.layout.activity_main);
        init();
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        Log.i(TAG, "ext_media:" + SystemProperties.get("ro.boot.nxp4330.ext_media"));
        Log.i(TAG, "ext_audio:" + SystemProperties.get("ro.boot.nxp4330.ext_audio"));
        Log.i(TAG, "ext_video:" + SystemProperties.get("ro.boot.nxp4330.ext_video"));
        addLog(String.valueOf(this.currentCfgtring) + MediaConfigUtils.getInstance().getMediaConfigFromMachine());
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "onDestroy");
        this.mHandler.removeCallbacksAndMessages(null);
    }

    private void init() {
        Log.i(TAG, "init");
        initView();
        initStringResource();
        if (!"android.intent.action.MEDIA_MOUNTED".equals(getIntent().getAction())) {
            MediaConfigUtils.getInstance().setDefaultPath();
            if (!MediaConfigUtils.getInstance().checkFile()) {
                addLog(this.fileNotExistString);
            }
        }
        Application.getInstance().setMainActivity(this);
    }

    private void initStringResource() {
        this.warningString = getString(R.string.warning);
        this.successString = getString(R.string.write_success);
        this.failedString = getString(R.string.write_failed);
        this.writingString = getString(R.string.writing);
        this.syncDoneString = getString(R.string.sync_done);
        this.currentCfgtring = getString(R.string.current_cfg);
        this.fileNotExistString = getString(R.string.file_not_exist);
        this.invalidateCfgString = getString(R.string.invalidate_cfg);
        this.rebootInfo = getString(R.string.reboot_info);
    }

    private void initView() {
        Log.i(TAG, "initView");
        this.tvLog = (TextView) findViewById(R.id.tvLog);
        this.btSetCfg = (Button) findViewById(R.id.btnSetCfg);
        this.btGetCfg = (Button) findViewById(R.id.btnGetConfig);
        this.btGetFileCfg = (Button) findViewById(R.id.btnGetFileCfg);
        this.btExit = (Button) findViewById(R.id.btnExit);
        this.btSetCfg.setOnClickListener(this);
        this.btGetCfg.setOnClickListener(this);
        this.btGetFileCfg.setOnClickListener(this);
        this.btExit.setOnClickListener(this);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnGetConfig /* 2131165186 */:
                addLog(String.valueOf(this.currentCfgtring) + MediaConfigUtils.getInstance().getMediaConfigFromMachine());
                break;
            case R.id.btnGetFileCfg /* 2131165187 */:
                addLog("获取新的配置信息:" + MediaConfigUtils.getInstance().readFileByChars());
                break;
            case R.id.btnSetCfg /* 2131165188 */:
                enableButtons(false);
                onAutoBtnClick();
                break;
            case R.id.btnExit /* 2131165189 */:
                finish();
                break;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void enableButtons(boolean enabled) {
        Log.i(TAG, "enableButtons: " + enabled);
        this.btSetCfg.setEnabled(enabled);
        this.btGetCfg.setEnabled(enabled);
        this.btExit.setEnabled(enabled);
    }

    private void onAutoBtnClick() {
        Log.i(TAG, "onAutoBtnClick");
        sendHandleMessage(3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void writeConfig(String config, boolean sync) {
        Log.i(TAG, "Writing config: " + config);
        addLog(String.valueOf(this.writingString) + config);
        boolean ret = MediaConfigUtils.getInstance().writeMediaConfigToMachine(config);
        if (ret) {
            addLog(this.successString);
        } else {
            addLog(this.failedString);
            if (sync) {
                addLog(this.warningString);
                updateProgress();
                addLog(this.syncDoneString);
                stopUpdateProgress();
            }
        }
        addLog(String.valueOf(this.currentCfgtring) + MediaConfigUtils.getInstance().getMediaConfigFromMachine());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void autoWrite() {
        Log.i(TAG, "autoWrite");
        new Thread(new AutoWriteThread()).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void addLog(String log) {
        Log.i(TAG, "AddLog: " + log);
        sendHandleMessage(4, log);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void sendHandleMessage(int what, Object obj) {
        sendHandleMessageDelayed(what, obj, 0L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void sendHandleMessageDelayed(int what, Object obj, long delayMillis) {
        this.mHandler.sendMessageDelayed(Message.obtain(this.mHandler, what, obj), delayMillis);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateProgress() {
        sendHandleMessageDelayed(5, null, 1000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void stopUpdateProgress() {
        this.mHandler.removeMessages(5);
    }

    class AutoWriteThread implements Runnable {
        AutoWriteThread() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Log.i(MainActivity.TAG, "AutoWrite thread start...");
            MainActivity.this.updateProgress();
            String mediaCfg = MediaConfigUtils.getInstance().readFileByChars();
            MainActivity.this.stopUpdateProgress();
            if (MainActivity.this.checkInvalidateCfg(mediaCfg)) {
                MainActivity.this.writeConfig(mediaCfg, true);
            } else {
                MainActivity.this.addLog(MainActivity.this.invalidateCfgString);
            }
            MainActivity.this.sendHandleMessage(2, true);
            Log.i(MainActivity.TAG, "AutoWrite thread stop...");
            File file = new File(MainActivity.MEDIA_PATH);
            Log.i(MainActivity.TAG, "deleteMediaFile:/mnt/sdcard/zhmedia,exists:" + file.exists());
            if (file.exists()) {
                FileUtils.deleteFile(file);
            }
            MainActivity.this.addLog(MainActivity.this.rebootInfo);
            MainActivity.this.sendHandleMessageDelayed(6, 0, 2000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean checkInvalidateCfg(String mediaCfg) {
        if (mediaCfg != null && mediaCfg.length() == 13 && mediaCfg.startsWith("media")) {
            String split = mediaCfg.substring(5);
            if (split.matches("^[A-Fa-f0-9]{8}$")) {
                return true;
            }
        }
        return false;
    }
}
