package com.zhonghong.mediaconfigtool;

/* loaded from: classes.dex */
public final class R {

    public static final class attr {
    }

    public static final class dimen {
        public static final int activity_horizontal_margin = 0x7f040000;
        public static final int activity_vertical_margin = 0x7f040001;
    }

    public static final class drawable {
        public static final int ic_launcher = 0x7f020000;
    }

    public static final class id {
        public static final int btnExit = 0x7f070005;
        public static final int btnGetConfig = 0x7f070002;
        public static final int btnGetFileCfg = 0x7f070003;
        public static final int btnSetCfg = 0x7f070004;
        public static final int container = 0x7f070000;
        public static final int tvLog = 0x7f070006;
        public static final int writeBtnParent = 0x7f070001;
    }

    public static final class layout {
        public static final int activity_main = 0x7f030000;
    }

    public static final class string {
        public static final int app_name = 0x7f050000;
        public static final int current_cfg = 0x7f05000e;
        public static final int exit = 0x7f050006;
        public static final int file_not_exist = 0x7f050010;
        public static final int get_cfg = 0x7f050003;
        public static final int get_file_cfg = 0x7f050004;
        public static final int invalidate_cfg = 0x7f05000f;
        public static final int reboot_info = 0x7f050011;
        public static final int set_cfg = 0x7f050005;
        public static final int str_clear = 0x7f050002;
        public static final int str_del = 0x7f050001;
        public static final int sync_done = 0x7f05000c;
        public static final int sync_failed = 0x7f05000d;
        public static final int warn = 0x7f050008;
        public static final int warning = 0x7f050007;
        public static final int write_failed = 0x7f05000a;
        public static final int write_success = 0x7f050009;
        public static final int writing = 0x7f05000b;
    }

    public static final class style {
        public static final int AppBaseTheme = 0x7f060000;
        public static final int AppTheme = 0x7f060001;
    }
}
