package com.zhonghong.mediaconfigtool.utils;

import android.text.TextUtils;
import android.util.Log;
import com.zhonghong.mediatool.Utils;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;

/* loaded from: classes.dex */
public final class MediaConfigUtils {
    public static final String MediaConfig_FILE = "zhMediaConfig.txt";
    public static final String MediaConfig_FILE_PATH = "/mnt/USB";
    public static final int MediaConfig_LENGTH1 = 16;
    private static final String TAG = MediaConfigUtils.class.getSimpleName();
    private static MediaConfigUtils mInstance;
    private String mPath = null;
    private File mFile = null;

    private MediaConfigUtils() {
    }

    public static synchronized MediaConfigUtils getInstance() {
        MediaConfigUtils mediaConfigUtils;
        synchronized (MediaConfigUtils.class) {
            if (mInstance == null) {
                synchronized (MediaConfigUtils.class) {
                    mInstance = new MediaConfigUtils();
                }
            }
            mediaConfigUtils = mInstance;
        }
        return mediaConfigUtils;
    }

    public void setDefaultPath() {
        setPath(MediaConfig_FILE_PATH);
    }

    public void setPath(String path) {
        this.mPath = String.valueOf(path) + File.separator + MediaConfig_FILE;
    }

    public String getPath() {
        return this.mPath;
    }

    public boolean checkFile() {
        Log.i(TAG, "mPath: " + this.mPath);
        if (TextUtils.isEmpty(this.mPath)) {
            Log.e(TAG, "Empty path");
            return false;
        }
        this.mFile = new File(this.mPath);
        if (this.mFile.exists() && this.mFile.isFile() && this.mFile.canRead() && this.mFile.length() > 0) {
            Log.i(TAG, "checkFile: OK");
            return true;
        }
        Log.e(TAG, "checkFile: Not OK, exists = " + this.mFile.exists() + ", isFile = " + this.mFile.isFile() + ", canRead = " + this.mFile.canRead() + ", canWrite = " + this.mFile.canWrite() + ", length = " + this.mFile.length());
        return false;
    }

    public String getMediaConfigFromMachine() {
        try {
            return Utils.getInstance().getConfig();
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public boolean writeMediaConfigToMachine(String config) {
        return Utils.getInstance().saveConfig(config);
    }

    public String readFileByChars() {
        Log.i(TAG, "readFileByChars: " + this.mPath);
        Reader reader = null;
        StringBuffer bf = new StringBuffer();
        try {
            try {
                char[] tempchars = new char[30];
                Reader reader2 = new InputStreamReader(new FileInputStream(this.mPath), "GBK");
                while (true) {
                    try {
                        int charread = reader2.read(tempchars);
                        if (charread == -1) {
                            break;
                        }
                        if (charread == tempchars.length && tempchars[tempchars.length - 1] != '\r') {
                            bf.append(tempchars);
                        } else {
                            for (int i = 0; i < charread; i++) {
                                if (tempchars[i] != '\r') {
                                    bf.append(tempchars[i]);
                                }
                            }
                        }
                    } catch (Exception e) {
                        e1 = e;
                        reader = reader2;
                        e1.printStackTrace();
                        if (reader != null) {
                            try {
                                reader.close();
                            } catch (IOException e2) {
                            }
                        }
                        return bf.toString();
                    } catch (Throwable th) {
                        th = th;
                        reader = reader2;
                        if (reader != null) {
                            try {
                                reader.close();
                            } catch (IOException e3) {
                            }
                        }
                        throw th;
                    }
                }
                if (reader2 != null) {
                    try {
                        reader2.close();
                    } catch (IOException e4) {
                    }
                }
            } catch (Exception e5) {
                e1 = e5;
            }
            return bf.toString();
        } catch (Throwable th2) {
            th = th2;
        }
    }
}
