package com.zhonghong.mediaconfigtool.utils;

import android.os.Environment;
import android.support.v4.view.accessibility.AccessibilityEventCompat;
import android.text.TextUtils;
import android.util.Log;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.DigestInputStream;
import java.security.MessageDigest;

/* loaded from: classes.dex */
public class FileUtils {
    public static boolean isFileExist(String filePath) {
        Log.i("FileUtils", "isFileExist:" + filePath);
        if (TextUtils.isEmpty(filePath)) {
            return false;
        }
        return new File(filePath).exists();
    }

    public static boolean isFolderExist(String filePath) {
        Log.i("FileUtils", "isFolderExist:" + filePath);
        if (!TextUtils.isEmpty(filePath)) {
            File file = new File(filePath);
            if (file.exists() && file.isDirectory()) {
                return true;
            }
        }
        return false;
    }

    public static String getSDPath() {
        return Environment.getExternalStorageDirectory().getPath();
    }

    public static boolean deleteFile(File file) {
        String[] children;
        Log.i("deleteFile", file.getAbsolutePath());
        if (file.isDirectory() && (children = file.list()) != null) {
            for (String str : children) {
                boolean success = deleteFile(new File(file, str));
                if (!success) {
                    return false;
                }
            }
        }
        return file.delete();
    }

    public static String getFileStr(File file) {
        InputStream inputStream = null;
        BufferedReader bufferedReader = null;
        try {
            if (file != null) {
                try {
                    if (file.exists()) {
                        InputStream inputStream2 = new FileInputStream(file);
                        try {
                            BufferedReader bufferedReader2 = new BufferedReader(new InputStreamReader(inputStream2));
                            try {
                                StringBuffer sb = new StringBuffer();
                                while (true) {
                                    String strline = bufferedReader2.readLine();
                                    if (strline == null) {
                                        break;
                                    }
                                    sb.append(strline);
                                }
                                bufferedReader2.close();
                                String stringBuffer = sb.toString();
                                if (bufferedReader2 != null) {
                                    try {
                                        bufferedReader2.close();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }
                                if (inputStream2 != null) {
                                    try {
                                        inputStream2.close();
                                    } catch (IOException e2) {
                                        e2.printStackTrace();
                                    }
                                }
                                return stringBuffer;
                            } catch (FileNotFoundException e3) {
                                e = e3;
                                bufferedReader = bufferedReader2;
                                inputStream = inputStream2;
                                e.printStackTrace();
                                if (bufferedReader != null) {
                                    try {
                                        bufferedReader.close();
                                    } catch (IOException e4) {
                                        e4.printStackTrace();
                                    }
                                }
                                if (inputStream != null) {
                                    try {
                                        inputStream.close();
                                    } catch (IOException e5) {
                                        e5.printStackTrace();
                                    }
                                }
                                return null;
                            } catch (IOException e6) {
                                e = e6;
                                bufferedReader = bufferedReader2;
                                inputStream = inputStream2;
                                e.printStackTrace();
                                if (bufferedReader != null) {
                                    try {
                                        bufferedReader.close();
                                    } catch (IOException e7) {
                                        e7.printStackTrace();
                                    }
                                }
                                if (inputStream != null) {
                                    try {
                                        inputStream.close();
                                    } catch (IOException e8) {
                                        e8.printStackTrace();
                                    }
                                }
                                return null;
                            } catch (Throwable th) {
                                th = th;
                                bufferedReader = bufferedReader2;
                                inputStream = inputStream2;
                                if (bufferedReader != null) {
                                    try {
                                        bufferedReader.close();
                                    } catch (IOException e9) {
                                        e9.printStackTrace();
                                    }
                                }
                                if (inputStream != null) {
                                    try {
                                        inputStream.close();
                                    } catch (IOException e10) {
                                        e10.printStackTrace();
                                    }
                                }
                                throw th;
                            }
                        } catch (FileNotFoundException e11) {
                            e = e11;
                            inputStream = inputStream2;
                        } catch (IOException e12) {
                            e = e12;
                            inputStream = inputStream2;
                        } catch (Throwable th2) {
                            th = th2;
                            inputStream = inputStream2;
                        }
                    }
                } catch (FileNotFoundException e13) {
                    e = e13;
                } catch (IOException e14) {
                    e = e14;
                }
            }
            if (0 != 0) {
                try {
                    bufferedReader.close();
                } catch (IOException e15) {
                    e15.printStackTrace();
                }
            }
            if (0 != 0) {
                try {
                    inputStream.close();
                } catch (IOException e16) {
                    e16.printStackTrace();
                }
            }
            return null;
        } catch (Throwable th3) {
            th = th3;
        }
    }

    public static String getFileStr(String path) {
        return getFileStr(new File(path));
    }

    public static void syncFile() {
        new Thread(new Runnable() { // from class: com.zhonghong.mediaconfigtool.utils.FileUtils.1
            @Override // java.lang.Runnable
            public void run() {
                try {
                    Runtime.getRuntime().exec("sync");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public static void deleteSDCardFolder(File dir) {
        File to = new File(String.valueOf(dir.getAbsolutePath()) + System.currentTimeMillis());
        dir.renameTo(to);
        if (to.isDirectory()) {
            String[] children = to.list();
            for (String str : children) {
                File temp = new File(to, str);
                if (temp.isDirectory()) {
                    deleteSDCardFolder(temp);
                } else {
                    boolean b = temp.delete();
                    if (!b) {
                        Log.e("deleteSDCardFolder", "DELETE FAIL");
                    }
                }
            }
            to.delete();
        }
    }

    public static String getFileMD5(String path) {
        MessageDigest md;
        DigestInputStream dis;
        String str = null;
        if (path != null) {
            DigestInputStream dis2 = null;
            try {
                try {
                    FileInputStream fis = new FileInputStream(path);
                    md = MessageDigest.getInstance("MD5");
                    dis = new DigestInputStream(fis, md);
                } catch (Exception e) {
                    e = e;
                }
            } catch (Throwable th) {
                th = th;
            }
            try {
                byte[] buffer = new byte[AccessibilityEventCompat.TYPE_GESTURE_DETECTION_START];
                while (dis.read(buffer) > 0) {
                    md = dis.getMessageDigest();
                }
                byte[] bs = md.digest();
                if (bs != null) {
                    StringBuilder sb = new StringBuilder();
                    for (byte b : bs) {
                        int temp = b & 255;
                        String hexString = Integer.toHexString(temp);
                        if (hexString.length() < 2) {
                            sb.append("0").append(hexString);
                        } else {
                            sb.append(hexString);
                        }
                    }
                    str = sb.toString();
                    if (dis != null) {
                        try {
                            dis.close();
                        } catch (IOException e2) {
                            e2.printStackTrace();
                        }
                    }
                } else if (dis != null) {
                    try {
                        dis.close();
                    } catch (IOException e3) {
                        e3.printStackTrace();
                    }
                }
            } catch (Exception e4) {
                e = e4;
                dis2 = dis;
                e.printStackTrace();
                if (dis2 != null) {
                    try {
                        dis2.close();
                    } catch (IOException e5) {
                        e5.printStackTrace();
                    }
                }
                return str;
            } catch (Throwable th2) {
                th = th2;
                dis2 = dis;
                if (dis2 != null) {
                    try {
                        dis2.close();
                    } catch (IOException e6) {
                        e6.printStackTrace();
                    }
                }
                throw th;
            }
        }
        return str;
    }
}
