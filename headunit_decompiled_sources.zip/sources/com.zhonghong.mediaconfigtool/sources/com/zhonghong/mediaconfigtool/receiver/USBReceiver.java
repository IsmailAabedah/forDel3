package com.zhonghong.mediaconfigtool.receiver;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import com.zhonghong.mediaconfigtool.Application;
import com.zhonghong.mediaconfigtool.MainActivity;
import com.zhonghong.mediaconfigtool.utils.MediaConfigUtils;

/* loaded from: classes.dex */
public class USBReceiver extends BroadcastReceiver {
    private static final String TAG = USBReceiver.class.getSimpleName();

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        Log.i(TAG, "Received a broadcast: " + action);
        if ("android.intent.action.MEDIA_MOUNTED".equals(action)) {
            onMediaMounted(context, intent);
        } else if ("android.intent.action.MEDIA_EJECT".equals(action) || "android.intent.action.MEDIA_UNMOUNTED".equals(action)) {
            onMediaUnmounted();
        }
    }

    private void onMediaUnmounted() {
        Log.i(TAG, "onMediaUnmounted");
        Activity mActivity = Application.getInstance().getMainActivity();
        if (mActivity == null) {
            Log.e(TAG, "MainActivity is null");
        } else {
            mActivity.finish();
        }
    }

    private void onMediaMounted(Context context, Intent intent) {
        Log.i(TAG, "onMediaMounted");
        Uri uri = intent.getData();
        if (uri != null) {
            String path = uri.getPath();
            Log.i(TAG, "path: " + path);
            if (!TextUtils.isEmpty(path)) {
                MediaConfigUtils.getInstance().setPath(path);
                if (MediaConfigUtils.getInstance().checkFile()) {
                    startMainActivity(context);
                }
            }
        }
    }

    private void startMainActivity(Context context) {
        Log.i(TAG, "startMainActivity");
        Intent mainActivity = new Intent(context, (Class<?>) MainActivity.class);
        mainActivity.setFlags(268435456);
        mainActivity.setAction("android.intent.action.MEDIA_MOUNTED");
        context.startActivity(mainActivity);
    }
}
