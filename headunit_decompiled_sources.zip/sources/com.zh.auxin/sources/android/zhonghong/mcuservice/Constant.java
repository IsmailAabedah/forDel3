package android.zhonghong.mcuservice;

/* loaded from: classes.dex */
public class Constant {
    static final int ATESTINFO_DOMAIN = 7;
    static final int CANINFO_DOMAIN = 5;
    static final int CUSTOMERCAN_DOMAIN = 9;
    static final int CUSTOMERINFO_DOMAIN = 6;
    static final int IS_CHAR_TYPE = 0;
    static final int IS_JSON_CHAR_TYPE = 1;
    static final int MCUKEY_DOMAIN = 4;
    static final String MCU_SERVICE = "zhonghong.mcu";
    public static final int MCU_STATE_3GTALK = 7;
    public static final int MCU_STATE_BACK = 0;
    public static final int MCU_STATE_BTTALK = 2;
    public static final int MCU_STATE_CARMEDIA = 5;
    public static final int MCU_STATE_CARVOICE = 1;
    public static final int MCU_STATE_CCD = 4;
    public static final int MCU_STATE_DVR = 6;
    public static final int MCU_STATE_NAVI = 3;
    public static final int MCU_STATE_RDS = 8;
    public static final int MCU_STATE_THIRDAPP = 9;
    public static final int MCU_STATE_TTSVOICE = 10;
    static final int OFFLINE_CONFIG_DOMAIN = 8;
    static final int RADIO_DOMAIN = 1;
    static final int SETTINGS_DOMAIN = 2;
    static final int SYSTEMKEY_DOMAIN = 4608;
    static final int SYSTEM_DOMAIN = 3;
    static final int TOUCH_DOMAIN = 4864;

    public static class SourceType {
        public static final int SOURCE_AUX = 6;
        public static final int SOURCE_BTMUSIC = 13;
        public static final int SOURCE_CARLIFE = 11;
        public static final int SOURCE_MUSIC = 15;
        public static final int SOURCE_POWEROFF = 17;
        public static final int SOURCE_RADIO = 0;
        public static final int SOURCE_VIDEO = 16;
    }
}
