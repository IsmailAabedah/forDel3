package android.zhonghong.mcuservice;

import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.util.Log;
import android.zhonghong.mcuservice.IMcuService;
import java.util.Timer;
import java.util.TimerTask;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
class McuServiceManager {
    private static final String TAG = "McuManagerService";
    private static McuServiceManager sManagerService;
    private IBinder mIbinder;
    private IMcuService mImcuService = null;
    private IBinder.DeathRecipient mMcuDeathRecipient = new IBinder.DeathRecipient() { // from class: android.zhonghong.mcuservice.McuServiceManager.1
        @Override // android.os.IBinder.DeathRecipient
        public void binderDied() {
            Log.i(McuServiceManager.TAG, "Mcuserver died!");
            McuServiceManager.this.mImcuService = null;
            if (McuServiceManager.this.mIbinder != null) {
                try {
                    McuServiceManager.this.mIbinder.unlinkToDeath(McuServiceManager.this.mMcuDeathRecipient, 0);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                McuServiceManager.this.mIbinder = null;
            }
            McuServiceManager.this.reConnect();
        }
    };

    private McuServiceManager() {
        getIMcuService();
    }

    static McuServiceManager getInstance() {
        if (sManagerService == null) {
            synchronized (McuServiceManager.class) {
                if (sManagerService == null) {
                    sManagerService = new McuServiceManager();
                }
            }
        }
        return sManagerService;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void getIMcuService() {
        if (this.mImcuService == null) {
            Log.i(TAG, "mcuService is null");
            this.mIbinder = ServiceManager.getService("zhonghong.mcu");
            if (this.mIbinder != null) {
                this.mImcuService = IMcuService.Stub.asInterface(this.mIbinder);
                try {
                    this.mIbinder.linkToDeath(this.mMcuDeathRecipient, 0);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            } else {
                Log.w(TAG, "connect mcuservice failed will reconnect");
                reConnect();
            }
        } else {
            Log.w(TAG, "getIMcuService but mImcuService not null");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void reConnect() {
        Log.i(TAG, "reConnect ");
        Timer time = new Timer();
        time.schedule(new TimerTask() { // from class: android.zhonghong.mcuservice.McuServiceManager.2
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                McuServiceManager.this.getIMcuService();
                if (McuServiceManager.this.mIbinder != null) {
                    Log.i(McuServiceManager.TAG, "reconnect mcuservice success will registAll!");
                    RegistManager.getInstance().registAll();
                }
            }
        }, 1500L);
    }

    Parcel getPracel(int domain, int cmd) {
        Parcel p = Parcel.obtain();
        Parcel in = Parcel.obtain();
        try {
            try {
                if (this.mImcuService == null) {
                    getIMcuService();
                }
                this.mImcuService.obtainInfo(domain, cmd, in, p);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
            return p;
        } finally {
            p.recycle();
        }
    }

    void getPracel(int domain, int cmd, Parcel p) {
        Parcel in = Parcel.obtain();
        try {
            if (this.mImcuService == null) {
                getIMcuService();
            }
            this.mImcuService.obtainInfo(domain, cmd, in, p);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    int getInt(int domain, int cmd) {
        Parcel p = Parcel.obtain();
        Parcel in = Parcel.obtain();
        int result = 0;
        try {
            try {
                if (this.mImcuService == null) {
                    getIMcuService();
                }
                this.mImcuService.obtainInfo(domain, cmd, in, p);
                if (p != null && p.dataSize() > 0) {
                    result = p.readInt();
                }
            } catch (RemoteException e) {
                e.printStackTrace();
            }
            return result;
        } finally {
            p.recycle();
        }
    }

    boolean getBoolean(int domain, int cmd) {
        Parcel p = Parcel.obtain();
        Parcel in = Parcel.obtain();
        try {
            try {
                if (this.mImcuService == null) {
                    getIMcuService();
                }
                this.mImcuService.obtainInfo(domain, cmd, in, p);
                if (p != null && p.dataSize() > 0) {
                    return p.readInt() == 1;
                }
            } catch (RemoteException e) {
                e.printStackTrace();
            }
            return false;
        } finally {
            p.recycle();
        }
    }

    int[] getIntArray(int domain, int cmd) {
        int[] result = new int[16];
        Parcel p = Parcel.obtain();
        Parcel in = Parcel.obtain();
        try {
            try {
                if (this.mImcuService == null) {
                    getIMcuService();
                }
                this.mImcuService.obtainInfo(domain, cmd, in, p);
                if (p != null && p.dataSize() > 0) {
                    p.readIntArray(result);
                }
            } catch (RemoteException e) {
                e.printStackTrace();
            }
            return result;
        } finally {
            p.recycle();
        }
    }

    boolean sendInt(int domain, int cmd, int data) {
        Parcel p = Parcel.obtain();
        try {
            try {
                if (this.mImcuService == null) {
                    getIMcuService();
                }
                p.writeInt(data);
                boolean result = this.mImcuService.sendInfo(domain, cmd, p);
                return result;
            } catch (RemoteException e) {
                e.printStackTrace();
                p.recycle();
                return false;
            }
        } finally {
            p.recycle();
        }
    }

    boolean sendByteArray(int domain, int cmd, byte[] data) {
        Parcel p = Parcel.obtain();
        int[] data_int = new int[data.length];
        for (int i = 0; i < data.length; i++) {
            try {
                data_int[i] = data[i];
            } finally {
                p.recycle();
            }
        }
        try {
            if (this.mImcuService == null) {
                getIMcuService();
            }
            if (data != null && data.length > 0) {
                p.writeIntArray(data_int);
                boolean result = this.mImcuService.sendInfo(domain, cmd, p);
                return result;
            }
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        p.recycle();
        return false;
    }

    boolean sendData(int domain, byte[] data) {
        Parcel p = Parcel.obtain();
        try {
            try {
                if (this.mImcuService == null) {
                    getIMcuService();
                }
                if (data != null && data.length > 0) {
                    p.writeByteArray(data);
                    boolean result = this.mImcuService.sendInfo(domain, 0, p);
                    return result;
                }
            } catch (RemoteException e) {
                e.printStackTrace();
            }
            return false;
        } finally {
            p.recycle();
        }
    }

    boolean sendJson(int domain, byte[] data) {
        Parcel p = Parcel.obtain();
        try {
            try {
                if (this.mImcuService == null) {
                    getIMcuService();
                }
                if (data != null && data.length > 0) {
                    p.writeByteArray(data);
                    return this.mImcuService.sendInfo(domain, 1, p);
                }
            } catch (RemoteException e) {
                e.printStackTrace();
            }
            p.recycle();
            return false;
        } finally {
            p.recycle();
        }
    }

    boolean getJsonBoolean(int domain, int cmd, String key, boolean def) {
        boolean res = def;
        JSONObject json = new JSONObject();
        try {
            json.put(key, 0);
            String jsonstr = json.toString();
            byte[] data = jsonstr.getBytes();
            String str = getInstance().obtainJson(domain, cmd, data);
            res = def;
            if (str != null && !str.isEmpty()) {
                try {
                    boolean res2 = Boolean.valueOf(str).booleanValue();
                    return res2;
                } catch (Exception e) {
                    e.printStackTrace();
                    return res;
                }
            }
            return res;
        } catch (Exception e2) {
            e2.printStackTrace();
            return res;
        }
    }

    int getJsonInt(int domain, int cmd, String key, int def) {
        int res = def;
        JSONObject json = new JSONObject();
        try {
            json.put(key, 0);
            String jsonstr = json.toString();
            byte[] data = jsonstr.getBytes();
            String str = getInstance().obtainJson(domain, cmd, data);
            res = def;
            if (str != null && !str.isEmpty()) {
                try {
                    int res2 = Integer.valueOf(str).intValue();
                    return res2;
                } catch (Exception e) {
                    e.printStackTrace();
                    return res;
                }
            }
            return res;
        } catch (Exception e2) {
            e2.printStackTrace();
            return res;
        }
    }

    long getJsonLong(int domain, int cmd, String key, long def) {
        long res = def;
        JSONObject json = new JSONObject();
        try {
            json.put(key, 0);
            String jsonstr = json.toString();
            byte[] data = jsonstr.getBytes();
            String str = getInstance().obtainJson(domain, cmd, data);
            res = def;
            if (str != null && !str.isEmpty()) {
                try {
                    long res2 = Long.valueOf(str).longValue();
                    return res2;
                } catch (Exception e) {
                    e.printStackTrace();
                    return res;
                }
            }
            return res;
        } catch (Exception e2) {
            e2.printStackTrace();
            return res;
        }
    }

    String getJsonString(int domain, int cmd, String key, String def) {
        String res = def;
        JSONObject json = new JSONObject();
        try {
            json.put(key, 0);
            String jsonstr = json.toString();
            byte[] data = jsonstr.getBytes();
            String str = getInstance().obtainJson(domain, cmd, data);
            res = def;
            if (str == null) {
                return res;
            }
            if (!str.isEmpty()) {
                return str;
            }
            return res;
        } catch (Exception e) {
            e.printStackTrace();
            return res;
        }
    }

    String obtainJson(int domain, int cmd, byte[] data) {
        Parcel p = Parcel.obtain();
        Parcel in = Parcel.obtain();
        String str = "";
        try {
            try {
                if (this.mImcuService == null) {
                    getIMcuService();
                }
                if (data != null && data.length > 0) {
                    in.writeByteArray(data);
                    boolean result = this.mImcuService.obtainInfo(domain, cmd, in, p);
                    if (result && p != null) {
                        int len = p.readInt();
                        p.readInt();
                        if (len > 1 && len <= p.dataAvail()) {
                            byte[] info = new byte[len];
                            p.readByteArray(info);
                            str = new String(info, 0, len - 1);
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return str;
        } finally {
            p.recycle();
        }
    }

    byte[] obtainConfigInfo(int domain, int cmd) {
        Parcel p = Parcel.obtain();
        Parcel in = Parcel.obtain();
        JSONObject json = new JSONObject();
        try {
            json.put("all", 0);
        } catch (JSONException e1) {
            e1.printStackTrace();
        }
        String jsonstr = json.toString();
        byte[] data = jsonstr.getBytes();
        try {
            try {
                if (this.mImcuService == null) {
                    getIMcuService();
                }
                if (data != null && data.length > 0) {
                    in.writeByteArray(data);
                    boolean result = this.mImcuService.obtainInfo(domain, cmd, in, p);
                    if (result && p != null) {
                        int len = p.readInt();
                        p.readInt();
                        if (len > 1 && len <= p.dataAvail()) {
                            byte[] info = new byte[len];
                            p.readByteArray(info);
                            return info;
                        }
                    }
                }
            } finally {
                p.recycle();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        p.recycle();
        return null;
    }

    JSONObject obtainAllJsonMsg(int domain, int cmd) {
        Parcel p = Parcel.obtain();
        Parcel in = Parcel.obtain();
        JSONObject JsonMsg = null;
        JSONObject json = new JSONObject();
        try {
            json.put("all", 0);
        } catch (JSONException e1) {
            e1.printStackTrace();
        }
        String jsonstr = json.toString();
        byte[] data = jsonstr.getBytes();
        try {
            try {
                if (this.mImcuService == null) {
                    getIMcuService();
                }
                if (data != null && data.length > 0) {
                    in.writeByteArray(data);
                    boolean result = this.mImcuService.obtainInfo(domain, cmd, in, p);
                    if (result && p != null) {
                        int len = p.readInt();
                        p.readInt();
                        if (len > 1 && len <= p.dataAvail()) {
                            byte[] info = new byte[len];
                            p.readByteArray(info);
                            String str = new String(info, 0, len - 1);
                            JsonMsg = new JSONObject(str);
                        }
                    }
                }
            } finally {
                p.recycle();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return JsonMsg;
    }

    boolean obtainAllParcel(int domain, int cmd, Parcel p) {
        Parcel in = Parcel.obtain();
        JSONObject json = new JSONObject();
        try {
            json.put("result", 0);
        } catch (JSONException e1) {
            e1.printStackTrace();
        }
        String jsonstr = json.toString();
        byte[] data = jsonstr.getBytes();
        try {
            if (this.mImcuService == null) {
                getIMcuService();
            }
            if (data != null && data.length > 0) {
                in.writeByteArray(data);
                boolean result = this.mImcuService.obtainInfo(domain, cmd, in, p);
                return result;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    boolean registDataChangedListener(int domain, IDataChangedListener listener) {
        try {
            if (this.mImcuService == null) {
                getIMcuService();
            }
            Log.i(TAG, "registDataChangedListener domain:" + domain + "|listener:" + listener);
            this.mImcuService.registDataChangedListener(domain, listener);
            return true;
        } catch (RemoteException e) {
            e.printStackTrace();
            return false;
        }
    }
}
