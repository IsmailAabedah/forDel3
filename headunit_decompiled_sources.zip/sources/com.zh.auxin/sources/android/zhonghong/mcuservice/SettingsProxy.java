package android.zhonghong.mcuservice;

import android.os.Parcel;
import android.util.Log;
import android.zhonghong.mcuservice.RegistManager;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class SettingsProxy {
    private static final int DOMAIN = 2;
    static final String TAG = "SettingsProxy";
    private McuServiceManager mMcuServiceManager = McuServiceManager.getInstance();

    public boolean registSettingsInfoChangedListener(RegistManager.ISettingsInfoChangedListener listener) {
        return RegistManager.getInstance().addSettingsInfoChangedListener(listener);
    }

    public boolean unregisSettingsInfoChangedListener(RegistManager.ISettingsInfoChangedListener listener) {
        RegistManager.getInstance().removeSettingsInfoChangedListener(listener);
        return true;
    }

    public boolean sendCmd(byte[] data) {
        Log.i(TAG, "sendCmd");
        return this.mMcuServiceManager.sendData(2, data);
    }

    public byte[] getOfflineConfigInfo() {
        byte[] out = this.mMcuServiceManager.obtainConfigInfo(8, 0);
        return out;
    }

    public JSONObject getSetupInfo() {
        JSONObject out = this.mMcuServiceManager.obtainAllJsonMsg(2, 1);
        return out;
    }

    public SettingsInfo getSettingsInfo() {
        Parcel out = Parcel.obtain();
        this.mMcuServiceManager.obtainAllParcel(2, 1, out);
        SettingsInfo info = SettingsInfo.CREATOR.createFromParcel(out);
        out.recycle();
        return info;
    }

    public boolean setBrightness(int brightness) {
        Log.i(TAG, "setBrightness : " + brightness);
        JSONObject json = new JSONObject();
        try {
            json.put("brightness", brightness);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getBrightness() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "brightness", 0);
    }

    public boolean setRrsAutoLevel(int data) {
        JSONObject json = new JSONObject();
        try {
            json.put("RRS_AUTO_LEVEL", data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "setRrsAutoLevel:" + data);
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getRrsAutoLevel() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "RRS_AUTO_LEVEL", 0);
    }

    public int getRrsRturnEn() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "RRS_RTURN_EN", 0);
    }

    public boolean setRrsRturnEn(int data) {
        JSONObject json = new JSONObject();
        try {
            json.put("RRS_RTURN_EN", data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "setRrsRturnEn:" + data);
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getAutoRrsTouchReq() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "RRS_AUTO_REQ", 0);
    }

    public boolean is3DAudioEnabled() {
        return this.mMcuServiceManager.getJsonBoolean(2, 1, "3D_AUDIO_SW", false);
    }

    public boolean enable3DAudio(boolean z) {
        Log.i(TAG, "enable3DAudio " + z);
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("3D_AUDIO_SW", z ? 1 : 0);
            return this.mMcuServiceManager.sendJson(2, jSONObject.toString().getBytes());
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean isBeepEnabled() {
        return this.mMcuServiceManager.getJsonBoolean(2, 1, "SYS_BEEP", false);
    }

    public boolean enableBeep(boolean z) {
        Log.i(TAG, "enableBeep  " + z);
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("SYS_BEEP", z ? 1 : 0);
            return this.mMcuServiceManager.sendJson(2, jSONObject.toString().getBytes());
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getBeepVol() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "SYS_BEEPVOL", -1);
    }

    public boolean setBeepVol(byte vol) {
        Log.i(TAG, "setBeepVol vol = " + ((int) vol));
        JSONObject json = new JSONObject();
        try {
            json.put("SYS_BEEPVOL", (int) vol);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean setVol(byte vol) {
        Log.i(TAG, "setVol " + ((int) vol));
        JSONObject json = new JSONObject();
        try {
            json.put("SYS_VOL", (int) vol);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getVol() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "SYS_VOL", -1);
    }

    public boolean setAudio40(byte data) {
        Log.i(TAG, "setAudio40 : " + ((int) data));
        JSONObject json = new JSONObject();
        try {
            json.put("EQ40", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getAudio40() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "EQ40", 0);
    }

    public boolean setAudio80(byte data) {
        Log.i(TAG, "setAudio80 " + ((int) data));
        JSONObject json = new JSONObject();
        try {
            json.put("EQ80", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getAudio80() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "EQ80", 0);
    }

    public boolean setAudio500(byte data) {
        Log.i(TAG, "setAudio500 " + ((int) data));
        JSONObject json = new JSONObject();
        try {
            json.put("EQ500", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getAudio500() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "EQ500", 0);
    }

    public boolean setAudio1k(byte data) {
        Log.i(TAG, "setAudio1k : " + ((int) data));
        JSONObject json = new JSONObject();
        try {
            json.put("EQ1k", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getAudio1k() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "EQ1k", 0);
    }

    public boolean setAudio5k(byte data) {
        Log.i(TAG, "setAudio5k " + ((int) data));
        JSONObject json = new JSONObject();
        try {
            json.put("EQ5k", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getAudio5k() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "EQ5k", 0);
    }

    public boolean setAudio16k(byte data) {
        Log.i(TAG, "setAudio16k " + ((int) data));
        JSONObject json = new JSONObject();
        try {
            json.put("EQ16k", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getAudio16k() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "EQ16k", 0);
    }

    public boolean setTreb(byte data) {
        Log.i(TAG, "setTreb : " + ((int) data));
        JSONObject json = new JSONObject();
        try {
            json.put("treb", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getTreb() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "treb", 0);
    }

    public boolean setMid(byte data) {
        Log.i(TAG, "setMid " + ((int) data));
        JSONObject json = new JSONObject();
        try {
            json.put("SYS_MID", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getMid() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "SYS_MID", 0);
    }

    public boolean setBass(byte data) {
        Log.i(TAG, "setBass " + ((int) data));
        JSONObject json = new JSONObject();
        try {
            json.put("bass", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getBass() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "bass", 0);
    }

    public boolean enableLoud(boolean z) {
        Log.i(TAG, "enableLoud " + z);
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("SYS_LOUD", z ? 1 : 0);
            return this.mMcuServiceManager.sendJson(2, jSONObject.toString().getBytes());
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean isLoudEnabled() {
        return this.mMcuServiceManager.getJsonBoolean(2, 1, "SYS_LOUD", false);
    }

    public boolean setFade(byte data) {
        Log.i(TAG, "setFade " + ((int) data));
        JSONObject json = new JSONObject();
        try {
            json.put("audiofade", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getFade() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "audiofade", 0);
    }

    public boolean setBal(byte data) {
        Log.i(TAG, "setBal " + ((int) data));
        JSONObject json = new JSONObject();
        try {
            json.put("audiobal", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getBal() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "audiobal", 0);
    }

    public boolean reqMcuVerInside() {
        Log.i(TAG, "reqMcuVerInside");
        JSONObject json = new JSONObject();
        try {
            json.put("mcuverinside", 0);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean reqCanVer() {
        JSONObject json = new JSONObject();
        try {
            json.put("canver", 0);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "reqCanVer");
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean setMute(boolean z) {
        Log.i(TAG, "setMute " + z);
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("SYS_MUTE", z ? 1 : 0);
            return this.mMcuServiceManager.sendJson(2, jSONObject.toString().getBytes());
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean isMute() {
        return this.mMcuServiceManager.getJsonBoolean(2, 1, "SYS_MUTE", false);
    }

    public boolean setBtVol(byte data) {
        Log.i(TAG, "setBtVol " + ((int) data));
        JSONObject json = new JSONObject();
        try {
            json.put("SYS_BTVOL", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getBtVol() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "SYS_BTVOL", 0);
    }

    public boolean setFmLimiter(byte data) {
        JSONObject json = new JSONObject();
        try {
            json.put("FM_LIMITER", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "setFmLimiter:" + ((int) data));
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getFmLimiter() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "FM_LIMITER", 0);
    }

    public boolean setAmLimiter(byte data) {
        JSONObject json = new JSONObject();
        try {
            json.put("AM_LIMITER", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "setAmLimiter:" + ((int) data));
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getAmLimiter() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "AM_LIMITER", 0);
    }

    public boolean setSpeedAdjustVolume(byte data) {
        JSONObject json = new JSONObject();
        try {
            json.put("carspeed_volume", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "setSpeedAdjustVolume:" + ((int) data));
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getSpeedAdjustVolume() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "carspeed_volume", 0);
    }

    public boolean setTboxVol(byte data) {
        JSONObject json = new JSONObject();
        try {
            json.put("SYS_TBOXVOL", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "setTboxVol:" + ((int) data));
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getTboxVol() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "SYS_TBOXVOL", -1);
    }

    public int getWelcomeState() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "WELCOME_REQ", -1);
    }

    public boolean forceMcuMute(byte data) {
        JSONObject json = new JSONObject();
        try {
            json.put("FORCE_MUTE", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "forceMcuMute:" + ((int) data));
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean setTTSVol(byte data) {
        JSONObject json = new JSONObject();
        try {
            json.put("SYS_TTSVOL", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "setTTSVol:" + ((int) data));
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getTTSVol() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "SYS_TTSVOL", -1);
    }

    public boolean setGPSVol(byte data) {
        JSONObject json = new JSONObject();
        try {
            json.put("SYS_GPSVOL", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "setGPSVol:" + ((int) data));
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getGpsVol() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "SYS_GPSVOL", -1);
    }

    public boolean setDefVol(byte data) {
        JSONObject json = new JSONObject();
        try {
            json.put("defvol", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "setDefVol:" + ((int) data));
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getDefVol() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "defvol", -1);
    }

    public boolean setSysFlag(byte data) {
        JSONObject json = new JSONObject();
        try {
            json.put("SYS_FLAG", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "setSysFlag:" + ((int) data));
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getSysFlag() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "SYS_FLAG", -1);
    }

    public boolean setSysFlag2(byte data) {
        JSONObject json = new JSONObject();
        try {
            json.put("SYS_SYSFLAG2", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "setSysFlag2:" + ((int) data));
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getSysFlag2() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "SYS_SYSFLAG2", -1);
    }

    public boolean setAudioMode(byte data) {
        JSONObject json = new JSONObject();
        try {
            json.put("SYS_AUDIOMODE", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "setAudioMode:" + ((int) data));
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getAudioMode() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "SYS_AUDIOMODE", 0);
    }

    public boolean setTimeFormat24(boolean is24hFormat) {
        Log.i(TAG, "setTimeFormat24 " + is24hFormat);
        JSONObject json = new JSONObject();
        try {
            json.put("SYS_TIME12H", is24hFormat);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean isTimeFormat24() {
        return this.mMcuServiceManager.getJsonBoolean(2, 1, "SYS_TIME12H", false);
    }

    public int getCarDoorUnlockState() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "UNLOCK_STATE", -1);
    }

    public boolean setTftOn(boolean val) {
        JSONObject json = new JSONObject();
        try {
            json.put("TFT1", val);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "setTftOnOff:" + val);
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean isTftOn() {
        return this.mMcuServiceManager.getJsonBoolean(2, 1, "TFT1", true);
    }

    public boolean setTftOn2(boolean val) {
        JSONObject json = new JSONObject();
        try {
            json.put("TFT2", val);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "setTftOnOff2:" + val);
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean isTftOn2() {
        return this.mMcuServiceManager.getJsonBoolean(2, 1, "TFT2", false);
    }

    public boolean setSave1(byte data) {
        Log.i(TAG, "setSave1 " + ((int) data));
        JSONObject json = new JSONObject();
        try {
            json.put("SYS_ARMSAVE1", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getSave1() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "SYS_ARMSAVE1", 0);
    }

    public boolean setSave2(byte data) {
        JSONObject json = new JSONObject();
        try {
            json.put("SYS_ARMSAVE2", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "setSave2:" + ((int) data));
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getSave2() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "SYS_ARMSAVE2", 0);
    }

    public boolean setSave3(byte data) {
        JSONObject json = new JSONObject();
        try {
            json.put("SYS_ARMSAVE3", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getSave3() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "SYS_ARMSAVE3", 0);
    }

    public boolean setAutoBrightOn(boolean open) {
        Log.i(TAG, "setAutoBrightOn open:" + open);
        JSONObject json = new JSONObject();
        try {
            json.put("setautobrighton", open);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean getAutoBrightOn() {
        return this.mMcuServiceManager.getJsonBoolean(2, 1, "setautobrighton", true);
    }

    public boolean setBacklight(byte data) {
        JSONObject json = new JSONObject();
        try {
            json.put("backlight", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "setBacklight:" + ((int) data));
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getBacklight() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "backlight", 5);
    }

    public boolean setViceBacklight(byte data) {
        JSONObject json = new JSONObject();
        try {
            json.put("vicebacklight", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "setViceBacklight:" + ((int) data));
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getViceBacklight() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "vicebacklight", 5);
    }

    public boolean setLanguageToMcu(byte data) {
        JSONObject json = new JSONObject();
        try {
            json.put("LANG_SEL", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getSysLanguage() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "LANG_SEL", 1);
    }

    public boolean setProductInfoToMcu(byte data) {
        JSONObject json = new JSONObject();
        try {
            json.put("PRODUCT_INFO", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getProductInfo() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "PRODUCT_INFO", 0);
    }

    public boolean setFactoryVerCtrl(byte data) {
        JSONObject json = new JSONObject();
        try {
            json.put("CAN_COMPANY", (int) data);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            Log.i(TAG, "setFactoryVerCtrl:" + ((int) data));
            return this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getFactoryVerCtrl() {
        return this.mMcuServiceManager.getJsonInt(2, 1, "CAN_COMPANY", 0);
    }

    public int[] getWheelStudyFlag() {
        return getSettingsInfo().getWheelStudyFlag();
    }

    public void setWheelKeyStudy(int keyVal) {
        JSONObject json = new JSONObject();
        try {
            json.put("setwheel", keyVal);
            String jsonstr = json.toString();
            Log.i(TAG, "sendjson:" + jsonstr.toString());
            byte[] jsondata = jsonstr.getBytes();
            this.mMcuServiceManager.sendJson(2, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public boolean isLearningWheelKey() {
        return getSettingsInfo().isWheelKeyLearning();
    }
}
