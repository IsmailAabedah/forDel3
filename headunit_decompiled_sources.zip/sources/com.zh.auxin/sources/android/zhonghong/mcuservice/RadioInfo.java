package android.zhonghong.mcuservice;

import android.os.Parcel;
import android.os.Parcelable;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class RadioInfo implements Parcelable {
    static final String ARM_CMD_AUX_PLAY_STATE_STRING = "AUX_PLAYSTATE";
    static final String ARM_CMD_RADIO_AFMODE_STRING = "AF";
    static final String ARM_CMD_RADIO_APS_STRING = "aps";
    static final String ARM_CMD_RADIO_AREA_STRING = "RADIO_AREA";
    static final String ARM_CMD_RADIO_EON_STRING = "EON";
    static final String ARM_CMD_RADIO_FREQ_STRING = "freq";
    static final String ARM_CMD_RADIO_GET_FREQ_STRING = "getfreq";
    static final String ARM_CMD_RADIO_INTRO_STRING = "INTRO";
    static final String ARM_CMD_RADIO_LOC_STRING = "loc";
    static final String ARM_CMD_RADIO_NEW_RADIO_HAVESIG_LEVEL_STRING = "signlevel";
    static final String ARM_CMD_RADIO_NEW_RADIO_INTRO_HAVESIG_STRING = "HAVESIG";
    static final String ARM_CMD_RADIO_NEW_RADIO_INTRO_LEGALFREQ_STRING = "LAGEL_FREG";
    static final String ARM_CMD_RADIO_PLAY_STATE_STRING = "RADIO_PLAYSTATE";
    static final String ARM_CMD_RADIO_PS_STRING = "RADIO_NAME";
    static final String ARM_CMD_RADIO_PTY_STRING = "PTY";
    static final String ARM_CMD_RADIO_RDS_ON_OFF_STRING = "RDS_ON_OFF";
    static final String ARM_CMD_RADIO_RDS_TA_MODE_STRING = "RDS_TA_MODE";
    static final String ARM_CMD_RADIO_SCAN_STRING = "scan";
    static final String ARM_CMD_RADIO_SREACH_L_STRING = "RADIO_SREACH_L";
    static final String ARM_CMD_RADIO_SREACH_R_STRING = "RADIO_SREACH_R";
    static final String ARM_CMD_RADIO_SREACH_STATE_STRING = "RADIO_SREACH_STATE";
    static final String ARM_CMD_RADIO_STMODE_STRING = "st";
    static final String ARM_CMD_RADIO_STOPSCAN_STRING = "stop_scan";
    static final String ARM_CMD_RADIO_ST_STRING = "stind";
    static final String ARM_CMD_RADIO_TA_MODE_STRING = "TA_MODE";
    static final String ARM_CMD_RADIO_TEXT_STRING = "RADIO_TEXT";
    static final String ARM_CMD_RADIO_TPINFO_STRING = "TP_INFO";
    static final String ARM_CMD_RADIO_TP_STRING = "TP";
    public static final Parcelable.Creator<RadioInfo> CREATOR = new Parcelable.Creator<RadioInfo>() { // from class: android.zhonghong.mcuservice.RadioInfo.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public RadioInfo createFromParcel(Parcel source) {
            int len = source.readInt();
            int type = source.readInt();
            byte[] data = new byte[len];
            source.readByteArray(data);
            RadioInfo radio = new RadioInfo();
            if (type == 1) {
                String str = new String(data);
                try {
                    JSONObject radioject = new JSONObject(str);
                    radio.freq = radioject.optInt(RadioInfo.ARM_CMD_RADIO_FREQ_STRING, 0);
                    radio.mFreq = radioject.optInt(RadioInfo.ARM_CMD_RADIO_GET_FREQ_STRING, 0);
                    radio.mIsLoc = radioject.optBoolean(RadioInfo.ARM_CMD_RADIO_LOC_STRING, false);
                    radio.mStIsEnable = radioject.optBoolean(RadioInfo.ARM_CMD_RADIO_STMODE_STRING, false);
                    radio.mIsStState = radioject.optBoolean(RadioInfo.ARM_CMD_RADIO_ST_STRING, false);
                    radio.mIsSearching = radioject.optBoolean(RadioInfo.ARM_CMD_RADIO_APS_STRING, false);
                    radio.mScanState = radioject.optInt(RadioInfo.ARM_CMD_RADIO_SCAN_STRING, 0);
                    radio.mLegalFreq = radioject.optInt(RadioInfo.ARM_CMD_RADIO_NEW_RADIO_INTRO_LEGALFREQ_STRING, 0);
                    radio.level = radioject.optInt(RadioInfo.ARM_CMD_RADIO_NEW_RADIO_HAVESIG_LEVEL_STRING, 0);
                    radio.mHasLegalFreq = radioject.optBoolean(RadioInfo.ARM_CMD_RADIO_NEW_RADIO_INTRO_HAVESIG_STRING, false);
                    radio.mArea = radioject.optInt(RadioInfo.ARM_CMD_RADIO_AREA_STRING, 0);
                    radio.mPlaystate = radioject.optInt(RadioInfo.ARM_CMD_RADIO_PLAY_STATE_STRING, 0);
                    radio.auxPlaystate = radioject.optInt(RadioInfo.ARM_CMD_AUX_PLAY_STATE_STRING, 0);
                    radio.mIsLRSeasrching = radioject.optBoolean(RadioInfo.ARM_CMD_RADIO_SREACH_STATE_STRING, false);
                    radio.mIsRdsTaState = radioject.optBoolean(RadioInfo.ARM_CMD_RADIO_TA_MODE_STRING, false);
                    radio.mRdsAfState = radioject.optInt(RadioInfo.ARM_CMD_RADIO_AFMODE_STRING, 0);
                    radio.mRdsPty = radioject.optInt(RadioInfo.ARM_CMD_RADIO_PTY_STRING, 0);
                    radio.mRdsPsInfo = radioject.optString(RadioInfo.ARM_CMD_RADIO_PS_STRING, "");
                    radio.mRdsTraffic = radioject.optBoolean(RadioInfo.ARM_CMD_RADIO_RDS_TA_MODE_STRING, false);
                    radio.mRdsTp = radioject.optBoolean(RadioInfo.ARM_CMD_RADIO_TP_STRING, false);
                    radio.mRdsTpInfo = radioject.optString(RadioInfo.ARM_CMD_RADIO_TPINFO_STRING, "");
                    radio.mRdsEon = radioject.optBoolean(RadioInfo.ARM_CMD_RADIO_EON_STRING, false);
                    radio.mRdsText = radioject.optString(RadioInfo.ARM_CMD_RADIO_TEXT_STRING, "");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return radio;
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public RadioInfo[] newArray(int size) {
            return new RadioInfo[size];
        }
    };
    private int auxPlaystate;
    private int freq;
    private int level;
    private int mArea;
    private int mBand;
    private int mFreq;
    private boolean mHasLegalFreq;
    private boolean mIsLRSeasrching;
    private boolean mIsLoc;
    private boolean mIsRdsTaState;
    private boolean mIsSearching;
    private boolean mIsStState;
    private int mLegalFreq;
    private int mPlaystate;
    private int mRdsAfState;
    private boolean mRdsEon;
    private String mRdsPsInfo;
    private int mRdsPty;
    private String mRdsText;
    private boolean mRdsTp;
    private String mRdsTpInfo;
    private boolean mRdsTraffic;
    private int mScanState;
    private boolean mStIsEnable;

    public int getFreq() {
        return this.mFreq;
    }

    public boolean isScan() {
        return this.mScanState == 1;
    }

    public boolean isLoc() {
        return this.mIsLoc;
    }

    public boolean isSt() {
        return this.mStIsEnable;
    }

    public boolean isStind() {
        return this.mIsStState;
    }

    public boolean isSearch() {
        return this.mIsSearching;
    }

    public boolean isLRSearch() {
        return this.mIsLRSeasrching;
    }

    public boolean isHasLegalFreq() {
        return this.mHasLegalFreq;
    }

    public int getLegalFreq() {
        return this.mLegalFreq;
    }

    public int getArea() {
        return this.mArea;
    }

    public int getTunerLevel() {
        return this.level;
    }

    public int getBand() {
        return this.mBand;
    }

    public int getPlayState() {
        return this.mPlaystate;
    }

    public int getAuxPlayState() {
        return this.auxPlaystate;
    }

    public boolean getRdsTa() {
        return this.mIsRdsTaState;
    }

    public int getRdsAf() {
        return this.mRdsAfState;
    }

    public int getRdsPty() {
        return this.mRdsPty;
    }

    public String getRdsPsInfo() {
        return this.mRdsPsInfo;
    }

    public boolean getRdsTraffic() {
        return this.mRdsTraffic;
    }

    public boolean getRdsTp() {
        return this.mRdsTp;
    }

    public String getRdsTpInfo() {
        return this.mRdsTpInfo;
    }

    public boolean getRdsEon() {
        return this.mRdsEon;
    }

    public String getRdsText() {
        return this.mRdsText;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.freq);
        parcel.writeInt(this.mScanState);
        parcel.writeInt(this.mIsLoc ? 1 : 0);
        parcel.writeInt(this.mStIsEnable ? 1 : 0);
        parcel.writeInt(this.mIsStState ? 1 : 0);
        parcel.writeInt(this.mIsSearching ? 1 : 0);
    }

    public String toString() {
        return "RadioInfo [mFreq=" + this.mFreq + ", mScanState=" + this.mScanState + ", mLegalFreq=" + this.mLegalFreq + ", mBand=" + this.mBand + ", mPlaystate=" + this.mPlaystate + ", mIsStState=" + this.mIsStState + ", mIsSearching=" + this.mIsSearching + ", mIsLRSeasrching=" + this.mIsLRSeasrching + ", mHasLegalFreq=" + this.mHasLegalFreq + ", mIsLoc=" + this.mIsLoc + ", mStIsEnable=" + this.mStIsEnable + "]";
    }
}
