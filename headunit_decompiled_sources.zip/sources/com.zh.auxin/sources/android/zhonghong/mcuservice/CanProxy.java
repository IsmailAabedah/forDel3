package android.zhonghong.mcuservice;

import android.util.Log;
import android.zhonghong.mcuservice.RegistManager;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class CanProxy {
    private static final String ARM_CMD_CAN_REQ_INIT_INFO_STRING = "REQ_CAN_INIT_INFO";
    private static final String ARM_CMD_CAN_SEND_DATA0_STRING = "SEND_DATA0";
    private static final String ARM_CMD_CAN_SEND_DATA1_STRING = "SEND_DATA1";
    private static final String ARM_CMD_CAN_SEND_DATA2_STRING = "SEND_DATA2";
    private static final String ARM_CMD_CAN_SEND_DATA3_STRING = "SEND_DATA3";
    private static final String ARM_CMD_CAN_SET_DATA0_STRING = "SET_DATA0";
    private static final String ARM_CMD_CAN_SET_DATA1_STRING = "SET_DATA1";
    private static final String ARM_CMD_CAN_SET_DATA2_STRING = "SET_DATA2";
    private static final String ARM_CMD_CAN_SET_DATA3_STRING = "SET_DATA3";
    private static final String TAG = "CanProxy";

    public boolean registCanInfoChangedListener(RegistManager.ICanInfoChangedListener listener) {
        return RegistManager.getInstance().addCanInfoChangedListener(listener);
    }

    public boolean unregistCanInfoChangeListener(RegistManager.ICanInfoChangedListener listener) {
        return RegistManager.getInstance().removeCanInfoChangedListener(listener);
    }

    public boolean sendCanDataToMcu(byte[] data) {
        return McuServiceManager.getInstance().sendData(5, data);
    }

    public boolean reqCanInitInfo(int type) {
        Log.i(TAG, "reqCanInitInfo type = " + type);
        JSONObject json = new JSONObject();
        try {
            json.put(ARM_CMD_CAN_REQ_INIT_INFO_STRING, type);
            String jsonstr = json.toString();
            byte[] data = jsonstr.getBytes();
            return McuServiceManager.getInstance().sendJson(5, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean fullSetCanData(byte[] data) {
        return McuServiceManager.getInstance().sendData(9, data);
    }

    public boolean setCanData(int moduleID, int index, int length, int what) {
        JSONObject json = new JSONObject();
        try {
            json.put(ARM_CMD_CAN_SET_DATA0_STRING, moduleID);
            json.put(ARM_CMD_CAN_SET_DATA1_STRING, index);
            json.put(ARM_CMD_CAN_SET_DATA2_STRING, length);
            json.put(ARM_CMD_CAN_SET_DATA3_STRING, what);
            String jsonstr = json.toString();
            byte[] data = jsonstr.getBytes();
            return McuServiceManager.getInstance().sendJson(9, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean sendCanData(int moduleID, int index, int length, int what) {
        JSONObject json = new JSONObject();
        try {
            json.put(ARM_CMD_CAN_SEND_DATA0_STRING, moduleID);
            json.put(ARM_CMD_CAN_SEND_DATA1_STRING, index);
            json.put(ARM_CMD_CAN_SEND_DATA2_STRING, length);
            json.put(ARM_CMD_CAN_SEND_DATA3_STRING, what);
            String jsonstr = json.toString();
            byte[] data = jsonstr.getBytes();
            return McuServiceManager.getInstance().sendJson(9, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }
}
