package android.zhonghong.mcuservice;

import android.zhonghong.mcuservice.RegistManager;

/* loaded from: classes.dex */
public class TouchProxy {
    public boolean registTouchInfoChangedListener(RegistManager.ITouchInfoChangedListener listener) {
        return RegistManager.getInstance().addTouchInfoChangedListener(listener);
    }

    public boolean unregistTouchInfoChangedListener(RegistManager.ITouchInfoChangedListener listener) {
        RegistManager.getInstance().removeTouchInfoChangedListener(listener);
        return true;
    }
}
