package android.zhonghong.mcuservice;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.zhonghong.mcuservice.IDataChangedListener;

/* loaded from: classes.dex */
public interface IMcuService extends IInterface {
    int getTest() throws RemoteException;

    boolean obtainInfo(int i, int i2, Parcel parcel, Parcel parcel2) throws RemoteException;

    int registDataChangedListener(int i, IDataChangedListener iDataChangedListener) throws RemoteException;

    boolean sendInfo(int i, int i2, Parcel parcel) throws RemoteException;

    int unregistDataChangedListener(int i, IDataChangedListener iDataChangedListener) throws RemoteException;

    public static abstract class Stub extends Binder implements IMcuService {
        private static final String DESCRIPTOR = "android.zhonghong.IMcuService";
        static final int TRANSACTION_GET_TEST = 2;
        static final int TRANSACTION_OBTAIN_INFO = 3;
        static final int TRANSACTION_REGIST_DATA_CHANGED_LISTENER = 5;
        static final int TRANSACTION_REGIST_DATA_UNCHANGED_LISTENER = 6;
        static final int TRANSACTION_SEND_INFO = 4;

        public Stub() {
            attachInterface(this, DESCRIPTOR);
        }

        public static IMcuService asInterface(IBinder obj) {
            if (obj == null) {
                return null;
            }
            IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
            if (iin != null && (iin instanceof IMcuService)) {
                return (IMcuService) iin;
            }
            return new Proxy(obj);
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i == 1598968902) {
                parcel2.writeString(DESCRIPTOR);
                return true;
            }
            switch (i) {
                case 2:
                    parcel.enforceInterface(DESCRIPTOR);
                    int test = getTest();
                    parcel2.writeNoException();
                    parcel2.writeInt(test);
                    return true;
                case 3:
                    parcel.enforceInterface(DESCRIPTOR);
                    int readInt = parcel.readInt();
                    int readInt2 = parcel.readInt();
                    Parcel obtain = Parcel.obtain();
                    Parcel obtain2 = Parcel.obtain();
                    if (parcel.dataAvail() > 0) {
                        obtain2.appendFrom(parcel, parcel.dataPosition(), parcel.dataSize() - parcel.dataPosition());
                        obtain2.setDataPosition(0);
                    }
                    boolean obtainInfo = obtainInfo(readInt, readInt2, obtain2, obtain);
                    if (obtain != null && obtain.dataSize() > 0) {
                        parcel2.appendFrom(obtain, 0, obtain.dataSize());
                    }
                    parcel2.writeInt(obtainInfo ? 1 : 0);
                    return true;
                case 4:
                    parcel.enforceInterface(DESCRIPTOR);
                    int readInt3 = parcel.readInt();
                    int readInt4 = parcel.readInt();
                    Parcel obtain3 = Parcel.obtain();
                    if (parcel.dataAvail() > 0) {
                        obtain3.appendFrom(parcel, parcel.dataPosition(), parcel.dataSize() - parcel.dataPosition());
                        obtain3.setDataPosition(0);
                    }
                    parcel2.writeInt(sendInfo(readInt3, readInt4, obtain3) ? 1 : 0);
                    return true;
                case 5:
                    parcel.enforceInterface(DESCRIPTOR);
                    parcel2.writeInt(registDataChangedListener(parcel.readInt(), IDataChangedListener.Stub.asInterface(parcel.readStrongBinder())));
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }

        private static class Proxy implements IMcuService {
            private IBinder mRemote;

            Proxy(IBinder remote) {
                this.mRemote = remote;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return Stub.DESCRIPTOR;
            }

            @Override // android.zhonghong.mcuservice.IMcuService
            public int getTest() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    this.mRemote.transact(2, _data, _reply, 0);
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.zhonghong.mcuservice.IMcuService
            public boolean obtainInfo(int domain, int cmd, Parcel in, Parcel out) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeInt(domain);
                    _data.writeInt(cmd);
                    if (in != null && in.dataSize() > 0) {
                        _data.appendFrom(in, 0, in.dataSize());
                    }
                    this.mRemote.transact(3, _data, _reply, 0);
                    if (_reply != null && _reply.dataSize() > 4) {
                        out.appendFrom(_reply, 0, _reply.dataSize() - 4);
                        out.setDataPosition(0);
                    }
                    _reply.setDataPosition(_reply.dataSize() - 4);
                    boolean _result = _reply.readInt() == 1;
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.zhonghong.mcuservice.IMcuService
            public boolean sendInfo(int domain, int cmd, Parcel in) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeInt(domain);
                    _data.writeInt(cmd);
                    if (in != null && in.dataSize() > 0) {
                        _data.appendFrom(in, 0, in.dataSize());
                    }
                    this.mRemote.transact(4, _data, _reply, 0);
                    boolean _result = _reply.readInt() == 1;
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.zhonghong.mcuservice.IMcuService
            public int registDataChangedListener(int domain, IDataChangedListener listener) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeInt(domain);
                    _data.writeStrongBinder(listener != null ? listener.asBinder() : null);
                    this.mRemote.transact(5, _data, _reply, 0);
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.zhonghong.mcuservice.IMcuService
            public int unregistDataChangedListener(int domain, IDataChangedListener listener) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeInt(domain);
                    _data.writeStrongBinder(listener != null ? listener.asBinder() : null);
                    this.mRemote.transact(6, _data, _reply, 0);
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }
        }
    }
}
