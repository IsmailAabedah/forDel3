package android.zhonghong.mcuservice;

import android.zhonghong.mcuservice.RegistManager;

/* loaded from: classes.dex */
public class SystemKeyProxy {
    final String TAG = "SystemKeyProxy";

    public boolean registSystemKeyInfoChangedListener(RegistManager.ISystemKeyInfoChangedListener listener) {
        return RegistManager.getInstance().addSystemKeyInfoChangedListener(listener);
    }

    public boolean unregistSystemKeyInfoChangedListener(RegistManager.ISystemKeyInfoChangedListener listener) {
        RegistManager.getInstance().removeSystemKeyInfoChangedListener(listener);
        return true;
    }

    public boolean registSystemKey(int data) {
        RegistManager.getInstance().addSystemKey(data);
        return McuServiceManager.getInstance().sendInt(4352, data, 0);
    }

    public boolean cleanSystemKey(int data) {
        RegistManager.getInstance().removeSystemKey(data);
        return McuServiceManager.getInstance().sendInt(4353, data, 0);
    }
}
