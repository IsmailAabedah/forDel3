package android.zhonghong.mcuservice;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public class TouchInfo implements Parcelable {
    public static final Parcelable.Creator<TouchInfo> CREATOR = new Parcelable.Creator<TouchInfo>() { // from class: android.zhonghong.mcuservice.TouchInfo.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public TouchInfo createFromParcel(Parcel source) {
            TouchInfo syskey = new TouchInfo();
            syskey.x = source.readInt();
            syskey.y = source.readInt();
            syskey.point = source.readInt();
            syskey.time = source.readInt();
            syskey.state = source.readInt();
            return syskey;
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public TouchInfo[] newArray(int arg0) {
            return new TouchInfo[arg0];
        }
    };
    public int point;
    public int state;
    public int time;
    public int x;
    public int y;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int arg1) {
    }
}
