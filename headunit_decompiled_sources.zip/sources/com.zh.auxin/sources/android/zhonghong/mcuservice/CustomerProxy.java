package android.zhonghong.mcuservice;

import android.zhonghong.mcuservice.RegistManager;

/* loaded from: classes.dex */
public class CustomerProxy {
    public boolean registCustomerInfoChangedListener(RegistManager.ICustomerInfoChangedListener listener) {
        return RegistManager.getInstance().addCustomerInfoChangedListener(listener);
    }

    public boolean unregistCustomerInfoChangeListener(RegistManager.ICustomerInfoChangedListener listener) {
        return RegistManager.getInstance().removeCustomerInfoChangedListener(listener);
    }

    public boolean sendCustomerDataToMcu(byte[] data) {
        return McuServiceManager.getInstance().sendData(6, data);
    }
}
