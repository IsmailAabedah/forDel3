package android.zhonghong.mcuservice;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* loaded from: classes.dex */
public interface IDataChangedListener extends IInterface {
    void notify(int i, int i2, int i3, Parcel parcel) throws RemoteException;

    public static abstract class Stub extends Binder implements IDataChangedListener {
        private static final String DESCRIPTOR = "android.zhonghong.IDataChangedListener";
        private static final String TAG = "leo";
        static final int TRANSACTION_notify = 2;

        public Stub() {
            attachInterface(this, DESCRIPTOR);
        }

        public static IDataChangedListener asInterface(IBinder obj) {
            if (obj == null) {
                return null;
            }
            IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
            if (iin != null && (iin instanceof IDataChangedListener)) {
                return (IDataChangedListener) iin;
            }
            return new Proxy(obj);
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }

        @Override // android.os.Binder
        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            if (code != 2) {
                if (code == 1598968902) {
                    reply.writeString(DESCRIPTOR);
                    return true;
                }
                return super.onTransact(code, data, reply, flags);
            }
            data.enforceInterface(DESCRIPTOR);
            int msg = data.readInt();
            int ext0 = data.readInt();
            int ext1 = data.readInt();
            Parcel p = null;
            if (data.dataAvail() > 0) {
                p = Parcel.obtain();
                p.appendFrom(data, data.dataPosition(), data.dataSize() - data.dataPosition());
                p.setDataPosition(0);
            }
            notify(msg, ext0, ext1, p);
            return true;
        }

        private static class Proxy implements IDataChangedListener {
            private IBinder mRemote;

            Proxy(IBinder remote) {
                this.mRemote = remote;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return Stub.DESCRIPTOR;
            }

            @Override // android.zhonghong.mcuservice.IDataChangedListener
            public void notify(int msg, int ext0, int ext1, Parcel parcel) throws RemoteException {
                Parcel _data = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeInt(msg);
                    _data.writeInt(ext0);
                    _data.writeInt(ext1);
                    if (parcel != null && parcel.dataSize() > 0) {
                        _data.appendFrom(parcel, 0, parcel.dataSize());
                    }
                    this.mRemote.transact(2, _data, null, 1);
                } finally {
                    _data.recycle();
                }
            }
        }
    }
}
