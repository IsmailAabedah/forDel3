package android.zhonghong.mcuservice;

import android.os.Parcel;
import android.util.Log;
import android.zhonghong.mcuservice.RegistManager;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class SystemProxy {
    private static final int DOMAIN = 3;
    final String TAG = "SystemProxy";
    private McuServiceManager mMcuServiceManager = McuServiceManager.getInstance();

    public boolean registSystemInfoChangedListener(RegistManager.ISystemInfoChangedListener listener) {
        return RegistManager.getInstance().addSysInfoChangedListener(listener);
    }

    public boolean unregistSystemInfoChangedListener(RegistManager.ISystemInfoChangedListener listener) {
        return RegistManager.getInstance().removeSysInfoChangedListener(listener);
    }

    public JSONObject getSystemInfoJson() {
        return this.mMcuServiceManager.obtainAllJsonMsg(3, 1);
    }

    public SystemInfo getSystemInfo() {
        Parcel out = Parcel.obtain();
        this.mMcuServiceManager.obtainAllParcel(3, 1, out);
        SystemInfo system = SystemInfo.CREATOR.createFromParcel(out);
        out.recycle();
        return system;
    }

    public boolean sendCmd(byte[] data) {
        Log.i("SystemProxy", "sendCmd");
        return this.mMcuServiceManager.sendData(3, data);
    }

    public boolean setMcuSource(int source) {
        Log.i("SystemProxy", "setMcuSource:" + source);
        JSONObject scanjson = new JSONObject();
        try {
            scanjson.put("MCU_SOURCE", source);
            String jsonstr = scanjson.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(3, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getMcuSource() {
        return this.mMcuServiceManager.getJsonInt(3, 1, "MCU_SOURCE", 0);
    }

    public boolean sendPowerKeyToMcu() {
        Log.i("SystemProxy", "sendPowerKeyToMcu");
        JSONObject scanjson = new JSONObject();
        try {
            scanjson.put("power_key", 0);
            String jsonstr = scanjson.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(3, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean sendResetKeyToMcu() {
        Log.i("SystemProxy", "sendPowerKeyToMcu");
        JSONObject scanjson = new JSONObject();
        try {
            scanjson.put("reset_key", 0);
            String jsonstr = scanjson.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(3, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean sendUpdateStateToMcu(int state) {
        Log.i("SystemProxy", "sendUpdateStateToMcu state =" + state);
        JSONObject scanjson = new JSONObject();
        try {
            scanjson.put("update_state", state);
            String jsonstr = scanjson.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(3, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean reqMcuPoweron() {
        JSONObject json = new JSONObject();
        try {
            json.put("REQ_POWERON", 1);
            String jsonstr = json.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(3, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean sendResetCmdToMcu(int cmd) {
        JSONObject json = new JSONObject();
        try {
            json.put("REQ_RESET", cmd);
            String jsonstr = json.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(3, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean notifyUnrealPoweroffToMcu(int cmd) {
        JSONObject json = new JSONObject();
        try {
            json.put("REQ_UNREAL_POWEROFF", cmd);
            String jsonstr = json.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(3, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean notifyAnimationToMcu(int cmd) {
        JSONObject json = new JSONObject();
        try {
            json.put("ENTER_ANIMATION", cmd);
            String jsonstr = json.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(3, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean notifyNaviVoiceToMcu(int cmd) {
        JSONObject json = new JSONObject();
        try {
            json.put("NAVI_VOICE", cmd);
            String jsonstr = json.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(3, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean notifyMcuMute1S() {
        JSONObject json = new JSONObject();
        try {
            json.put("MUTE_1S", 1);
            String jsonstr = json.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(3, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean sendBeepToMcu() {
        JSONObject json = new JSONObject();
        try {
            json.put("REQ_BEEP", 1);
            String jsonstr = json.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(3, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean setMcuStateByBit(int state) {
        Log.i("SystemProxy", "setMcuState " + state);
        if (state < 0 || state > 15) {
            Log.i("SystemProxy", "setMcuState err cmd[0,15] :" + state);
            return false;
        }
        JSONObject json = new JSONObject();
        try {
            json.put("MCU_STATE_SET", state);
            String jsonstr = json.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(3, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean setMcuState(int state) {
        Log.i("SystemProxy", "setMcuState:" + state);
        JSONObject json = new JSONObject();
        try {
            json.put("MCU_STATE", state);
            String jsonstr = json.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(3, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean clearMcuStateByBit(int state) {
        Log.i("SystemProxy", "clearStateToMcu " + state);
        if (state < 0 || state > 15) {
            Log.i("SystemProxy", "clearMcuState err cmd[0,15] :" + state);
            return false;
        }
        JSONObject json = new JSONObject();
        try {
            json.put("MCU_STATE_CLEAR", state);
            String jsonstr = json.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(3, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getMcuState() {
        return this.mMcuServiceManager.getJsonInt(3, 1, "MCU_STATE", 0);
    }

    public boolean getBPowerOn() {
        return this.mMcuServiceManager.getJsonBoolean(3, 1, "BPOWER_ON", false);
    }

    public boolean setBPowerOnFalse() {
        Log.i("SystemProxy", "setBPowerOnFalse");
        JSONObject json = new JSONObject();
        try {
            json.put("BPOWER_ON", 0);
            String jsonstr = json.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(3, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean getViceDriverHeadPhone() {
        return this.mMcuServiceManager.getJsonBoolean(3, 1, "VICEDIRVER_HEADPHONE", false);
    }

    public int getBrightTurner() {
        return this.mMcuServiceManager.getJsonInt(3, 1, "BRIGHT_TURNER", 100);
    }

    public byte[] getReservedData() {
        byte[] ReservedData = new byte[30];
        Parcel source = Parcel.obtain();
        this.mMcuServiceManager.getPracel(3, 3, source);
        if (source != null) {
            int len = source.readInt();
            source.readInt();
            byte[] data = new byte[len];
            if (len > 0) {
                source.readByteArray(data);
                String str = new String(data);
                try {
                    JSONObject myJson = new JSONObject(str);
                    if (myJson != null) {
                        for (int i = 0; i < myJson.length(); i++) {
                            ReservedData[i] = (byte) myJson.optInt("BLOCK_NO" + i, 0);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                } finally {
                    source.recycle();
                }
            }
        }
        return ReservedData;
    }

    public boolean isParking() {
        return this.mMcuServiceManager.getJsonBoolean(3, 1, "BACK_SIGNAL", false);
    }

    public boolean isSysReady() {
        return this.mMcuServiceManager.getJsonBoolean(3, 1, "SYSREADY", true);
    }

    public boolean isAccOn() {
        return this.mMcuServiceManager.getJsonBoolean(3, 1, "ACC_STATE", true);
    }

    public int getShowTouchDialogState() {
        return this.mMcuServiceManager.getJsonInt(3, 1, "NEED_SHOWDIALOG", 0);
    }

    public boolean isPowerOnState() {
        return this.mMcuServiceManager.getJsonBoolean(3, 1, "POWER_STATE", false);
    }

    public long getMcuTime() {
        return this.mMcuServiceManager.getJsonLong(3, 1, "MCU_TIME", 0L);
    }

    public long getSysTime() {
        return this.mMcuServiceManager.getJsonLong(3, 1, "SYS_TIME", 0L);
    }

    public boolean isIllState() {
        return this.mMcuServiceManager.getJsonBoolean(3, 1, "ILL_STATE", false);
    }
}
