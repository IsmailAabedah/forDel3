package android.zhonghong.mcuservice;

import android.os.Parcel;

/* loaded from: classes.dex */
class DataUtils {
    DataUtils() {
    }

    static short[] toShortArray(byte[] arr) {
        if (arr == null || arr.length == 0) {
            return null;
        }
        short[] result = new short[arr.length];
        for (int i = 0; i < arr.length; i++) {
            result[i] = toUnsigned(arr[i]);
        }
        return result;
    }

    static short toUnsigned(byte b) {
        return (short) (b & 255);
    }

    static short[] toShortArray(Parcel p) {
        if (p == null) {
            return null;
        }
        int len = p.readInt();
        p.readInt();
        byte[] result = new byte[len];
        p.readByteArray(result);
        return toShortArray(result);
    }

    static byte[] toByteArray(Parcel p) {
        if (p == null) {
            return null;
        }
        int len = p.readInt();
        p.readInt();
        byte[] result = new byte[len];
        p.readByteArray(result);
        return result;
    }
}
