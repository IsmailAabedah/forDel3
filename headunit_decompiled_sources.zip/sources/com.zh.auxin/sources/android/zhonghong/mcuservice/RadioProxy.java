package android.zhonghong.mcuservice;

import android.os.Parcel;
import android.util.Log;
import android.zhonghong.mcuservice.RegistManager;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class RadioProxy {
    static final int DOMAIN = 1;
    public static final int RADIO_BAND_AM = 3;
    public static final int RADIO_BAND_FM = 0;
    static final String TAG = "RadioProxy";
    private McuServiceManager mMcuServiceManager = McuServiceManager.getInstance();

    public boolean registRadioInfoChangedListener(RegistManager.IRadioInfoChangedListener listener) {
        return RegistManager.getInstance().addRadioInfoChangedListener(listener);
    }

    public boolean unregistRadioInfoChangedListener(RegistManager.IRadioInfoChangedListener listener) {
        return RegistManager.getInstance().removeRadioInfoChangedListener(listener);
    }

    public JSONObject getRadioJson() {
        return this.mMcuServiceManager.obtainAllJsonMsg(1, 1);
    }

    public RadioInfo getRadioInfo() {
        Parcel out = Parcel.obtain();
        this.mMcuServiceManager.obtainAllParcel(1, 1, out);
        RadioInfo radio = RadioInfo.CREATOR.createFromParcel(out);
        out.recycle();
        return radio;
    }

    public boolean sendCmd(byte[] data) {
        Log.i(TAG, "sendCmd");
        return this.mMcuServiceManager.sendData(1, data);
    }

    public boolean setFreq(int band, int freq) {
        Log.i(TAG, "setFreq band = " + band + " freq " + freq);
        if (band != 3 && band != 0) {
            Log.w(TAG, " Error band!");
            return false;
        }
        int temp = (band << 14) | (freq & 16383);
        JSONObject scanjson = new JSONObject();
        try {
            scanjson.put("freq", temp);
            String jsonstr = scanjson.toString();
            byte[] data = jsonstr.getBytes();
            Log.i(TAG, "2 setFraq band = " + band + " freq = " + freq);
            return this.mMcuServiceManager.sendJson(1, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getFreq() {
        return this.mMcuServiceManager.getJsonInt(1, 1, "getfreq", 0);
    }

    public boolean setScan() {
        Log.i(TAG, "setScan");
        JSONObject scanjson = new JSONObject();
        try {
            scanjson.put("scan", 0);
            String jsonstr = scanjson.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(1, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getScan() {
        return this.mMcuServiceManager.getJsonInt(1, 1, "scan", 0);
    }

    public boolean setLoc() {
        Log.i(TAG, "setLoc");
        JSONObject scanjson = new JSONObject();
        try {
            scanjson.put("loc", 0);
            String jsonstr = scanjson.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(1, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean getLoc() {
        return this.mMcuServiceManager.getJsonBoolean(1, 1, "loc", false);
    }

    public boolean setSt() {
        Log.i(TAG, "setSt");
        JSONObject scanjson = new JSONObject();
        try {
            scanjson.put("st", 0);
            String jsonstr = scanjson.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(1, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean getSt() {
        return this.mMcuServiceManager.getJsonBoolean(1, 1, "st", false);
    }

    public boolean getStInd() {
        return this.mMcuServiceManager.getJsonBoolean(1, 1, "stind", false);
    }

    public boolean setSearch() {
        Log.i(TAG, "setSearch");
        JSONObject scanjson = new JSONObject();
        try {
            scanjson.put("aps", 0);
            String jsonstr = scanjson.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(1, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean getSearch() {
        return this.mMcuServiceManager.getJsonBoolean(1, 1, "aps", false);
    }

    public int getArea() {
        return this.mMcuServiceManager.getJsonInt(1, 1, "RADIO_AREA", 0);
    }

    public boolean getRadioMute() {
        return false;
    }

    public boolean setRadioMute(boolean mute) {
        return false;
    }

    public boolean setSearchRight() {
        Log.i(TAG, "setSearchRight");
        JSONObject scanjson = new JSONObject();
        try {
            scanjson.put("RADIO_SREACH_R", 0);
            String jsonstr = scanjson.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(4, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean setSearchLeft() {
        Log.i(TAG, "setSearchLeft");
        JSONObject scanjson = new JSONObject();
        try {
            scanjson.put("RADIO_SREACH_L", 0);
            String jsonstr = scanjson.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(4, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean isLRSearch() {
        return this.mMcuServiceManager.getJsonBoolean(1, 1, "RADIO_SREACH_STATE", false);
    }

    public boolean stopAllSearchMode() {
        Log.i(TAG, "stopAllSearchMode");
        JSONObject scanjson = new JSONObject();
        try {
            scanjson.put("stop_scan", 0);
            String jsonstr = scanjson.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(1, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean setPlayState(int state) {
        Log.i(TAG, "setPlayState " + state);
        JSONObject scanjson = new JSONObject();
        try {
            scanjson.put("RADIO_PLAYSTATE", state);
            String jsonstr = scanjson.toString();
            byte[] data = jsonstr.getBytes();
            return this.mMcuServiceManager.sendJson(1, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getPlayState() {
        return this.mMcuServiceManager.getJsonInt(1, 1, "RADIO_PLAYSTATE", 0);
    }

    public boolean setAuxPlayState(int state) {
        JSONObject scanjson = new JSONObject();
        try {
            scanjson.put("AUX_PLAYSTATE", state);
            String jsonstr = scanjson.toString();
            byte[] data = jsonstr.getBytes();
            Log.i(TAG, "setAuxPlayState:" + state);
            return this.mMcuServiceManager.sendJson(1, data);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getAuxPlayState() {
        return this.mMcuServiceManager.getJsonInt(1, 1, "AUX_PLAYSTATE", 0);
    }

    public void setClickTA() {
        JSONObject scanjson = new JSONObject();
        try {
            scanjson.put("TA_MODE", 0);
            String jsonstr = scanjson.toString();
            byte[] data = jsonstr.getBytes();
            this.mMcuServiceManager.sendJson(1, data);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void setClickAF() {
        JSONObject scanjson = new JSONObject();
        try {
            scanjson.put("AF", 0);
            String jsonstr = scanjson.toString();
            byte[] data = jsonstr.getBytes();
            this.mMcuServiceManager.sendJson(1, data);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void setRdsOnOff(boolean isOn) {
        JSONObject scanjson = new JSONObject();
        try {
            scanjson.put("RDS_ON_OFF", isOn);
            String jsonstr = scanjson.toString();
            byte[] data = jsonstr.getBytes();
            this.mMcuServiceManager.sendJson(1, data);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void setRdsPty(int type) {
        JSONObject scanjson = new JSONObject();
        try {
            scanjson.put("PTY", type);
            String jsonstr = scanjson.toString();
            byte[] data = jsonstr.getBytes();
            this.mMcuServiceManager.sendJson(1, data);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void setFactoryRadioArea(int area) {
        Log.i(TAG, "setFactoryRadioArea " + area);
        JSONObject json = new JSONObject();
        try {
            json.put("RADIO_AREA", area);
            String jsonstr = json.toString();
            byte[] jsondata = jsonstr.getBytes();
            this.mMcuServiceManager.sendJson(1, jsondata);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
