package android.zhonghong.mcuservice;

import android.os.Parcel;
import android.os.Parcelable;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class SystemInfo implements Parcelable {
    static final String ARM_CMD_KEY_POWER = "power_key";
    static final String ARM_CMD_KEY_RESET = "reset_key";
    static final String ARM_CMD_MCUSOURCE_DATA_KEYSTRING = "MCU_SOURCE";
    static final String ARM_CMD_MCUSTATE_CLEAR_DATA_KEYSTRING = "MCU_STATE_CLEAR";
    static final String ARM_CMD_MCUSTATE_DATA_KEYSTRING = "MCU_STATE";
    static final String ARM_CMD_MCUSTATE_SET_DATA_KEYSTRING = "MCU_STATE_SET";
    static final String ARM_CMD_MCU_UPDATE_STATE = "update_state";
    static final String ARM_CMD_SYS_ACC_STATE_KEYSTRING = "ACC_STATE";
    static final String ARM_CMD_SYS_BACKSIGHT_KEYSTRING = "BACK_SIGNAL";
    static final String ARM_CMD_SYS_CARRUN_KEYSTRING = "CAR_RUN";
    static final String ARM_CMD_SYS_CARSPEED_KEYSTRING = "CAR_SPEED";
    static final String ARM_CMD_SYS_ILLON_KEYSTRING = "ILL_STATE";
    static final String ARM_CMD_SYS_LAST_DEVEICE_KEYSTRING = "LAST_DEVEICE";
    static final String ARM_CMD_SYS_SOURECEVAILDFLAG_KEYSTRING = "SOURCE_VAILFLAG";
    static final String ARM_DATA_BLOCK_NO_KEYSTRING = "BLOCK_NO";
    static final String ARM_DATA_MCUTIME_KEYSTRING = "MCU_TIME";
    static final String ARM_DATA_MUTE1S_TO_MCU = "MUTE_1S";
    static final String ARM_DATA_NAVI_VOICE_TO_MCU = "NAVI_VOICE";
    static final String ARM_DATA_POWER_STATE_KEYSTRING = "POWER_STATE";
    static final String ARM_DATA_RADARBEEP_KEYSTRING = "RADAR_BEEP";
    static final String ARM_DATA_RESERVED_BLOCK_KEYSTRING = "RESERVED_BLOCK";
    static final String ARM_DATA_SYSTIME_KEYSTRING = "SYS_TIME";
    static final String ARM_DATA_SYS_BPOWER_ON_KEYSTRING = "BPOWER_ON";
    static final String ARM_DATA_SYS_BRIGHT_TURNER = "BRIGHT_TURNER";
    static final String ARM_DATA_SYS_ENTER_ANIMATION_KEYSTRING = "ENTER_ANIMATION";
    static final String ARM_DATA_SYS_NEED_SHOWDIALOG_KEYSTRING = "NEED_SHOWDIALOG";
    static final String ARM_DATA_SYS_REQ_POWERON_KEYSTRING = "REQ_POWERON";
    static final String ARM_DATA_SYS_REQ_RESET_KEYSTRING = "REQ_RESET";
    static final String ARM_DATA_SYS_REQ_UNREAL_POWEROFF_KEYSTRING = "REQ_UNREAL_POWEROFF";
    static final String ARM_DATA_SYS_SYSREADY_KEYSTRING = "SYSREADY";
    static final String ARM_DATA_SYS_SYSREQBEEP_KEYSTRING = "REQ_BEEP";
    static final String ARM_DATA_SYS_VICEDIRVER_HEADPHONE = "VICEDIRVER_HEADPHONE";
    public static final int AUDIO_MODE_CLASS = 3;
    public static final int AUDIO_MODE_DANCE = 8;
    public static final int AUDIO_MODE_FLAT = 4;
    public static final int AUDIO_MODE_JAZZ = 5;
    public static final int AUDIO_MODE_NORMAL = 10;
    public static final int AUDIO_MODE_POP = 1;
    public static final int AUDIO_MODE_ROCK = 2;
    public static final int AUDIO_MODE_STD = 7;
    public static final int AUDIO_MODE_USER = 0;
    public static final int AUDIO_MODE_VOCAL = 6;
    public static final Parcelable.Creator<SystemInfo> CREATOR = new Parcelable.Creator<SystemInfo>() { // from class: android.zhonghong.mcuservice.SystemInfo.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SystemInfo createFromParcel(Parcel source) {
            int len = source.readInt();
            int type = source.readInt();
            byte[] data = new byte[len];
            source.readByteArray(data);
            SystemInfo sysinfo = new SystemInfo();
            if (type == 1) {
                String str = new String(data);
                try {
                    JSONObject mcujson = new JSONObject(str);
                    sysinfo.mIsParking = mcujson.optBoolean(SystemInfo.ARM_CMD_SYS_BACKSIGHT_KEYSTRING, false);
                    sysinfo.mSysReady = mcujson.optBoolean(SystemInfo.ARM_DATA_SYS_SYSREADY_KEYSTRING, true);
                    sysinfo.mAccState = mcujson.optBoolean(SystemInfo.ARM_CMD_SYS_ACC_STATE_KEYSTRING, true);
                    sysinfo.mIsCarRunning = mcujson.optBoolean(SystemInfo.ARM_CMD_SYS_CARRUN_KEYSTRING, true);
                    sysinfo.mIllState = mcujson.optBoolean(SystemInfo.ARM_CMD_SYS_ILLON_KEYSTRING, false);
                    sysinfo.mPowerState = mcujson.optBoolean(SystemInfo.ARM_DATA_POWER_STATE_KEYSTRING, true);
                    sysinfo.mSourceVaildFlag = mcujson.optInt(SystemInfo.ARM_CMD_SYS_SOURECEVAILDFLAG_KEYSTRING, 0);
                    sysinfo.mLastDevice = mcujson.optInt(SystemInfo.ARM_CMD_SYS_LAST_DEVEICE_KEYSTRING, 0);
                    sysinfo.mMcuSource = mcujson.optInt(SystemInfo.ARM_CMD_MCUSOURCE_DATA_KEYSTRING, 0);
                    sysinfo.mMcuState = mcujson.optInt(SystemInfo.ARM_CMD_MCUSTATE_DATA_KEYSTRING, 0);
                    sysinfo.mMcuTime = mcujson.optLong(SystemInfo.ARM_DATA_MCUTIME_KEYSTRING, 0L);
                    sysinfo.mSysTime = mcujson.optLong(SystemInfo.ARM_DATA_SYSTIME_KEYSTRING, 0L);
                    sysinfo.mBPowerOn = mcujson.optBoolean(SystemInfo.ARM_DATA_SYS_BPOWER_ON_KEYSTRING, false);
                    sysinfo.mBrightTurner = mcujson.optInt(SystemInfo.ARM_DATA_SYS_BRIGHT_TURNER, 100);
                    sysinfo.mViceDirverHeadPhone = mcujson.optBoolean(SystemInfo.ARM_DATA_SYS_VICEDIRVER_HEADPHONE, false);
                    sysinfo.mCarSpeedState = mcujson.optInt(SystemInfo.ARM_CMD_SYS_CARSPEED_KEYSTRING, 0);
                    sysinfo.mAvmState = mcujson.optInt(SystemInfo.ARM_DATA_SYS_NEED_SHOWDIALOG_KEYSTRING, 0);
                    sysinfo.mRadarBeep = mcujson.optInt(SystemInfo.ARM_DATA_RADARBEEP_KEYSTRING, 0);
                    JSONObject mcujsonArray = mcujson.getJSONObject(SystemInfo.ARM_DATA_RESERVED_BLOCK_KEYSTRING);
                    if (mcujsonArray != null) {
                        for (int i = 0; i < mcujsonArray.length(); i++) {
                            String cmd = SystemInfo.ARM_DATA_BLOCK_NO_KEYSTRING + i;
                            sysinfo.ReservedData[i] = (byte) mcujsonArray.optInt(cmd, 0);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return sysinfo;
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SystemInfo[] newArray(int size) {
            return new SystemInfo[size];
        }
    };
    static final String TAG = "SystemInfo";
    private byte[] ReservedData = new byte[30];
    private boolean mAccState;
    private int mAvmState;
    private boolean mBPowerOn;
    private int mBrightTurner;
    private int mCarSpeedState;
    private boolean mIllState;
    private boolean mIsCarRunning;
    private boolean mIsParking;
    private int mLastDevice;
    private int mMcuSource;
    private int mMcuState;
    private long mMcuTime;
    private boolean mPowerState;
    private int mRadarBeep;
    private int mSourceVaildFlag;
    private boolean mSysReady;
    private long mSysTime;
    private boolean mViceDirverHeadPhone;

    public int getMcuSource() {
        return this.mMcuSource;
    }

    public int getMcuState() {
        return this.mMcuState;
    }

    public boolean getBpowerOn() {
        return this.mBPowerOn;
    }

    public boolean getViceDriverHeadPhone() {
        return this.mViceDirverHeadPhone;
    }

    public int getBrightTurner() {
        return this.mBrightTurner;
    }

    public byte[] getReservedData() {
        return this.ReservedData;
    }

    public boolean isParking() {
        return this.mIsParking;
    }

    public boolean isSysReady() {
        return this.mSysReady;
    }

    public boolean isAccOn() {
        return this.mAccState;
    }

    public int getShowTouchDialogState() {
        return this.mAvmState;
    }

    public boolean isPowerOnState() {
        return this.mPowerState;
    }

    public long getMcuTime() {
        return this.mMcuTime;
    }

    public long getSysTime() {
        return this.mSysTime;
    }

    public int getCarSpeedState() {
        return this.mCarSpeedState;
    }

    public boolean isCarRunning() {
        return this.mIsCarRunning;
    }

    public boolean isIllState() {
        return this.mIllState;
    }

    public int getSourceVailFlag() {
        return this.mSourceVaildFlag;
    }

    public int getLastDevice() {
        return this.mLastDevice;
    }

    public int getRadarBeepState() {
        return this.mRadarBeep;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.mIsParking ? 1 : 0);
        parcel.writeInt(this.mAccState ? 1 : 0);
        parcel.writeInt(this.mIsCarRunning ? 1 : 0);
        parcel.writeInt(this.mIllState ? 1 : 0);
        parcel.writeInt(this.mPowerState ? 1 : 0);
        parcel.writeInt(this.mSourceVaildFlag);
        parcel.writeInt(this.mLastDevice);
        parcel.writeInt(this.mMcuSource);
        parcel.writeInt(this.mMcuState);
        parcel.writeLong(this.mMcuTime);
        parcel.writeLong(this.mSysTime);
        parcel.writeByteArray(this.ReservedData);
    }
}
