package android.zhonghong.mcuservice;

import android.os.Parcel;
import android.os.Parcelable;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class SettingsInfo implements Parcelable {
    static final String ARM_CMD_CAN_VER_KEYSTRING = "canver";
    static final String ARM_CMD_GET_WHEELSTUDY_FLAG_KEYSTRING = "wheelstudyflag";
    static final String ARM_CMD_GET_WHEEL_IS_LEARNING_FLAG_KEYSTRING = "wheelislearning";
    static final String ARM_CMD_MCU103_VER_KEYSTRING = "mcu103ver";
    static final String ARM_CMD_MCU_VER_INSIDE_KEYSTRING = "mcuverinside";
    static final String ARM_CMD_MCU_VER_KEYSTRING = "mcuver";
    static final String ARM_CMD_SET_AUTOBRIGHT_ON_KEYSTRING = "setautobrighton";
    static final String ARM_CMD_SET_TFTONOFF1_KEYSTRING = "TFT1";
    static final String ARM_CMD_SET_TFTONOFF2_KEYSTRING = "TFT2";
    static final String ARM_CMD_SET_WHEELS_SETUP_KEYSTRING = "setwheel";
    static final String ARM_DATA_3D_AUDIO_SW_KEYSTRING = "3D_AUDIO_SW";
    static final String ARM_DATA_AMLIMITER_KEYSTRING = "AM_LIMITER";
    static final String ARM_DATA_ARMSAVE1_KEYSTRING = "SYS_ARMSAVE1";
    static final String ARM_DATA_ARMSAVE2_KEYSTRING = "SYS_ARMSAVE2";
    static final String ARM_DATA_ARMSAVE3_KEYSTRING = "SYS_ARMSAVE3";
    static final String ARM_DATA_AUDIOMODE_KEYSTRING = "SYS_AUDIOMODE";
    static final String ARM_DATA_BACKLIGHT_KEYSTRING = "backlight";
    static final String ARM_DATA_BAL_KEYSTRING = "audiobal";
    static final String ARM_DATA_BASS_KEYSTRING = "bass";
    static final String ARM_DATA_BEEPVOL_KEYSTRING = "SYS_BEEPVOL";
    static final String ARM_DATA_BEEP_KEYSTRING = "SYS_BEEP";
    static final String ARM_DATA_BRIGHT_KEYSTRING = "brightness";
    static final String ARM_DATA_BTVOL_KEYSTRING = "SYS_BTVOL";
    static final String ARM_DATA_CAN_COMPANY_KEYSTRING = "CAN_COMPANY";
    static final String ARM_DATA_CARSPEED_VOLUME_KEYSTRING = "carspeed_volume";
    static final String ARM_DATA_DAY_KEYSTRING = "SYS_DAY";
    static final String ARM_DATA_DEFVOL_KEYSTRING = "defvol";
    static final String ARM_DATA_EQ_16K_KEYSTRING = "EQ16k";
    static final String ARM_DATA_EQ_1K_KEYSTRING = "EQ1k";
    static final String ARM_DATA_EQ_40_KEYSTRING = "EQ40";
    static final String ARM_DATA_EQ_500_KEYSTRING = "EQ500";
    static final String ARM_DATA_EQ_5K_KEYSTRING = "EQ5k";
    static final String ARM_DATA_EQ_80_KEYSTRING = "EQ80";
    static final String ARM_DATA_FADE_KEYSTRING = "audiofade";
    static final String ARM_DATA_FMLIMITER_KEYSTRING = "FM_LIMITER";
    static final String ARM_DATA_GPSVOL_KEYSTRING = "SYS_GPSVOL";
    static final String ARM_DATA_HOUR_KEYSTRING = "SYS_HOUR";
    static final String ARM_DATA_LANG_SEL_KEYSTRING = "LANG_SEL";
    static final String ARM_DATA_LOUD_KEYSTRING = "SYS_LOUD";
    static final String ARM_DATA_MID_KEYSTRING = "SYS_MID";
    static final String ARM_DATA_MINUTE_KEYSTRING = "SYS_MINUTE";
    static final String ARM_DATA_MONTH_KEYSTRING = "SYS_MONTH";
    static final String ARM_DATA_MUTE_KEYSTRING = "SYS_MUTE";
    static final String ARM_DATA_PRODUCT_INFO_KEYSTRING = "PRODUCT_INFO";
    static final String ARM_DATA_RRS_AUTO_LEVEL_KEYSTRING = "RRS_AUTO_LEVEL";
    static final String ARM_DATA_RRS_AUTO_REQ_KEYSTRING = "RRS_AUTO_REQ";
    static final String ARM_DATA_RRS_RTURN_EN_KEYSTRING = "RRS_RTURN_EN";
    static final String ARM_DATA_SECOND_KEYSTRING = "SYS_SECOND";
    static final String ARM_DATA_SYSFLAG2_KEYSTRING = "SYS_SYSFLAG2";
    static final String ARM_DATA_SYSFLAG_KEYSTRING = "SYS_FLAG";
    static final String ARM_DATA_SYS_FORCE_MUTE_KEYSTRING = "FORCE_MUTE";
    static final String ARM_DATA_SYS_PART_DATA_KEYSTRING = "PART_NUM_DATA";
    static final String ARM_DATA_SYS_PRODUCT_ID_DATA_KEYSTRING = "PRODUCT_ID_DATA";
    static final String ARM_DATA_SYS_TUID_DATA_KEYSTRING = "TUID_DATA";
    static final String ARM_DATA_SYS_UNLOCK_STATE_KEYSTRING = "UNLOCK_STATE";
    static final String ARM_DATA_SYS_VIN_DATA_KEYSTRING = "VIN_DATA";
    static final String ARM_DATA_TBOXVOL_KEYSTRING = "SYS_TBOXVOL";
    static final String ARM_DATA_TIME12H_KEYSTRING = "SYS_TIME12H";
    static final String ARM_DATA_TREB_KEYSTRING = "treb";
    static final String ARM_DATA_TTSVOL_KEYSTRING = "SYS_TTSVOL";
    static final String ARM_DATA_USER_BASS_KEYSTRING = "SYS_USER_BASS";
    static final String ARM_DATA_USER_MID_KEYSTRING = "SYS_USER_MID";
    static final String ARM_DATA_USER_TREB_KEYSTRING = "SYS_USER_TREB";
    static final String ARM_DATA_VICEBACKLIGHT_KEYSTRING = "vicebacklight";
    static final String ARM_DATA_VOL_KEYSTRING = "SYS_VOL";
    static final String ARM_DATA_WELCOME_REQ_KEYSTRING = "WELCOME_REQ";
    static final String ARM_DATA_YEAR_KEYSTRING = "SYS_YEAR";
    private static final int INVAILDVALUE = -1;
    private int day;
    private int hour;
    private boolean is3DAudioEnabled;
    private boolean isBeepEnabled;
    private int mAmLimiter;
    private int mArmSave1;
    private int mArmSave2;
    private int mArmSave3;
    private int mAudio16k;
    private int mAudio1k;
    private int mAudio40;
    private int mAudio500;
    private int mAudio5k;
    private int mAudio80;
    private int mAudioBass;
    private int mAudioMid;
    private int mAudioMode;
    private int mAudioTreb;
    private int mBacklight;
    private int mBal;
    private int mBeepVol;
    private int mBrightness;
    private int mBtVol;
    private int mCanFavtoryVer;
    private int mDefVol;
    private int mFade;
    private int mFmLimiter;
    private int mGpsVol;
    private boolean mIsLoudEnabled;
    private boolean mIsMute;
    private boolean mIsWheelLearning;
    private int mProductInfo;
    private int mRrsAudoLevel;
    private int mRrsAutoReq;
    private int mRrsTurnEnable;
    private int mSpeedAdjustVolumeLevel;
    private int mSysFlag;
    private int mSysFlag2;
    private int mSysLanguage;
    private int mSystemVol;
    private int mTboxVol;
    private boolean mTftOn;
    private boolean mTftOn2;
    private boolean mTime24H;
    private int mTtsVol;
    private int mUnlockState;
    private int mUserBass;
    private int mUserMid;
    private int mUserTreb;
    private int mViceBackLight;
    private int mWelcomeState;
    private int minute;
    private int month;
    private int second;
    private int year;
    private static int[] mMcuVersion = new int[30];
    private static int[] Mcu103Ver = new int[30];
    private static int[] McuVerInside = new int[30];
    private static int[] VinData = new int[30];
    private static int[] CanVer = new int[30];
    private static int[] TuidData = new int[30];
    private static int[] PartData = new int[30];
    private static int[] ProductData = new int[30];
    public static final Parcelable.Creator<SettingsInfo> CREATOR = new Parcelable.Creator<SettingsInfo>() { // from class: android.zhonghong.mcuservice.SettingsInfo.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SettingsInfo createFromParcel(Parcel from) {
            JSONException e;
            int len = from.readInt();
            int type = from.readInt();
            byte[] data = new byte[len];
            from.readByteArray(data);
            SettingsInfo settings = new SettingsInfo();
            if (type == 1) {
                String str = new String(data);
                try {
                    JSONObject json = new JSONObject(str);
                    settings.year = json.optInt(SettingsInfo.ARM_DATA_YEAR_KEYSTRING, -1);
                    settings.month = json.optInt(SettingsInfo.ARM_DATA_MONTH_KEYSTRING, -1);
                    settings.day = json.optInt(SettingsInfo.ARM_DATA_DAY_KEYSTRING, -1);
                    settings.hour = json.optInt(SettingsInfo.ARM_DATA_HOUR_KEYSTRING, -1);
                    settings.minute = json.optInt(SettingsInfo.ARM_DATA_MINUTE_KEYSTRING, -1);
                    settings.second = json.optInt(SettingsInfo.ARM_DATA_SECOND_KEYSTRING, -1);
                    settings.mSystemVol = json.optInt(SettingsInfo.ARM_DATA_VOL_KEYSTRING, -1);
                    settings.mAudio40 = json.optInt(SettingsInfo.ARM_DATA_EQ_40_KEYSTRING, -1);
                    settings.mAudio80 = json.optInt(SettingsInfo.ARM_DATA_EQ_80_KEYSTRING, -1);
                    settings.mAudio500 = json.optInt(SettingsInfo.ARM_DATA_EQ_500_KEYSTRING, -1);
                    settings.mAudio1k = json.optInt(SettingsInfo.ARM_DATA_EQ_1K_KEYSTRING, -1);
                    settings.mAudio5k = json.optInt(SettingsInfo.ARM_DATA_EQ_5K_KEYSTRING, -1);
                    settings.mAudio16k = json.optInt(SettingsInfo.ARM_DATA_EQ_16K_KEYSTRING, -1);
                    settings.mAudioBass = json.optInt(SettingsInfo.ARM_DATA_BASS_KEYSTRING, -1);
                    settings.mAudioTreb = json.optInt(SettingsInfo.ARM_DATA_TREB_KEYSTRING, -1);
                    settings.mAudioMid = json.optInt(SettingsInfo.ARM_DATA_MID_KEYSTRING, -1);
                    settings.mFade = json.optInt(SettingsInfo.ARM_DATA_FADE_KEYSTRING, -1);
                    settings.mBal = json.optInt(SettingsInfo.ARM_DATA_BAL_KEYSTRING, -1);
                    settings.mAudioMode = json.optInt(SettingsInfo.ARM_DATA_AUDIOMODE_KEYSTRING, -1);
                    settings.mBrightness = json.optInt(SettingsInfo.ARM_DATA_BRIGHT_KEYSTRING, -1);
                    settings.mSysFlag = json.optInt(SettingsInfo.ARM_DATA_SYSFLAG_KEYSTRING, -1);
                    settings.mBtVol = json.optInt(SettingsInfo.ARM_DATA_BTVOL_KEYSTRING, -1);
                    settings.mGpsVol = json.optInt(SettingsInfo.ARM_DATA_GPSVOL_KEYSTRING, -1);
                    settings.mTtsVol = json.optInt(SettingsInfo.ARM_DATA_TTSVOL_KEYSTRING, -1);
                    settings.mSysFlag2 = json.optInt(SettingsInfo.ARM_DATA_SYSFLAG2_KEYSTRING, -1);
                    settings.mDefVol = json.optInt(SettingsInfo.ARM_DATA_DEFVOL_KEYSTRING, -1);
                    settings.mArmSave1 = json.optInt(SettingsInfo.ARM_DATA_ARMSAVE1_KEYSTRING, -1);
                    settings.mArmSave2 = json.optInt(SettingsInfo.ARM_DATA_ARMSAVE2_KEYSTRING, -1);
                    settings.mArmSave3 = json.optInt(SettingsInfo.ARM_DATA_ARMSAVE3_KEYSTRING, -1);
                    settings.mUserBass = json.optInt(SettingsInfo.ARM_DATA_USER_BASS_KEYSTRING, -1);
                    settings.mUserMid = json.optInt(SettingsInfo.ARM_DATA_USER_MID_KEYSTRING, -1);
                    settings.mUserTreb = json.optInt(SettingsInfo.ARM_DATA_USER_TREB_KEYSTRING, -1);
                    settings.mTime24H = json.optBoolean(SettingsInfo.ARM_DATA_TIME12H_KEYSTRING, false);
                    settings.mIsWheelLearning = json.optBoolean(SettingsInfo.ARM_CMD_GET_WHEEL_IS_LEARNING_FLAG_KEYSTRING, false);
                    settings.mIsMute = json.optBoolean(SettingsInfo.ARM_DATA_MUTE_KEYSTRING, false);
                    settings.isBeepEnabled = json.optBoolean(SettingsInfo.ARM_DATA_BEEP_KEYSTRING, true);
                    settings.mTftOn = json.optBoolean(SettingsInfo.ARM_CMD_SET_TFTONOFF1_KEYSTRING, true);
                    settings.mTftOn2 = json.optBoolean(SettingsInfo.ARM_CMD_SET_TFTONOFF2_KEYSTRING, true);
                    settings.mAutoBrightOn = json.optBoolean(SettingsInfo.ARM_CMD_SET_AUTOBRIGHT_ON_KEYSTRING, true);
                    JSONArray aa = json.optJSONArray(SettingsInfo.ARM_CMD_MCU_VER_KEYSTRING);
                    int len1 = aa.length();
                    int index = 0;
                    while (index < len1) {
                        try {
                            int len2 = len;
                            int type2 = type;
                            byte[] data2 = data;
                            String str2 = str;
                            SettingsInfo.mMcuVersion[index] = aa.getInt(index);
                            index++;
                            len = len2;
                            type = type2;
                            data = data2;
                            str = str2;
                        } catch (JSONException e2) {
                            e = e2;
                            e = e;
                            e.printStackTrace();
                            return settings;
                        }
                    }
                    JSONArray aainside = json.optJSONArray(SettingsInfo.ARM_CMD_MCU_VER_INSIDE_KEYSTRING);
                    if (aainside != null) {
                        try {
                            int len3 = aainside.length();
                            for (int index2 = 0; index2 < len3; index2++) {
                                SettingsInfo.McuVerInside[index2] = aainside.getInt(index2);
                            }
                        } catch (JSONException e3) {
                            e = e3;
                            e = e;
                            e.printStackTrace();
                            return settings;
                        }
                    }
                    JSONArray aa103 = json.optJSONArray(SettingsInfo.ARM_CMD_MCU103_VER_KEYSTRING);
                    if (aa103 != null) {
                        int len22 = aa103.length();
                        for (int index3 = 0; index3 < len22; index3++) {
                            SettingsInfo.Mcu103Ver[index3] = aa103.getInt(index3);
                        }
                    }
                    JSONArray flag = json.optJSONArray(SettingsInfo.ARM_CMD_GET_WHEELSTUDY_FLAG_KEYSTRING);
                    if (flag != null) {
                        int flagLen = flag.length();
                        for (int index4 = 0; index4 < flagLen; index4++) {
                            settings.wheelStudyFlag[index4] = flag.getInt(index4);
                        }
                    }
                    JSONArray canversion = json.optJSONArray(SettingsInfo.ARM_CMD_CAN_VER_KEYSTRING);
                    int canlen = canversion.length();
                    int index5 = 0;
                    while (index5 < canlen) {
                        SettingsInfo.CanVer[index5] = canversion.getInt(index5);
                        index5++;
                        len = len;
                        type = type;
                        data = data;
                        str = str;
                    }
                    JSONArray vin = json.optJSONArray(SettingsInfo.ARM_DATA_SYS_VIN_DATA_KEYSTRING);
                    int lenvin = vin.length();
                    int len4 = 0;
                    while (true) {
                        int type3 = type;
                        int type4 = lenvin;
                        if (len4 >= type4) {
                            try {
                                break;
                            } catch (JSONException e4) {
                                e = e4;
                            }
                        } else {
                            SettingsInfo.VinData[len4] = vin.getInt(len4);
                            len4++;
                            type = type3;
                            lenvin = type4;
                            data = data;
                            str = str;
                        }
                    }
                    JSONArray tuid = json.optJSONArray(SettingsInfo.ARM_DATA_SYS_TUID_DATA_KEYSTRING);
                    int lentuid = tuid.length();
                    int lenvin2 = 0;
                    while (true) {
                        byte[] data3 = data;
                        int lentuid2 = lentuid;
                        if (lenvin2 >= lentuid2) {
                            try {
                                break;
                            } catch (JSONException e5) {
                                e = e5;
                                e.printStackTrace();
                                return settings;
                            }
                        }
                        SettingsInfo.TuidData[lenvin2] = tuid.getInt(lenvin2);
                        lenvin2++;
                        data = data3;
                        lentuid = lentuid2;
                        str = str;
                    }
                    JSONArray partnum = json.optJSONArray(SettingsInfo.ARM_DATA_SYS_PART_DATA_KEYSTRING);
                    int lenpart = partnum.length();
                    int lentuid3 = 0;
                    while (true) {
                        int lenpart2 = lenpart;
                        if (lentuid3 >= lenpart2) {
                            break;
                        }
                        SettingsInfo.PartData[lentuid3] = partnum.getInt(lentuid3);
                        lentuid3++;
                        lenpart = lenpart2;
                        str = str;
                    }
                    JSONArray productnum = json.optJSONArray(SettingsInfo.ARM_DATA_SYS_PRODUCT_ID_DATA_KEYSTRING);
                    int lenproduct = productnum.length();
                    int lenpart3 = 0;
                    while (true) {
                        String str3 = str;
                        int lenproduct2 = lenproduct;
                        if (lenpart3 >= lenproduct2) {
                            break;
                        }
                        SettingsInfo.ProductData[lenpart3] = productnum.getInt(lenpart3);
                        lenpart3++;
                        str = str3;
                        lenproduct = lenproduct2;
                    }
                    settings.mBacklight = json.optInt(SettingsInfo.ARM_DATA_BACKLIGHT_KEYSTRING, 5);
                    settings.mViceBackLight = json.optInt(SettingsInfo.ARM_DATA_VICEBACKLIGHT_KEYSTRING, 5);
                    settings.mIsLoudEnabled = json.optBoolean(SettingsInfo.ARM_DATA_LOUD_KEYSTRING, false);
                    settings.mSysLanguage = json.optInt(SettingsInfo.ARM_DATA_LANG_SEL_KEYSTRING, 1);
                    settings.mProductInfo = json.optInt(SettingsInfo.ARM_DATA_PRODUCT_INFO_KEYSTRING, 0);
                    settings.mCanFavtoryVer = json.optInt(SettingsInfo.ARM_DATA_CAN_COMPANY_KEYSTRING, 0);
                    settings.mTboxVol = json.optInt(SettingsInfo.ARM_DATA_TBOXVOL_KEYSTRING, -1);
                    settings.mBeepVol = json.optInt(SettingsInfo.ARM_DATA_BEEPVOL_KEYSTRING, -1);
                    settings.mFmLimiter = json.optInt(SettingsInfo.ARM_DATA_FMLIMITER_KEYSTRING, -1);
                    settings.mAmLimiter = json.optInt(SettingsInfo.ARM_DATA_AMLIMITER_KEYSTRING, -1);
                    settings.mSpeedAdjustVolumeLevel = json.optInt(SettingsInfo.ARM_DATA_CARSPEED_VOLUME_KEYSTRING, -1);
                    settings.is3DAudioEnabled = json.optBoolean(SettingsInfo.ARM_DATA_3D_AUDIO_SW_KEYSTRING, false);
                    settings.mWelcomeState = json.optInt(SettingsInfo.ARM_DATA_WELCOME_REQ_KEYSTRING, -1);
                    settings.mRrsAudoLevel = json.optInt(SettingsInfo.ARM_DATA_RRS_AUTO_LEVEL_KEYSTRING, -1);
                    settings.mRrsTurnEnable = json.optInt(SettingsInfo.ARM_DATA_RRS_RTURN_EN_KEYSTRING, -1);
                    settings.mRrsAutoReq = json.optInt(SettingsInfo.ARM_DATA_RRS_AUTO_REQ_KEYSTRING, -1);
                    settings.mUnlockState = json.optInt(SettingsInfo.ARM_DATA_SYS_UNLOCK_STATE_KEYSTRING, -1);
                } catch (JSONException e6) {
                    e = e6;
                }
            }
            return settings;
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SettingsInfo[] newArray(int size) {
            return new SettingsInfo[size];
        }
    };
    private boolean mAutoBrightOn = true;
    private int[] wheelStudyFlag = new int[3];

    public int getBrightness() {
        return this.mBrightness;
    }

    public int getRrsAutoLevel() {
        return this.mRrsAudoLevel;
    }

    public int getRrsRturnEn() {
        return this.mRrsTurnEnable;
    }

    public boolean is3DAudioEnabled() {
        return this.is3DAudioEnabled;
    }

    public boolean isBeepEnabled() {
        return this.isBeepEnabled;
    }

    public int getBeepVol() {
        return this.mBeepVol;
    }

    public int getVol() {
        return this.mSystemVol;
    }

    public int getAudio40() {
        return this.mAudio40;
    }

    public int getAudio80() {
        return this.mAudio80;
    }

    public int getAudio500() {
        return this.mAudio500;
    }

    public int getAudio1k() {
        return this.mAudio1k;
    }

    public int getAudio5k() {
        return this.mAudio5k;
    }

    public int getAudio16k() {
        return this.mAudio16k;
    }

    public int getTreb() {
        return this.mAudioTreb;
    }

    public int getMid() {
        return this.mAudioMid;
    }

    public int getBass() {
        return this.mAudioBass;
    }

    public boolean isLoudEnabled() {
        return this.mIsLoudEnabled;
    }

    public int getFade() {
        return this.mFade;
    }

    public int getBal() {
        return this.mBal;
    }

    public boolean isMute() {
        return this.mIsMute;
    }

    public int getBtVol() {
        return this.mBtVol;
    }

    public int getFmLimiter() {
        return this.mFmLimiter;
    }

    public int getAmLimiter() {
        return this.mAmLimiter;
    }

    public int getSpeedAdjustVolume() {
        return this.mSpeedAdjustVolumeLevel;
    }

    public int getTboxVol() {
        return this.mTboxVol;
    }

    public int getWelcomeState() {
        return this.mWelcomeState;
    }

    public int getTTsVol() {
        return this.mTtsVol;
    }

    public int getGpsVol() {
        return this.mGpsVol;
    }

    public int getDefVol() {
        return this.mDefVol;
    }

    public int getSysFlag() {
        return this.mSysFlag;
    }

    public int getSysFlag2() {
        return this.mSysFlag2;
    }

    public int getAudioMode() {
        return this.mAudioMode;
    }

    public boolean isTimeFormat24() {
        return this.mTime24H;
    }

    public int getCarDoorUnlockState() {
        return this.mUnlockState;
    }

    public boolean isTftOn() {
        return this.mTftOn;
    }

    public boolean isTftOn2() {
        return this.mTftOn2;
    }

    public boolean isAutoBrightOn() {
        return this.mAutoBrightOn;
    }

    public int getSave1() {
        return this.mArmSave1;
    }

    public int getSave2() {
        return this.mArmSave2;
    }

    public int getSave3() {
        return this.mArmSave3;
    }

    public int getBacklight() {
        return this.mBacklight;
    }

    public int getViceBacklight() {
        return this.mViceBackLight;
    }

    public int getSysLanguage() {
        return this.mSysLanguage;
    }

    public int getProductInfo() {
        return this.mProductInfo;
    }

    public int getFactoryVerCtrl() {
        return this.mCanFavtoryVer;
    }

    public int[] getWheelStudyFlag() {
        return this.wheelStudyFlag;
    }

    public boolean isWheelKeyLearning() {
        return this.mIsWheelLearning;
    }

    public int getAutoRrsTouchReq() {
        return this.mRrsAutoReq;
    }

    public int getYear() {
        return this.year;
    }

    public int getMonth() {
        return this.month;
    }

    public int getDay() {
        return this.day;
    }

    public int getHour() {
        return this.hour;
    }

    public int getMinute() {
        return this.minute;
    }

    public int getSecond() {
        return this.second;
    }

    public String getMcuVersion() {
        return generateMcuVersionString(mMcuVersion);
    }

    public int[] getMcuVersionData() {
        return mMcuVersion;
    }

    public int[] getTuidData() {
        return TuidData;
    }

    public int[] getPartNumData() {
        return PartData;
    }

    public int[] getProductIdData() {
        return ProductData;
    }

    public int[] getVinData() {
        return VinData;
    }

    public int[] getMcuVerInside() {
        return McuVerInside;
    }

    public int[] getMcu103Ver() {
        return Mcu103Ver;
    }

    public int[] getCanVer() {
        return CanVer;
    }

    public int getUserBass() {
        return this.mUserBass;
    }

    public int getUserMid() {
        return this.mUserMid;
    }

    public int getUserTreb() {
        return this.mUserTreb;
    }

    private String generateMcuVersionString(int[] data) {
        if (data == null || data.length < 9) {
            return "0000-00-00-0000";
        }
        return new StringBuilder(String.valueOf(data[3] + (data[4] << 8))).toString() + "-" + String.format("%02d", Integer.valueOf(data[5])) + "-" + String.format("%02d", Integer.valueOf(data[6])) + "-" + String.format("%02d%02d", Integer.valueOf(data[0]), Integer.valueOf(data[1]));
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.year);
        parcel.writeInt(this.month);
        parcel.writeInt(this.day);
        parcel.writeInt(this.hour);
        parcel.writeInt(this.minute);
        parcel.writeInt(this.second);
        parcel.writeInt(this.mSystemVol);
        parcel.writeInt(this.mAudio40);
        parcel.writeInt(this.mAudio80);
        parcel.writeInt(this.mAudio500);
        parcel.writeInt(this.mAudio1k);
        parcel.writeInt(this.mAudio5k);
        parcel.writeInt(this.mAudio16k);
        parcel.writeInt(this.mAudioBass);
        parcel.writeInt(this.mAudioTreb);
        parcel.writeInt(this.mAudioMid);
        parcel.writeInt(this.mFade);
        parcel.writeInt(this.mBal);
        parcel.writeInt(this.mAudioMode);
        parcel.writeInt(this.mBrightness);
        parcel.writeInt(this.mSysFlag);
        parcel.writeInt(this.mBtVol);
        parcel.writeInt(this.mGpsVol);
        parcel.writeInt(this.mSysFlag2);
        parcel.writeInt(this.mDefVol);
        parcel.writeInt(this.mArmSave1);
        parcel.writeInt(this.mArmSave2);
        parcel.writeInt(this.mArmSave3);
        parcel.writeInt(this.mUserBass);
        parcel.writeInt(this.mUserMid);
        parcel.writeInt(this.mUserTreb);
        parcel.writeInt(this.mTime24H ? 1 : 0);
        parcel.writeInt(this.mIsMute ? 1 : 0);
        parcel.writeInt(this.isBeepEnabled ? 1 : 0);
        parcel.writeIntArray(mMcuVersion);
        parcel.writeInt(this.mBacklight);
        parcel.writeInt(this.mFmLimiter);
        parcel.writeInt(this.mAmLimiter);
        parcel.writeInt(this.mSpeedAdjustVolumeLevel);
    }

    public String toString() {
        return "SettingsInfo [mGpsVol=" + this.mGpsVol + ", mBacklight=" + this.mBacklight + ", mViceBackLight=" + this.mViceBackLight + ", mCanFavtoryVer=" + this.mCanFavtoryVer + ", mSysLanguage=" + this.mSysLanguage + ", mWelcomeState=" + this.mWelcomeState + ", mBrightness=" + this.mBrightness + ", mRrsAudoLevel=" + this.mRrsAudoLevel + ", mRrsTurnEnable=" + this.mRrsTurnEnable + ", mAudioTreb=" + this.mAudioTreb + ", mAudioBass=" + this.mAudioBass + ", mAudioMid=" + this.mAudioMid + ", mIsLoudEnabled=" + this.mIsLoudEnabled + ", mFade=" + this.mFade + ", mBal=" + this.mBal + ", mSpeedAdjustVolumeLevel=" + this.mSpeedAdjustVolumeLevel + ", is3DAudioEnabled=" + this.is3DAudioEnabled + ", isBeepEnabled=" + this.isBeepEnabled + ", mIsMute=" + this.mIsMute + ", mBtVol=" + this.mBtVol + ", mBeepVol=" + this.mBeepVol + ", mSystemVol=" + this.mSystemVol + ", mTboxVol=" + this.mTboxVol + ", mTtsVol=" + this.mTtsVol + ", mAudioMode=" + this.mAudioMode + ", mProductInfo=" + this.mProductInfo + ", mTime24H=" + this.mTime24H + ", mTftOn=" + this.mTftOn + "]";
    }
}
