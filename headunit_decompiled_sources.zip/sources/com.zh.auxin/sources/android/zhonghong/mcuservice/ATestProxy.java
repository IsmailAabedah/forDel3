package android.zhonghong.mcuservice;

import android.zhonghong.mcuservice.RegistManager;

/* loaded from: classes.dex */
public class ATestProxy {
    public final String TAG = "ATestProxy";

    public boolean registATestInfoChangedListener(RegistManager.IATestInfoChangedListener listener) {
        return RegistManager.getInstance().addATestInfoChangedListener(listener);
    }

    public boolean unregistATestInfoChangeListener(RegistManager.IATestInfoChangedListener listener) {
        return RegistManager.getInstance().removeATestInfoChangedListener(listener);
    }

    public boolean sendATestDataToMcu(byte[] data) {
        return McuServiceManager.getInstance().sendData(7, data);
    }
}
