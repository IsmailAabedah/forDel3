package android.zhonghong.mcuservice;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public class SystemKeyInfo implements Parcelable {
    public static final Parcelable.Creator<SystemKeyInfo> CREATOR = new Parcelable.Creator<SystemKeyInfo>() { // from class: android.zhonghong.mcuservice.SystemKeyInfo.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SystemKeyInfo createFromParcel(Parcel source) {
            SystemKeyInfo syskey = new SystemKeyInfo();
            syskey.type = source.readInt();
            syskey.code = source.readInt();
            syskey.value = source.readInt();
            return syskey;
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public SystemKeyInfo[] newArray(int arg0) {
            return new SystemKeyInfo[arg0];
        }
    };
    public int code;
    public int type;
    public int value;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int arg1) {
    }
}
