package android.zhonghong.mcuservice;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public class McuHardKeyInfo implements Parcelable {
    public static final Parcelable.Creator<McuHardKeyInfo> CREATOR = new Parcelable.Creator<McuHardKeyInfo>() { // from class: android.zhonghong.mcuservice.McuHardKeyInfo.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public McuHardKeyInfo createFromParcel(Parcel source) {
            int len = source.readInt();
            int type = source.readInt();
            byte[] data = new byte[len];
            source.readByteArray(data);
            McuHardKeyInfo mcuKey = new McuHardKeyInfo();
            if (type == 0) {
                mcuKey.keyStatus = data[1] & 255;
                mcuKey.keyCode = data[0] & 255;
            } else {
                mcuKey.keyStatus = 0;
                mcuKey.keyCode = 0;
            }
            return mcuKey;
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public McuHardKeyInfo[] newArray(int arg0) {
            return new McuHardKeyInfo[arg0];
        }
    };
    public static final int KEYCODE_BACK = 171;
    public static final int KEYCODE_BACK_CALL = 169;
    public static final int KEYCODE_DIAL = 95;
    public static final int KEYCODE_DOWN = 45;
    public static final int KEYCODE_ENTER = 37;
    public static final int KEYCODE_EQ = 28;
    public static final int KEYCODE_FF = 21;
    public static final int KEYCODE_FFREW_RELEASE = 42;
    public static final int KEYCODE_GPS = 120;
    public static final int KEYCODE_GPS_NAVI = 126;
    public static final int KEYCODE_HANG_UP = 92;
    public static final int KEYCODE_HOME = 172;
    public static final int KEYCODE_LEFT = 46;
    public static final int KEYCODE_MENU = 173;
    public static final int KEYCODE_MODE = 13;
    public static final int KEYCODE_MUTE = 15;
    public static final int KEYCODE_NEXT = 20;
    public static final int KEYCODE_ONE_KEY_SAVE = 181;
    public static final int KEYCODE_PAUSE = 48;
    public static final int KEYCODE_PICK_UP = 93;
    public static final int KEYCODE_PLAY = 49;
    public static final int KEYCODE_PLAY_PAUSE = 17;
    public static final int KEYCODE_POWER = 12;
    public static final int KEYCODE_PREV = 19;
    public static final int KEYCODE_RADIO = 60;
    public static final int KEYCODE_REW = 22;
    public static final int KEYCODE_RIGHT = 47;
    public static final int KEYCODE_SCREENSAVE = 174;
    public static final int KEYCODE_SEL_DEC = 182;
    public static final int KEYCODE_SEL_INC = 183;
    public static final int KEYCODE_TFTOFF = 1003;
    public static final int KEYCODE_TFT_LAMP = 117;
    public static final int KEYCODE_TFT_RESUME = 84;
    public static final int KEYCODE_UP = 44;
    public static final int KEYCODE_USB = 107;
    public static final int KEYCODE_VOL_DEC = 24;
    public static final int KEYCODE_VOL_INC = 23;
    private int keyCode;
    private int keyStatus;

    public int getKeyStatus() {
        return this.keyStatus;
    }

    public int getKeyCode() {
        return this.keyCode;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel arg0, int arg1) {
    }
}
