package android.zhonghong.mcuservice;

import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;
import android.zhonghong.mcuservice.IDataChangedListener;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class RegistManager {
    public static final String TAG = "RegistManager";
    private static RegistManager sInstance;
    private List<IRadioInfoChangedListener> mRadioInfoListeners = null;
    private List<ISettingsInfoChangedListener> mSettingsInfoListeners = null;
    private List<ICanInfoChangedListener> mCanInfoListeners = null;
    private List<IATestInfoChangedListener> mATestInfoListeners = null;
    private List<ICustomerInfoChangedListener> mCustomerInfoListeners = null;
    private List<ISystemInfoChangedListener> mSystemInfoListeners = null;
    private List<IMcuHardKeyChangedListener> mMcuHardKeyListeners = null;
    private List<ISystemKeyInfoChangedListener> mSystemKeyInfoListeners = null;
    private List<ITouchInfoChangedListener> mTouchInfoListeners = null;
    private List<Integer> mSystemKeyInfoList = null;

    public interface IATestInfoChangedListener {
        void notify(short[] sArr);
    }

    public interface ICanInfoChangedListener {
        void notify(byte[] bArr);
    }

    public interface ICustomerInfoChangedListener {
        void notify(short[] sArr);
    }

    public interface IMcuHardKeyChangedListener {
        void notify(McuHardKeyInfo mcuHardKeyInfo);
    }

    public interface IRadioInfoChangedListener {
        void notify(RadioInfo radioInfo);
    }

    public interface ISettingsInfoChangedListener {
        void notify(SettingsInfo settingsInfo);
    }

    public interface ISystemInfoChangedListener {
        void notify(SystemInfo systemInfo);
    }

    public interface ISystemKeyInfoChangedListener {
        void notify(SystemKeyInfo systemKeyInfo);
    }

    public interface ITouchInfoChangedListener {
        void notify(TouchInfo touchInfo);
    }

    private RegistManager() {
    }

    static RegistManager getInstance() {
        if (sInstance == null) {
            synchronized (RegistManager.class) {
                if (sInstance == null) {
                    sInstance = new RegistManager();
                }
            }
        }
        return sInstance;
    }

    boolean addRadioInfoChangedListener(IRadioInfoChangedListener listener) {
        if (listener == null) {
            Log.i(TAG, "addRadioInfoChangedListener but listener is null");
            return false;
        }
        if (this.mRadioInfoListeners == null) {
            this.mRadioInfoListeners = new ArrayList();
            registRadioInfoChangedListener();
        }
        if (!this.mRadioInfoListeners.contains(listener)) {
            this.mRadioInfoListeners.add(listener);
            return true;
        }
        return true;
    }

    boolean removeRadioInfoChangedListener(IRadioInfoChangedListener listener) {
        if (listener != null && this.mRadioInfoListeners != null && this.mRadioInfoListeners.contains(listener)) {
            this.mRadioInfoListeners.remove(listener);
            return true;
        }
        return false;
    }

    boolean addSettingsInfoChangedListener(ISettingsInfoChangedListener listener) {
        if (listener == null) {
            Log.i(TAG, "addSettingsInfoChangedListener but listener is null");
            return false;
        }
        if (this.mSettingsInfoListeners == null) {
            this.mSettingsInfoListeners = new ArrayList();
            registSettingsInfoChangedListener();
        }
        if (!this.mSettingsInfoListeners.contains(listener)) {
            this.mSettingsInfoListeners.add(listener);
            return true;
        }
        return true;
    }

    boolean removeSettingsInfoChangedListener(ISettingsInfoChangedListener listener) {
        if (listener != null && this.mSettingsInfoListeners != null && this.mSettingsInfoListeners.contains(listener)) {
            this.mSettingsInfoListeners.remove(listener);
            return true;
        }
        return false;
    }

    boolean addMcuKeyInfoChangedListener(IMcuHardKeyChangedListener listener) {
        if (listener == null) {
            Log.i(TAG, "addMcuKeyInfoChangedListener but listener is null");
            return false;
        }
        if (this.mMcuHardKeyListeners == null) {
            this.mMcuHardKeyListeners = new ArrayList();
            registMcuKeyInfoChangedListener();
        }
        if (!this.mMcuHardKeyListeners.contains(listener)) {
            this.mMcuHardKeyListeners.add(listener);
            return true;
        }
        return true;
    }

    boolean removeMcuKeyInfoChangedListener(IMcuHardKeyChangedListener listener) {
        if (listener != null && this.mMcuHardKeyListeners != null && this.mMcuHardKeyListeners.contains(listener)) {
            this.mMcuHardKeyListeners.remove(listener);
            return true;
        }
        return false;
    }

    boolean addSysInfoChangedListener(ISystemInfoChangedListener listener) {
        if (listener == null) {
            Log.i(TAG, "addSysInfoChangedListener but listener is null");
            return false;
        }
        if (this.mSystemInfoListeners == null) {
            this.mSystemInfoListeners = new ArrayList();
            registSysInfoChangedListener();
        }
        if (!this.mSystemInfoListeners.contains(listener)) {
            this.mSystemInfoListeners.add(listener);
            return true;
        }
        return true;
    }

    boolean removeSysInfoChangedListener(ISystemInfoChangedListener listener) {
        if (listener != null && this.mSystemInfoListeners != null && this.mSystemInfoListeners.contains(listener)) {
            this.mSystemInfoListeners.remove(listener);
            return true;
        }
        return false;
    }

    boolean addSystemKeyInfoChangedListener(ISystemKeyInfoChangedListener listener) {
        if (listener == null) {
            Log.i(TAG, "addSystemKeyInfoChangedListener but listener is null");
            return false;
        }
        if (this.mSystemKeyInfoListeners == null) {
            this.mSystemKeyInfoListeners = new ArrayList();
            registSystemKeyInfoChangedListener();
        }
        if (!this.mSystemKeyInfoListeners.contains(listener)) {
            this.mSystemKeyInfoListeners.add(listener);
            return true;
        }
        return true;
    }

    boolean removeSystemKeyInfoChangedListener(ISystemKeyInfoChangedListener listener) {
        if (listener != null && this.mSystemKeyInfoListeners != null && this.mSystemKeyInfoListeners.contains(listener)) {
            this.mSystemKeyInfoListeners.remove(listener);
            return true;
        }
        return false;
    }

    boolean addTouchInfoChangedListener(ITouchInfoChangedListener listener) {
        if (listener == null) {
            Log.i(TAG, "addTouchInfoChangedListener but listener is null");
            return false;
        }
        if (this.mTouchInfoListeners == null) {
            this.mTouchInfoListeners = new ArrayList();
            registTouchInfoChangedListener();
        }
        if (!this.mTouchInfoListeners.contains(listener)) {
            this.mTouchInfoListeners.add(listener);
            return true;
        }
        return true;
    }

    boolean removeTouchInfoChangedListener(ITouchInfoChangedListener listener) {
        if (listener != null && this.mTouchInfoListeners != null && this.mTouchInfoListeners.contains(listener)) {
            this.mTouchInfoListeners.remove(listener);
            return true;
        }
        return false;
    }

    boolean addCanInfoChangedListener(ICanInfoChangedListener listener) {
        if (listener == null) {
            Log.i(TAG, "addCanInfoChangedListener but listener is null");
            return false;
        }
        if (this.mCanInfoListeners == null) {
            this.mCanInfoListeners = new ArrayList();
            registCanInfoChangedListener();
        }
        if (!this.mCanInfoListeners.contains(listener)) {
            this.mCanInfoListeners.add(listener);
            return true;
        }
        return true;
    }

    boolean removeCanInfoChangedListener(ICanInfoChangedListener listener) {
        if (listener != null && this.mCanInfoListeners != null && this.mCanInfoListeners.contains(listener)) {
            this.mCanInfoListeners.remove(listener);
            return true;
        }
        return false;
    }

    boolean addATestInfoChangedListener(IATestInfoChangedListener listener) {
        if (listener == null) {
            Log.i(TAG, "addATestInfoChangedListener but listener is null");
            return false;
        }
        if (this.mATestInfoListeners == null) {
            this.mATestInfoListeners = new ArrayList();
            registATestInfoChangedListener();
        }
        if (!this.mATestInfoListeners.contains(listener)) {
            this.mATestInfoListeners.add(listener);
            return true;
        }
        return true;
    }

    boolean removeATestInfoChangedListener(IATestInfoChangedListener listener) {
        if (listener != null && this.mATestInfoListeners != null && this.mATestInfoListeners.contains(listener)) {
            this.mATestInfoListeners.remove(listener);
            return true;
        }
        return false;
    }

    boolean addCustomerInfoChangedListener(ICustomerInfoChangedListener listener) {
        if (listener == null) {
            Log.i(TAG, "addCustomerInfoChangedListener but listener is null");
            return false;
        }
        if (this.mCustomerInfoListeners == null) {
            this.mCustomerInfoListeners = new ArrayList();
            registCustomerInfoChangedListener();
        }
        if (!this.mCustomerInfoListeners.contains(listener)) {
            this.mCustomerInfoListeners.add(listener);
            return true;
        }
        return true;
    }

    boolean removeCustomerInfoChangedListener(ICustomerInfoChangedListener listener) {
        if (listener != null && this.mCustomerInfoListeners != null && this.mCustomerInfoListeners.contains(listener)) {
            this.mCustomerInfoListeners.remove(listener);
            return true;
        }
        return false;
    }

    boolean addSystemKey(int key) {
        if (this.mSystemKeyInfoList == null) {
            this.mSystemKeyInfoList = new ArrayList();
        }
        this.mSystemKeyInfoList.add(Integer.valueOf(key));
        return true;
    }

    boolean removeSystemKey(int key) {
        if (this.mSystemKeyInfoList == null) {
            return false;
        }
        for (int i = 0; i < this.mSystemKeyInfoList.size(); i++) {
            if (this.mSystemKeyInfoList.get(i).intValue() == key) {
                this.mSystemKeyInfoList.remove(i);
                if (this.mSystemKeyInfoList.size() != 0) {
                    return true;
                }
                this.mSystemKeyInfoList = null;
                return true;
            }
        }
        return false;
    }

    private void registRadioInfoChangedListener() {
        register(1);
    }

    private void registSettingsInfoChangedListener() {
        register(2);
    }

    private void registCanInfoChangedListener() {
        register(5);
    }

    private void registATestInfoChangedListener() {
        register(7);
    }

    private void registCustomerInfoChangedListener() {
        register(6);
    }

    private void registSysInfoChangedListener() {
        register(3);
    }

    private void registMcuKeyInfoChangedListener() {
        register(4);
    }

    private void registSystemKeyInfoChangedListener() {
        register(4608);
    }

    private void registTouchInfoChangedListener() {
        register(4864);
    }

    private void register(int domain) {
        McuServiceManager.getInstance().registDataChangedListener(domain, new DataChangedListener());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doNotify(int msg, Parcel parcel) {
        if (msg == 4608) {
            SystemKeyInfo systemkey = SystemKeyInfo.CREATOR.createFromParcel(parcel);
            if (systemkey != null && this.mSystemKeyInfoListeners != null) {
                for (ISystemKeyInfoChangedListener listener : this.mSystemKeyInfoListeners) {
                    listener.notify(systemkey);
                }
                return;
            }
            return;
        }
        if (msg != 4864) {
            switch (msg) {
                case 1:
                    RadioInfo radio = RadioInfo.CREATOR.createFromParcel(parcel);
                    if (radio != null && this.mRadioInfoListeners != null) {
                        for (IRadioInfoChangedListener listener2 : this.mRadioInfoListeners) {
                            listener2.notify(radio);
                        }
                        break;
                    }
                    break;
                case 2:
                    SettingsInfo settings = SettingsInfo.CREATOR.createFromParcel(parcel);
                    if (settings != null && this.mSettingsInfoListeners != null) {
                        for (ISettingsInfoChangedListener listener3 : this.mSettingsInfoListeners) {
                            listener3.notify(settings);
                        }
                        break;
                    }
                    break;
                case 3:
                    SystemInfo sysinfo = SystemInfo.CREATOR.createFromParcel(parcel);
                    if (sysinfo != null && this.mSystemInfoListeners != null) {
                        for (ISystemInfoChangedListener listener4 : this.mSystemInfoListeners) {
                            listener4.notify(sysinfo);
                        }
                        break;
                    }
                    break;
                case 4:
                    McuHardKeyInfo keyInfo = McuHardKeyInfo.CREATOR.createFromParcel(parcel);
                    if (keyInfo != null && this.mMcuHardKeyListeners != null) {
                        for (IMcuHardKeyChangedListener listener5 : this.mMcuHardKeyListeners) {
                            listener5.notify(keyInfo);
                        }
                        break;
                    }
                    break;
                case 5:
                    byte[] resultByte = DataUtils.toByteArray(parcel);
                    if (resultByte != null && this.mCanInfoListeners != null) {
                        for (ICanInfoChangedListener listener6 : this.mCanInfoListeners) {
                            listener6.notify(resultByte);
                        }
                        break;
                    }
                    break;
                case 6:
                    short[] result = DataUtils.toShortArray(parcel);
                    if (result != null && this.mCustomerInfoListeners != null) {
                        for (ICustomerInfoChangedListener listener7 : this.mCustomerInfoListeners) {
                            listener7.notify(result);
                        }
                        break;
                    }
                    break;
                case 7:
                    short[] result2 = DataUtils.toShortArray(parcel);
                    if (result2 != null && this.mATestInfoListeners != null) {
                        for (IATestInfoChangedListener listener8 : this.mATestInfoListeners) {
                            listener8.notify(result2);
                        }
                        break;
                    }
                    break;
            }
            return;
        }
        TouchInfo touch = TouchInfo.CREATOR.createFromParcel(parcel);
        if (touch != null && this.mTouchInfoListeners != null) {
            for (ITouchInfoChangedListener listener9 : this.mTouchInfoListeners) {
                listener9.notify(touch);
            }
        }
    }

    class DataChangedListener extends IDataChangedListener.Stub {
        DataChangedListener() {
        }

        @Override // android.zhonghong.mcuservice.IDataChangedListener
        public void notify(int msg, int ext0, int ext1, Parcel parcel) throws RemoteException {
            RegistManager.this.doNotify(msg, parcel);
        }
    }

    void registAll() {
        if (!isListEmpty(this.mRadioInfoListeners)) {
            registRadioInfoChangedListener();
        }
        if (!isListEmpty(this.mSettingsInfoListeners)) {
            registSettingsInfoChangedListener();
        }
        if (!isListEmpty(this.mCanInfoListeners)) {
            registCanInfoChangedListener();
        }
        if (!isListEmpty(this.mCustomerInfoListeners)) {
            registCustomerInfoChangedListener();
        }
        if (!isListEmpty(this.mSystemInfoListeners)) {
            registSysInfoChangedListener();
        }
        if (!isListEmpty(this.mMcuHardKeyListeners)) {
            registMcuKeyInfoChangedListener();
        }
        if (!isListEmpty(this.mSystemKeyInfoListeners)) {
            registSystemKeyInfoChangedListener();
        }
        if (!isListEmpty(this.mTouchInfoListeners)) {
            registTouchInfoChangedListener();
        }
        if (isListEmpty(this.mSystemKeyInfoList)) {
            return;
        }
        for (int i = 0; i < this.mSystemKeyInfoList.size(); i++) {
            McuServiceManager.getInstance().sendInt(4352, this.mSystemKeyInfoList.get(i).intValue(), 0);
        }
    }

    static boolean isListEmpty(List<?> list) {
        return list == null || list.size() == 0;
    }
}
