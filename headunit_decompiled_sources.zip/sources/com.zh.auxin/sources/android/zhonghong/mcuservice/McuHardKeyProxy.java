package android.zhonghong.mcuservice;

import android.os.Parcel;
import android.zhonghong.mcuservice.RegistManager;

/* loaded from: classes.dex */
public class McuHardKeyProxy {
    public boolean registKeyInfoChangedListener(RegistManager.IMcuHardKeyChangedListener listener) {
        return RegistManager.getInstance().addMcuKeyInfoChangedListener(listener);
    }

    public McuHardKeyInfo getMcuDataInfo() {
        Parcel out = McuServiceManager.getInstance().getPracel(4, 4);
        return McuHardKeyInfo.CREATOR.createFromParcel(out);
    }

    public boolean unregistKeyInfoChangedListener(RegistManager.IMcuHardKeyChangedListener listener) {
        RegistManager.getInstance().removeMcuKeyInfoChangedListener(listener);
        return true;
    }
}
